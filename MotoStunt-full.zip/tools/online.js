
// ===ONLINE===
const DEFAULT_SERVER='wss://motostunt-server.onrender.com';
const PLACE_REWARD=[400,250,150,80];
function esc(s){ return String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function clean(s){ return String(s||'').replace(/[<>&"'`]/g,'').trim().slice(0,16); }
function serverUrl(){
  if(S.server) { let u=S.server.trim(); if(/^https?:\/\//.test(u)) u=u.replace(/^http/,'ws'); else if(!/^wss?:\/\//.test(u)) u='wss://'+u; return u.replace(/\/$/,''); }
  if(/^https?:$/.test(location.protocol) && location.host) return (location.protocol==='https:'?'wss://':'ws://')+location.host;
  return DEFAULT_SERVER;
}
const Net={ws:null,id:0,room:null,roomAt:0,status:'off',pending:null,
  connect(){
    if(this.ws && this.ws.readyState<2) return;
    this.status='connecting'; let ws;
    try{ ws=new WebSocket(serverUrl()); }catch(e){ this.status='error'; onNet({t:'_status'}); return; }
    this.ws=ws;
    const to=setTimeout(()=>{ if(this.ws===ws && ws.readyState!==1){ try{ws.close();}catch(e){} } }, 75000);
    ws.onopen=()=>{ clearTimeout(to); if(this.ws!==ws) return; this.status='on'; this.hello(); if(this.pending){ this.send(this.pending); this.pending=null; } onNet({t:'_status'}); };
    ws.onmessage=e=>{ let m; try{ m=JSON.parse(e.data); }catch(_){ return; } onNet(m); };
    ws.onclose=()=>{ clearTimeout(to); if(this.ws!==ws) return; this.ws=null; const was=this.status; this.status=was==='connecting'?'error':'off'; this.room=null; this.pending=null; onNet({t:'_closed'}); };
    ws.onerror=()=>{};
  },
  send(o){ if(this.ws && this.ws.readyState===1) this.ws.send(JSON.stringify(o)); },
  hello(){ this.send({t:'hello', name:S.name, bike:curBike().type, color:bikeColor()}); },
  close(){ const w=this.ws; this.ws=null; if(w) try{ w.close(); }catch(e){} this.status='off'; this.room=null; this.pending=null; }
};
function netDo(o){ if(Net.status==='on') Net.send(o); else { Net.pending=o; Net.connect(); } if(scene==='online') renderOnline(); }

function onNet(m){
  switch(m.t){
    case 'welcome': Net.id=m.id; break;
    case '_status': if(scene==='online') renderOnline(); break;
    case '_closed':
      if(scene==='online'||scene==='lobby') renderOnline();
      if(R && R.mode==='online' && !R.over){ R.netLost=true; toast('Связь с сервером потеряна'); }
      break;
    case 'room':
      Net.room=m; Net.roomAt=performance.now();
      if(scene==='online'||scene==='lobby') renderLobby();
      break;
    case 'go':
      document.querySelectorAll('.ov').forEach(o=>o.remove());
      startRace('online', m.level|0);
      R.startDelay=(m.countdown||3000)/1000;
      break;
    case 'st': {
      if(!R || R.mode!=='online') break;
      const g=ghost(m.id); if(!g) break;
      g.buf.push({t:performance.now(), s:m.s}); if(g.buf.length>24) g.buf.shift();
      g.x=m.s[0];
      break; }
    case 'fin': {
      if(!R || R.mode!=='online') break;
      const g=ghost(m.id); if(g){ g.fin=m.time; if(!R.over) pop(g.name+' финишировал!','#8fd3ff'); }
      updateWaitList();
      break; }
    case 'left': if(R && R.ghosts) delete R.ghosts[m.id]; break;
    case 'results': showOnlineResults(m); break;
    case 'lobbyLeft': Net.room=null; if(scene==='lobby') renderOnline(); break;
    case 'err': toast(m.msg||'Ошибка'); if(scene==='online') renderOnline(); break;
  }
}
function ghost(id){
  if(id===Net.id || !R) return null;
  if(!R.ghosts[id]){
    const p=Net.room && Net.room.players.find(q=>q.id===id) || {name:'Соперник', bike:'dirt', color:'#3a7bd5'};
    R.ghosts[id]={id, name:p.name, type:p.bike, color:p.color, buf:[], x:0, fin:null};
  }
  return R.ghosts[id];
}

// ---------- screens ----------
function renderOnline(){
  scene='online';
  const st=Net.status;
  const msg = st==='connecting' ? '⏳ Подключение к серверу… Бесплатный сервер может просыпаться до минуты.'
            : st==='on' ? '🟢 Сервер на связи' : st==='error' ? '🔴 Сервер недоступен. Проверь интернет или адрес сервера в ⚙️ настройках.' : '';
  h(`<div class="top"><button class="ic" data-a="onlineBack">⬅</button><div class="ttl">Онлайн-гонка</div><div class="pill">💰 <b>${fmt(S.coins)}</b></div></div>
  <div class="onl">
    <div class="ocol">
      <label class="lbl">Твой ник<input id="nick" maxlength="16" value="${esc(S.name)}"></label>
      <div class="ostatus">${msg}</div>
      <p class="hint">Все едут одну трассу эндуро. Соперники видны полупрозрачными. Места: 💰${PLACE_REWARD.join(' / ')}.</p>
    </div>
    <div class="ocol">
      <button class="btn green big" data-a="quick" ${st==='connecting'?'disabled':''}>⚡ Быстрая игра</button>
      <button class="btn" data-a="create" ${st==='connecting'?'disabled':''}>➕ Создать комнату</button>
      <div class="joinrow"><input id="rcode" maxlength="4" placeholder="КОД" autocapitalize="characters" autocorrect="off" spellcheck="false"><button class="btn" data-a="join" ${st==='connecting'?'disabled':''}>Войти</button></div>
    </div>
  </div>`);
  const nk=document.getElementById('nick');
  nk.addEventListener('change',()=>{ S.name=clean(nk.value)||S.name; nk.value=S.name; save(); Net.hello(); });
}

function renderLobby(){
  const r=Net.room; if(!r){ renderOnline(); return; }
  scene='lobby';
  const isHost=r.host===Net.id, L=LEVELS[r.level]||LEVELS[0];
  const plist=r.players.map(p=>`<div class="prow"><i style="background:${esc(p.color)}"></i><b>${esc(p.name)}${p.id===Net.id?' (ты)':''}</b><small>${p.bike==='moped'?'🛵':'🏍️'}</small>${p.id===r.host&&!r.quick?'<span>👑</span>':''}</div>`).join('')
    + Array.from({length:Math.max(0,4-r.players.length)},()=>`<div class="prow empty"><i></i><b>свободно</b></div>`).join('');
  h(`<div class="top"><button class="ic" data-a="leaveRoom">⬅</button><div class="ttl">${r.quick?'Быстрая игра':'Комната '+esc(r.code)}</div><div class="pill">💰 <b>${fmt(S.coins)}</b></div></div>
  <div class="onl">
    <div class="ocol">
      <div class="lbox"><small>Трасса</small><div class="lvsel">${isHost&&!r.quick?'<button class="ic sm" data-a="lvl" data-v="-1">◀</button>':''}<b>${esc(L.name)}</b>${isHost&&!r.quick?'<button class="ic sm" data-a="lvl" data-v="1">▶</button>':''}</div><small>${L.len} м</small></div>
      <div class="lbox"><b id="lst"></b></div>
      ${!r.quick&&isHost?'<button class="btn green big" data-a="roomStart">🏁 НАЧАТЬ ГОНКУ</button>':''}
      ${!r.quick?`<p class="hint">Код комнаты для друзей: <b class="code">${esc(r.code)}</b></p>`:''}
    </div>
    <div class="ocol plist">${plist}</div>
  </div>`);
  updateLobbyStatus();
}
function updateLobbyStatus(){
  const el=document.getElementById('lst'); const r=Net.room; if(!el||!r) return;
  const left=Math.max(0, Math.ceil((r.startIn - (performance.now()-Net.roomAt))/1000));
  if(r.state==='race') el.textContent='Гонка идёт…';
  else if(r.quick) el.textContent = r.players.length<2 ? 'Ищем соперников…' : (r.startIn ? 'Старт через '+left+' с' : 'Готовимся…');
  else el.textContent = r.host===Net.id ? (r.players.length<2?'Ждём друзей (можно начать и одному)':'Все в сборе? Жми «Начать»') : 'Ждём, когда хост начнёт гонку';
}
setInterval(()=>{ if(scene==='lobby') updateLobbyStatus(); }, 250);

function onlineClick(a, v){
  if(a==='online'){ renderOnline(); Net.connect(); return true; }
  if(a==='onlineBack'){ Net.close(); renderModes(); return true; }
  if(a==='quick'){ netDo({t:'quick'}); return true; }
  if(a==='create'){ netDo({t:'create'}); return true; }
  if(a==='join'){ const c=(document.getElementById('rcode').value||'').trim().toUpperCase(); if(c.length!==4){ toast('Введи код из 4 символов'); return true; } netDo({t:'join', code:c}); return true; }
  if(a==='leaveRoom'){ Net.send({t:'leave'}); Net.room=null; renderOnline(); return true; }
  if(a==='lvl'){ const r=Net.room; if(r) Net.send({t:'level', level:(r.level+(+v)+LEVELS.length)%LEVELS.length}); return true; }
  if(a==='roomStart'){ Net.send({t:'start'}); return true; }
  return false;
}

// ---------- race hooks ----------
const r2=v=>Math.round(v*100)/100;
function onlineTick(dt){
  const b=R.bike;
  R.sendT+=dt;
  if(R.sendT>=0.066 && !R.over){
    R.sendT=0;
    const w=b.wheels;
    Net.send({t:'st', s:[r2(b.x),r2(b.y),r2(b.a),r2(w[0].x),r2(w[0].y),r2(w[1].x),r2(w[1].y),r2(w[0].phi),r2(w[1].phi),r2(b.pose),R.rider?1:0]});
  }
  const el=document.getElementById('place');
  if(el){
    const gs=Object.values(R.ghosts), total=gs.length+1;
    const ahead=gs.filter(g=> g.fin!=null || g.x>b.x).length;
    el.textContent='Место '+(ahead+1)+' / '+total;
  }
}
function drawGhosts(ox,oy,z,cx,cy){
  const now=performance.now(), labels=[];
  for(const g of Object.values(R.ghosts)){
    const b=g.buf; if(!b.length) continue;
    const rt=now-130; let s=b[b.length-1].s;
    for(let i=b.length-1;i>0;i--){ if(b[i-1].t<=rt){ const A=b[i-1],B=b[i], k=Math.max(0,Math.min(1,(rt-A.t)/((B.t-A.t)||1))); s=A.s.map((v,j)=>v+(B.s[j]-v)*k); break; } }
    const r=g.type==='moped'?0.29:0.34;
    const st={x:s[0],y:s[1],a:s[2],wheels:[{x:s[3],y:s[4],r,phi:s[7]},{x:s[5],y:s[6],r,phi:s[8]}]};
    ctx.globalAlpha=0.55; drawBikeBody(st,g.type,g.color,s[9],!s[10],'#3a7bd5'); ctx.globalAlpha=1;
    labels.push({t:g.name, x:ox+(s[0]-cx)*z, y:oy-(s[1]+1.9-cy)*z, c:g.fin!=null?'#7CFF6B':'#fff'});
  }
  return labels;
}
function onlinePause(){
  const ov=document.createElement('div'); ov.className='ov'; ov.id='pz';
  ov.innerHTML=`<div class="dlg"><h2>Онлайн-гонка</h2><p class="hint" style="text-align:center">Гонка продолжается, пока открыто меню</p><button class="btn green" id="go">Продолжить</button><button class="btn red" id="ex">Покинуть гонку</button></div>`;
  document.body.appendChild(ov);
  ov.querySelector('#go').onclick=()=>ov.remove();
  ov.querySelector('#ex').onclick=()=>{ ov.remove(); Net.send({t:'leave'}); Net.room=null; R=null; Snd.engine(0,0,false); renderOnline(); };
}
function onlineFinish(){
  R.over=true; Snd.engine(0,0,false); R.myTime=R.t;
  if(R.netLost || Net.status!=='on'){ // сервер отвалился — засчитываем как одиночный заезд
    const rw=100; S.coins+=rw; prog('runs',1); save();
    const ov=document.createElement('div'); ov.className='ov';
    ov.innerHTML=`<div class="dlg"><h2>Финиш! 🏁</h2><div class="res"><span>Время</span><b>${R.t.toFixed(1)} с</b></div><p class="hint">Связь с сервером пропала, результат засчитан как одиночный.</p><div class="res big"><span>Награда</span><b>💰 +${rw}</b></div><button class="btn green" id="gr">В меню</button></div>`;
    document.body.appendChild(ov); ov.querySelector('#gr').onclick=()=>{ ov.remove(); R=null; Net.close(); renderOnline(); };
    return;
  }
  Net.send({t:'fin', time:r2(R.t)});
  const ov=document.createElement('div'); ov.className='ov'; ov.id='wait';
  ov.innerHTML=`<div class="dlg"><h2>Финиш! 🏁</h2><div class="res"><span>Твоё время</span><b>${R.t.toFixed(1)} с</b></div><div id="wl"></div><p class="hint" style="text-align:center">Ждём остальных (до 45 сек)…</p></div>`;
  document.body.appendChild(ov); updateWaitList();
}
function updateWaitList(){
  const el=document.getElementById('wl'); if(!el||!R) return;
  el.innerHTML=Object.values(R.ghosts).map(g=>`<div class="res"><span>${esc(g.name)}</span><b>${g.fin!=null?g.fin.toFixed(1)+' с':'едет… '+Math.max(0,Math.round(g.x/R.finishX*100))+'%'}</b></div>`).join('');
}
setInterval(()=>{ if(R && R.mode==='online' && R.over) updateWaitList(); }, 500);

function showOnlineResults(m){
  document.querySelectorAll('.ov').forEach(o=>o.remove());
  if(R && R.mode==='online'){ R.over=true; Snd.engine(0,0,false); }
  const me=m.list.find(e=>e.id===Net.id);
  let reward=0;
  if(me){ reward = m.count>=2 ? (me.time!=null ? PLACE_REWARD[me.place-1]||50 : 30) : (me.time!=null?100:20); S.coins+=reward; prog('runs',1); save(); }
  const medal=['🥇','🥈','🥉','4️⃣'];
  const rows=m.list.map(e=>`<div class="res ${e.id===Net.id?'me':''}"><span>${medal[e.place-1]||e.place} ${esc(e.name)}${e.id===Net.id?' (ты)':''}</span><b>${e.time!=null?e.time.toFixed(1)+' с':'не доехал'}</b></div>`).join('');
  const ov=document.createElement('div'); ov.className='ov';
  ov.innerHTML=`<div class="dlg"><h2>${me&&me.place===1&&m.count>1?'Победа! 🏆':'Результаты'}</h2>${rows}
    <div class="res big"><span>Награда</span><b>💰 +${reward}</b></div>
    <div class="brow"><button class="btn green" id="lb">В лобби</button><button class="btn" id="ex">Выйти</button></div></div>`;
  document.body.appendChild(ov);
  if(me&&me.place===1&&m.count>1){ Snd.blip(523,0.15); setTimeout(()=>Snd.blip(659,0.15),150); setTimeout(()=>Snd.blip(784,0.35),300); }
  ov.querySelector('#lb').onclick=()=>{ ov.remove(); R=null; if(Net.room) renderLobby(); else renderOnline(); };
  ov.querySelector('#ex').onclick=()=>{ ov.remove(); R=null; Net.send({t:'leave'}); Net.close(); renderGarage(); };
}
