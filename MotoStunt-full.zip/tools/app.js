// ===APP===
const BIKES=[
  {id:'delta', name:'Дельта',      type:'moped',  price:0,     power:1.0, vmax:15, mass:85,  grip:1.00, hp:4.3,  color:'#b8322a', tier:0},
  {id:'minsk', name:'Минск Кросс', type:'dirt',   price:3000,  power:1.9, vmax:22, mass:100, grip:1.15, hp:12.0, color:'#e6e6e6', tier:1},
  {id:'taifun',name:'Тайфун 450',  type:'enduro', price:12000, power:2.5, vmax:30, mass:105, grip:1.30, hp:38.0, color:'#ff7a00', tier:2}
];
const UPG=[
  {id:'engine',name:'Двигатель',icon:'⚙️',desc:'+мощность и скорость'},
  {id:'wheels',name:'Колёса',icon:'⭕',desc:'+сцепление с землёй'},
  {id:'susp',  name:'Подвеска',icon:'🔩',desc:'мягче приземления'},
  {id:'frame', name:'Рама',    icon:'🔧',desc:'−вес, +вращение в воздухе'}
];
const MAXLVL=6;
const COLORS=['#b8322a','#1f6fd1','#2aa84a','#f2b705','#7b3fd1','#16191f','#e6e6e6','#ff7a00','#ff4fa3','#19c3c9'];
const LEVELS=[
  {name:'Лесная тропа',  theme:'forest',len:450, diff:0.6, seed:11,reward:250},
  {name:'Карьер',        theme:'quarry',len:650, diff:0.95,seed:23,reward:450},
  {name:'Зелёные холмы', theme:'hills', len:850, diff:1.25,seed:37,reward:700},
  {name:'Горный перевал',theme:'mount', len:1050,diff:1.55,seed:51,reward:1100},
  {name:'Ночной хардкор',theme:'night', len:1250,diff:1.9, seed:73,reward:1700}
];
const THEMES={
  forest:{sky:['#6fbef5','#d6efff'],far:'#86b3a6',near:'#4f8a5a',ground:'#6b4a2b',top:'#4caf50',deco:'tree'},
  quarry:{sky:['#f0b97a','#fbe3c4'],far:'#c99a6b',near:'#a87650',ground:'#8a5a35',top:'#c48a55',deco:'rock'},
  hills: {sky:['#82cdfb','#eaf8ff'],far:'#a4cfa0',near:'#6aa86a',ground:'#5b4026',top:'#7cc657',deco:'tree'},
  mount: {sky:['#93b0d6','#eef2f7'],far:'#8a96a8',near:'#5f6b7d',ground:'#4a4038',top:'#eef3f6',deco:'pine'},
  night: {sky:['#070d24','#262d58'],far:'#1d2647',near:'#141a31',ground:'#2a2018',top:'#3b6b3b',deco:'pine',stars:1},
  city:  {sky:['#27397a','#d97a8c'],far:'#2b2f55',near:'#1c1f3a',ground:'#3a3a44',top:'#a7adb7',deco:'city'}
};
const TASKS={
  dist:   {t:n=>`Проехать ${n} м`,              base:1500,mul:1.7,rw:150},
  flips:  {t:n=>`Сделать ${n} сальто`,           base:3,   mul:1.6,rw:220},
  runs:   {t:n=>`Завершить ${n} заезда`,         base:3,   mul:1.5,rw:150},
  wheelie:{t:n=>`Вилли на заднем колесе ${n} с`, base:8,   mul:1.6,rw:200},
  coins:  {t:n=>`Собрать ${n} монет на трассе`,  base:15,  mul:1.6,rw:160},
  air:    {t:n=>`Провести в воздухе ${n} с`,     base:12,  mul:1.6,rw:180}
};
const STUNT_TIME=90;

// ---------- save ----------
const SAVE_KEY='motostunt_v1';
function defSave(){ return {coins:400, cur:'delta', owned:{delta:{engine:0,wheels:0,susp:0,frame:0,color:0}}, lvl:{}, stuntBest:0, tl:{}, tasks:[], sound:true, name:'Гонщик'+Math.floor(100+Math.random()*900), server:''}; }
let S=defSave();
try{ const raw=localStorage.getItem(SAVE_KEY); if(raw) S=Object.assign(defSave(), JSON.parse(raw)); }catch(e){}
function save(){ try{ localStorage.setItem(SAVE_KEY, JSON.stringify(S)); }catch(e){} }
function taskTarget(k){ const d=TASKS[k], l=S.tl[k]||0; return Math.round(d.base*Math.pow(d.mul,l)); }
function taskReward(k){ return Math.round(TASKS[k].rw*(1+0.5*(S.tl[k]||0))/10)*10; }
function fillTasks(){
  const keys=Object.keys(TASKS);
  while(S.tasks.length<3){
    const free=keys.filter(k=>!S.tasks.some(t=>t.k===k));
    const k=free[Math.floor(Math.random()*free.length)];
    S.tasks.push({k, p:0});
  }
}
fillTasks(); save();
function prog(k, v){ for(const t of S.tasks) if(t.k===k) t.p=Math.min(taskTarget(k), t.p+v); }
function tasksReady(){ return S.tasks.filter(t=>t.p>=taskTarget(t.k)).length; }

const bikeIdx=id=>BIKES.findIndex(b=>b.id===id);
const curBike=()=>BIKES[bikeIdx(S.cur)];
const curUp=()=>S.owned[S.cur];
function upCost(bi, lvl){ return Math.round((140+bi*260)*Math.pow(lvl+1,1.75)/10)*10; }
function fmt(n){ n=Math.round(n); return n>=10000 ? (n/1000).toFixed(1).replace('.0','')+'K' : String(n); }

// ---------- sound ----------
const Snd={ctx:null,osc:null,g:null,
  init(){ if(this.ctx) return; try{ const C=window.AudioContext||window.webkitAudioContext; const c=new C(); const o=c.createOscillator(); o.type='sawtooth';
    const o2=c.createOscillator(); o2.type='square'; const f=c.createBiquadFilter(); f.type='lowpass'; f.frequency.value=650; const g=c.createGain(); g.gain.value=0;
    const g2=c.createGain(); g2.gain.value=0.35; o.connect(f); o2.connect(g2); g2.connect(f); f.connect(g); g.connect(c.destination); o.start(); o2.start();
    this.ctx=c; this.osc=o; this.osc2=o2; this.g=g; }catch(e){} },
  engine(rpm, gas, on){ if(!this.ctx) return; const t=this.ctx.currentTime; const f=38+rpm*150+gas*12;
    this.osc.frequency.setTargetAtTime(f,t,0.04); this.osc2.frequency.setTargetAtTime(f*0.5,t,0.04);
    this.g.gain.setTargetAtTime(on&&S.sound ? 0.035+gas*0.035 : 0, t, 0.06); },
  blip(freq, dur, type){ if(!this.ctx||!S.sound) return; try{ const c=this.ctx, o=c.createOscillator(), g=c.createGain(); o.type=type||'square'; o.frequency.value=freq;
    g.gain.setValueAtTime(0.08,c.currentTime); g.gain.exponentialRampToValueAtTime(0.0001,c.currentTime+dur); o.connect(g); g.connect(c.destination); o.start(); o.stop(c.currentTime+dur);}catch(e){} }
};
document.addEventListener('pointerdown',()=>{ Snd.init(); if(Snd.ctx&&Snd.ctx.state==='suspended') Snd.ctx.resume(); },{passive:true});

// ---------- canvas ----------
const cv=document.getElementById('c'), ctx=cv.getContext('2d');
let W=0,H=0,DPR=1;
function resize(){ DPR=Math.min(2, window.devicePixelRatio||1); W=window.innerWidth; H=window.innerHeight; cv.width=W*DPR; cv.height=H*DPR; cv.style.width=W+'px'; cv.style.height=H+'px'; }
window.addEventListener('resize', resize); resize();

// ---------- drawing: bike & rider ----------
function shade(hex, k){ const n=parseInt(hex.slice(1),16); let r=n>>16,g=n>>8&255,b=n&255; const f=v=>Math.max(0,Math.min(255,Math.round(k<0? v*(1+k) : v+(255-v)*k)));
  return '#'+((1<<24)|(f(r)<<16)|(f(g)<<8)|f(b)).toString(16).slice(1); }
function L(x1,y1,x2,y2,w,c){ ctx.strokeStyle=c; ctx.lineWidth=w; ctx.beginPath(); ctx.moveTo(x1,y1); ctx.lineTo(x2,y2); ctx.stroke(); }
function poly(pts, fill, stroke, lw){ ctx.beginPath(); ctx.moveTo(pts[0],pts[1]); for(let i=2;i<pts.length;i+=2) ctx.lineTo(pts[i],pts[i+1]); ctx.closePath();
  if(fill){ctx.fillStyle=fill; ctx.fill();} if(stroke){ctx.strokeStyle=stroke; ctx.lineWidth=lw||0.025; ctx.stroke();} }
function circ(x,y,r,fill,stroke,lw){ ctx.beginPath(); ctx.arc(x,y,r,0,Math.PI*2); if(fill){ctx.fillStyle=fill;ctx.fill();} if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=lw||0.03;ctx.stroke();} }

function drawWheel(x,y,r,phi,type){
  circ(x,y,r,'#15161a');
  if(type!=='moped'){ ctx.save(); ctx.translate(x,y); ctx.rotate(phi); ctx.fillStyle='#2a2b30'; for(let i=0;i<14;i++){ ctx.rotate(Math.PI/7); ctx.fillRect(r-0.035,-0.025,0.05,0.05);} ctx.restore(); }
  circ(x,y,r*0.72,'#3a3d44'); circ(x,y,r*0.66,'#1d1f24');
  ctx.save(); ctx.translate(x,y); ctx.rotate(phi);
  if(type==='moped'){ for(let i=0;i<5;i++){ ctx.rotate(Math.PI*2/5); L(0,0,r*0.64,0,0.045,'#9aa0aa'); } }
  else { for(let i=0;i<12;i++){ ctx.rotate(Math.PI/6); L(0,0,r*0.65,0.02,0.012,'#b9bec7'); } }
  ctx.restore();
  circ(x,y,r*0.16,'#c9ced6','#55595f',0.02);
}

function drawRider(type, pose, helmet){
  const moped=type==='moped';
  const hip = moped?[-0.26,0.36]:[-0.22,0.5];
  const peg = moped?[0.05,-0.1]:[-0.08,-0.06];
  const bar = moped?[0.4,0.52]:[0.36,0.66];
  const sh=[hip[0]+0.2+pose*0.2, hip[1]+0.5-Math.abs(pose)*0.1];
  const head=[sh[0]+0.07+pose*0.05, sh[1]+0.2];
  const knee=[(hip[0]+peg[0])/2+0.2, (hip[1]+peg[1])/2+0.12];
  ctx.lineCap='round'; ctx.lineJoin='round';
  // leg
  L(hip[0],hip[1],knee[0],knee[1],0.13,'#2f5f9e'); L(knee[0],knee[1],peg[0],peg[1],0.11,'#2f5f9e');
  poly([peg[0]-0.04,peg[1]-0.05, peg[0]+0.13,peg[1]-0.05, peg[0]+0.12,peg[1]+0.03, peg[0]-0.03,peg[1]+0.04],'#c8352b');
  // torso
  L(hip[0],hip[1],sh[0],sh[1],0.2,'#eef0f4');
  // arm
  const el=[(sh[0]+bar[0])/2+0.02,(sh[1]+bar[1])/2-0.08];
  L(sh[0],sh[1],el[0],el[1],0.09,'#eef0f4'); L(el[0],el[1],bar[0],bar[1],0.07,'#e2b48f');
  circ(bar[0],bar[1],0.045,'#e2b48f');
  // head
  circ(head[0],head[1],0.15,helmet||'#222');
  ctx.beginPath(); ctx.arc(head[0]+0.02,head[1],0.15,-0.6,0.5); ctx.lineTo(head[0]+0.02,head[1]); ctx.closePath(); ctx.fillStyle='#1b2433'; ctx.fill();
  L(head[0]-0.13,head[1]+0.03,head[0]+0.1,head[1]+0.1,0.03,'rgba(255,255,255,.55)');
}

function drawBikeBody(st, type, col, pose, rider, helmet){
  ctx.save(); ctx.translate(st.x,st.y); ctx.rotate(st.a); ctx.lineCap='round'; ctx.lineJoin='round';
  const ca=Math.cos(st.a), sa=Math.sin(st.a);
  const loc=w=>{const dx=w.x-st.x, dy=w.y-st.y; return [dx*ca+dy*sa, -dx*sa+dy*ca];};
  const R=loc(st.wheels[0]), F=loc(st.wheels[1]);
  const r=st.wheels[0].r, dark=shade(col,-0.35), lite=shade(col,0.25);
  const moped=type==='moped';
  const head = moped?[0.4,0.32]:[0.38,0.42];
  const piv = moped?[-0.1,-0.18]:[-0.14,-0.14];
  // swingarm
  L(piv[0],piv[1],R[0],R[1],0.07,'#2a2c31'); L(piv[0],piv[1]+0.05,R[0],R[1]+0.05,0.02,'#555a62');
  drawWheel(R[0],R[1],r,st.wheels[0].phi-st.a,type);
  drawWheel(F[0],F[1],r,st.wheels[1].phi-st.a,type);
  // fork
  L(head[0],head[1],F[0],F[1],0.075,'#3a3d44'); L(head[0]-0.02,head[1]-0.05,(head[0]+F[0])/2,(head[1]+F[1])/2,0.05,'#c9ced6');
  if(moped){
    // step-through frame
    ctx.strokeStyle=col; ctx.lineWidth=0.11; ctx.beginPath(); ctx.moveTo(head[0],head[1]); ctx.quadraticCurveTo(0.1,-0.22,-0.2,-0.12); ctx.lineTo(-0.38,0.14); ctx.stroke();
    poly([-0.22,-0.24, 0.12,-0.24, 0.14,-0.04, -0.2,-0.02],'#4a4e56','#2a2c31');       // engine
    circ(-0.05,-0.13,0.06,'#6c717a');
    L(0.0,-0.2,-0.62,-0.22,0.05,'#b9bec7');                                            // exhaust
    poly([-0.55,0.15, -0.05,0.15, -0.02,0.23, -0.52,0.25],'#4a2a1f');                  // seat
    poly([-0.75,0.13,-0.45,0.13,-0.45,0.17,-0.78,0.17],'#2a2c31');                      // rack
    ctx.strokeStyle=dark; ctx.lineWidth=0.04; ctx.beginPath(); ctx.arc(R[0],R[1],r+0.06,Math.PI*0.25,Math.PI*0.95); ctx.stroke();
    ctx.beginPath(); ctx.arc(F[0],F[1],r+0.06,Math.PI*0.15,Math.PI*0.75); ctx.stroke();
    poly([head[0]-0.05,head[1]+0.02, head[0]+0.12,head[1]+0.02, head[0]+0.14,head[1]+0.14, head[0]-0.04,head[1]+0.12], lite, dark);
    circ(head[0]+0.16,head[1]+0.06,0.045,'#ffe9a8','#888',0.015);
    L(head[0]-0.02,head[1]+0.14,0.42,0.54,0.035,'#2a2c31');
    poly([-0.86,0.1,-0.78,0.1,-0.78,0.17,-0.86,0.17],'#ff3b2f');
  } else {
    const enduro=type==='enduro';
    L(head[0],head[1],-0.3,0.32,0.07,'#2a2c31'); L(head[0]-0.02,head[1]-0.04,-0.02,-0.12,0.07,'#2a2c31'); L(-0.3,0.32,piv[0],piv[1],0.06,'#2a2c31');
    poly([-0.18,-0.28, 0.16,-0.28, 0.2,0.02, -0.16,0.06],'#3e424a','#22242a');        // engine
    for(let i=0;i<4;i++) L(-0.12,-0.2+i*0.06,0.14,-0.2+i*0.06,0.012,'#6c717a');
    ctx.strokeStyle='#b9bec7'; ctx.lineWidth=0.05; ctx.beginPath(); ctx.moveTo(0.14,-0.1); ctx.quadraticCurveTo(0.05,0.12,-0.3,0.2); ctx.lineTo(-0.7,0.3); ctx.stroke();
    poly([-0.72,0.27,-0.55,0.27,-0.55,0.35,-0.72,0.35],'#30333a');
    poly([0.02,0.34, 0.38,0.4, 0.36,0.52, 0.0,0.5],col,dark);                           // tank
    poly([-0.62,0.4, 0.06,0.48, 0.05,0.53, -0.62,0.47],'#1b1d22');                      // seat
    poly([-0.35,0.36, -0.95,0.48, -0.92,0.53, -0.3,0.44],col,dark);                     // rear fender
    poly([-0.12,0.08, 0.12,0.12, 0.08,0.36, -0.2,0.34],lite,dark);                      // side panel
    ctx.fillStyle=dark; ctx.font='bold 0.13px sans-serif';
    ctx.save(); ctx.translate(-0.12,0.16); ctx.scale(1,-1); ctx.fillText(enduro?'450':'125',0,0); ctx.restore();
    poly([head[0]+0.02,head[1]-0.02, head[0]+0.52,head[1]-0.12, head[0]+0.48,head[1]-0.04, head[0]+0.04,head[1]+0.06],col,dark); // front fender
    if(enduro){ poly([head[0]+0.02,head[1]+0.04, head[0]+0.16,head[1]+0.02, head[0]+0.18,head[1]+0.22, head[0]+0.03,head[1]+0.24],col,dark); circ(head[0]+0.12,head[1]+0.12,0.05,'#ffe9a8','#555',0.015); }
    else poly([head[0]+0.0,head[1]+0.02, head[0]+0.12,head[1]+0.0, head[0]+0.13,head[1]+0.18, head[0]+0.01,head[1]+0.2],'#f4f4f4','#333');
    L(head[0]-0.02,head[1]+0.18,0.36,0.66,0.035,'#2a2c31');
  }
  if(rider) drawRider(type,pose,helmet);
  ctx.restore();
}

// fake static state for garage preview
function restState(p, x, y){ const st={x,y,a:0,wheels:[]}; p.anch.forEach(([lx,ly])=>st.wheels.push({x:x+lx,y:y+ly-0.05,r:p.r,phi:0})); return st; }

// ---------- backgrounds ----------
function hash(n){ n=(n<<13)^n; return ((n*(n*n*15731+789221)+1376312589)&0x7fffffff)/0x7fffffff; }
function ridge(x, s){ return Math.sin(x*0.011+s)*0.5+Math.sin(x*0.027+s*2.1)*0.3+Math.sin(x*0.06+s*3.7)*0.2; }
function drawSky(th, camX){
  const g=ctx.createLinearGradient(0,0,0,H); g.addColorStop(0,th.sky[0]); g.addColorStop(1,th.sky[1]); ctx.fillStyle=g; ctx.fillRect(0,0,W,H);
  if(th.stars){ ctx.fillStyle='#fff'; for(let i=0;i<70;i++){ const x=(hash(i)*W*1.5 - camX*2)%W; ctx.globalAlpha=0.3+hash(i+99)*0.7; ctx.fillRect((x+W)%W, hash(i+7)*H*0.6, 2,2);} ctx.globalAlpha=1;
    circ(W*0.8,H*0.18,H*0.06,'#f4f1da'); }
  else if(th.deco!=='city'){ circ(W*0.82,H*0.16,H*0.07,'rgba(255,250,220,.9)'); }
  if(th.deco==='city'){
    for(let layer=0;layer<2;layer++){
      const f=layer?0.35:0.15, base=H*(layer?0.78:0.66), col=layer?th.near:th.far, off=camX*f*20;
      const bw=layer?70:50; const i0=Math.floor(off/bw)-1;
      for(let i=i0;i<i0+W/bw+3;i++){ const bh=(0.15+hash(i*3+layer)*0.35)*H; const x=i*bw-off;
        ctx.fillStyle=col; ctx.fillRect(x,base-bh,bw-6,bh+H);
        if(layer){ ctx.fillStyle='rgba(255,220,140,.55)'; for(let wy=base-bh+10;wy<base-10;wy+=16) for(let wx=x+8;wx<x+bw-14;wx+=14) if(hash(i*97+wy*3+wx)>0.55) ctx.fillRect(wx,wy,6,8); }
      }
    }
    return;
  }
  for(let layer=0;layer<2;layer++){
    const f=layer?0.3:0.12, base=H*(layer?0.72:0.6), amp=H*(layer?0.12:0.18), off=camX*f*25;
    ctx.fillStyle=layer?th.near:th.far; ctx.beginPath(); ctx.moveTo(0,H);
    for(let x=0;x<=W+10;x+=10) ctx.lineTo(x, base-amp*(0.5+0.5*ridge(x+off, layer*5+1)));
    ctx.lineTo(W,H); ctx.closePath(); ctx.fill();
    if(th.deco==='mount' && !layer){}
  }
}

// ---------- UI helpers ----------
const ui=document.getElementById('ui');
let scene='garage', tab='upg', R=null; // R = race
function h(s){ ui.innerHTML=s; }
function topbar(title){ return `<div class="top"><div class="pill">💰 <b>${fmt(S.coins)}</b></div><div class="ttl">${title||''}</div><button class="ic" data-a="settings">⚙️</button></div>`; }

function renderGarage(){
  scene='garage';
  const B=curBike(), bi=bikeIdx(S.cur), up=curUp(), p=makeParams(B,up);
  let body='';
  if(tab==='upg'){
    body=UPG.map(u=>{ const l=up[u.id]||0, max=l>=MAXLVL, c=upCost(bi,l);
      return `<div class="row"><div class="ricon">${u.icon}</div><div class="rmid"><b>${u.name}</b><small>${u.desc}</small>
      <div class="dots">${Array.from({length:MAXLVL},(_,i)=>`<i class="${i<l?'on':''}"></i>`).join('')}</div></div>
      <button class="buy ${max||S.coins<c?'dis':''}" data-a="up" data-v="${u.id}">${max?'МАКС':'💰 '+fmt(c)}</button></div>`; }).join('');
  } else if(tab==='bikes'){
    body=BIKES.map((b,i)=>{ const own=!!S.owned[b.id], sel=S.cur===b.id;
      return `<div class="row ${sel?'sel':''}"><div class="ricon">${b.type==='moped'?'🛵':'🏍️'}</div><div class="rmid"><b>${b.name}</b><small>${b.hp} л.с. · ${Math.round(b.vmax*3.6)} км/ч · ${b.mass} кг</small></div>
      ${sel?'<span class="tag">В ГАРАЖЕ</span>': own?`<button class="buy" data-a="sel" data-v="${b.id}">ВЫБРАТЬ</button>`:`<button class="buy ${S.coins<b.price?'dis':''}" data-a="buyb" data-v="${b.id}">💰 ${fmt(b.price)}</button>`}</div>`; }).join('');
  } else if(tab==='paint'){
    body=`<p class="hint">Покраска — 💰 100</p><div class="colors">${COLORS.map((c,i)=>`<button class="sw ${up.color===i+1?'on':''}" style="background:${c}" data-a="paint" data-v="${i+1}"></button>`).join('')}
      <button class="sw def ${!up.color?'on':''}" data-a="paint" data-v="0">↺</button></div>`;
  } else if(tab==='tasks'){
    body=S.tasks.map((t,i)=>{ const tg=taskTarget(t.k), done=t.p>=tg;
      return `<div class="row"><div class="rmid"><b>${TASKS[t.k].t(tg)}</b><div class="bar"><i style="width:${Math.min(100,t.p/tg*100)}%"></i><span>${(Math.round(t.p*10)/10)}/${tg}</span></div></div>
      <button class="buy ${done?'':'dis'}" data-a="claim" data-v="${i}">${done?'ЗАБРАТЬ':''} 💰${taskReward(t.k)}</button></div>`; }).join('');
  }
  const stat=(n,v,f)=>`<div class="st"><span>${n}</span><div class="sb"><i style="width:${Math.min(100,f*100)}%"></i></div><b>${v}</b></div>`;
  const hp=(B.hp*(1+0.13*(up.engine||0))).toFixed(1);
  h(topbar(B.name)+`
  <div class="stats">
    ${stat('Мощность',hp+' л.с.',p.T/(230*3.6))}
    ${stat('Скорость',Math.round(p.vmax*3.6)+' км/ч',p.vmax/38)}
    ${stat('Вес',Math.round(p.M-65)+' кг',1-(p.M-100)/80)}
    ${stat('Сцепление',Math.round(p.mu*100)+'%',p.mu/2)}
  </div>
  <div class="panel">
    <div class="tabs">
      <button class="${tab==='upg'?'on':''}" data-a="tab" data-v="upg">Тюнинг</button>
      <button class="${tab==='bikes'?'on':''}" data-a="tab" data-v="bikes">Мотоциклы</button>
      <button class="${tab==='paint'?'on':''}" data-a="tab" data-v="paint">Покраска</button>
      <button class="${tab==='tasks'?'on':''}" data-a="tab" data-v="tasks">Задания${tasksReady()?`<em>${tasksReady()}</em>`:''}</button>
    </div>
    <div class="tb">${body}</div>
  </div>
  <button class="start" data-a="modes">СТАРТ</button>`);
}

function renderModes(){
  scene='modes';
  const lv=LEVELS.map((L,i)=>{ const st=S.lvl[i], open=i===0||(S.lvl[i-1]&&S.lvl[i-1].done);
    return `<button class="card ${open?'':'lock'}" data-a="${open?'enduro':''}" data-v="${i}" style="--c1:${THEMES[L.theme].sky[0]};--c2:${THEMES[L.theme].near}">
      <div class="cimg"><span>${open?'🏁':'🔒'}</span></div><b>${L.name}</b><small>Эндуро · ${L.len} м</small>
      <small>${st&&st.best?'Рекорд: '+st.best.toFixed(1)+' с':'Награда: 💰'+L.reward}</small></button>`; }).join('');
  h(`<div class="top"><button class="ic" data-a="garage">⬅</button><div class="ttl">Выбор заезда</div><div class="pill">💰 <b>${fmt(S.coins)}</b></div></div>
  <div class="cards">
    <button class="card online" data-a="online" style="--c1:#0f9b8e;--c2:#3b4fa3"><div class="cimg"><span>👥</span></div><b>Онлайн-гонка</b><small>2–4 игрока · живые соперники</small><small>Награда: до 💰400</small></button>
    <button class="card stunt" data-a="stunt" style="--c1:#27397a;--c2:#d97a8c"><div class="cimg"><span>🤸</span></div><b>Стант-парк</b><small>Трюки · ${STUNT_TIME} сек</small><small>Рекорд: ${fmt(S.stuntBest)}</small></button>
    ${lv}
  </div>`);
}

function openSettings(){
  const prev=scene;
  const ov=document.createElement('div'); ov.className='ov';
  ov.innerHTML=`<div class="dlg"><h2>Настройки</h2>
    <button class="btn" id="snd">Звук: ${S.sound?'ВКЛ':'ВЫКЛ'}</button>
    <label class="lbl">Ник<input id="snick" maxlength="16" value="${esc(S.name)}"></label>
    <label class="lbl">Сервер мультиплеера<input id="ssrv" placeholder="${esc(DEFAULT_SERVER)}" value="${esc(S.server)}" autocapitalize="off" autocorrect="off" spellcheck="false"></label>
    <p class="hint">Управление: ГАЗ / ТОРМОЗ справа, наклон ◀ ▶ слева. В воздухе газ = наклон назад, тормоз = вперёд.</p>
    <button class="btn red" id="rst">Сбросить прогресс</button>
    <button class="btn green" id="cls">Закрыть</button></div>`;
  document.body.appendChild(ov);
  ov.querySelector('#snd').onclick=()=>{ S.sound=!S.sound; save(); ov.querySelector('#snd').textContent='Звук: '+(S.sound?'ВКЛ':'ВЫКЛ'); };
  ov.querySelector('#rst').onclick=()=>{ if(ov.dataset.c){ S=defSave(); fillTasks(); save(); ov.remove(); renderGarage(); } else { ov.dataset.c=1; ov.querySelector('#rst').textContent='Точно? Нажми ещё раз'; } };
  ov.querySelector('#cls').onclick=()=>{ S.name=clean(ov.querySelector('#snick').value)||S.name; S.server=ov.querySelector('#ssrv').value.trim(); save(); if(Net.status==='on') Net.hello(); ov.remove(); if(prev==='garage') renderGarage(); };
}

function toast(msg){ const t=document.createElement('div'); t.className='toast'; t.textContent=msg; document.body.appendChild(t); setTimeout(()=>t.remove(),1800); }

ui.addEventListener('click', e=>{
  const b=e.target.closest('[data-a]'); if(!b) return; const a=b.dataset.a, v=b.dataset.v;
  const bi=bikeIdx(S.cur), up=curUp();
  if(a==='tab'){ tab=v; renderGarage(); }
  else if(a==='settings') openSettings();
  else if(a==='up'){ const l=up[v]||0, c=upCost(bi,l); if(l>=MAXLVL) return; if(S.coins<c){ toast('Не хватает монет'); return; } S.coins-=c; up[v]=l+1; save(); Snd.blip(660,0.12); renderGarage(); }
  else if(a==='sel'){ S.cur=v; save(); renderGarage(); }
  else if(a==='buyb'){ const B=BIKES[bikeIdx(v)]; if(S.coins<B.price){ toast('Не хватает монет'); return; } S.coins-=B.price; S.owned[v]={engine:0,wheels:0,susp:0,frame:0,color:0}; S.cur=v; save(); Snd.blip(880,0.2); renderGarage(); }
  else if(a==='paint'){ const c=+v; if(up.color===c) return; if(S.coins<100){ toast('Не хватает монет'); return; } S.coins-=100; up.color=c; save(); renderGarage(); }
  else if(a==='claim'){ const t=S.tasks[+v]; if(!t||t.p<taskTarget(t.k)) return; S.coins+=taskReward(t.k); S.tl[t.k]=(S.tl[t.k]||0)+1; S.tasks.splice(+v,1); fillTasks(); save(); Snd.blip(990,0.25); renderGarage(); }
  else if(a==='modes') renderModes();
  else if(a==='garage') renderGarage();
  else if(a==='stunt') startRace('stunt');
  else if(a==='enduro') startRace('enduro', +v);
  else if(onlineClick(a,v,b)) {}
});

// ---------- race ----------
const input={gas:false,brake:false,lean:0};
const keys={};
window.addEventListener('keydown',e=>{keys[e.code]=true; updKeys();}); window.addEventListener('keyup',e=>{keys[e.code]=false; updKeys();});
function updKeys(){ input.gas=!!(keys.ArrowUp||keys.KeyW)||btn.gas; input.brake=!!(keys.ArrowDown||keys.KeyS)||btn.brake; input.lean=((keys.ArrowLeft||keys.KeyA||btn.back)?1:0)-((keys.ArrowRight||keys.KeyD||btn.fwd)?1:0); }
const btn={};

function bikeColor(){ const up=curUp(); return up.color? COLORS[up.color-1] : curBike().color; }

function startRace(mode, li){
  const B=curBike(), p=makeParams(B,curUp());
  R={mode, li, p, t:0, over:false, paused:false, crashT:0, crashes:0, coinsGot:0, score:0, combo:1, comboT:0,
     air:0, rot:0, lastA:0, wheelie:0, stoppie:0, pops:[], parts:[], cam:{x:0,y:0,z:H/10}, maxX:0, rider:null, startDelay:0.6, ghosts:{}, sendT:0};
  if(mode!=='stunt'){ const Lv=LEVELS[li]; const g=genEnduro(Lv.len,Lv.diff,Lv.seed); Object.assign(R,{T:g.T,coins:g.coins,cps:g.cps,finishX:g.finishX,theme:THEMES[Lv.theme],cp:0,name:Lv.name}); }
  else { const g=StuntGen((Math.random()*1e9)|0); g.ensure(0); Object.assign(R,{gen:g,T:g.T,coins:[],cps:[],finishX:1e9,theme:THEMES.city,cp:0,name:'Стант-парк'}); }
  R.bike=new Bike(p,0,0); R.bike.place(0,R.T); R.cam.x=R.bike.x; R.cam.y=R.bike.y;
  scene='race'; Object.keys(btn).forEach(k=>btn[k]=false); updKeys();
  h(`<div class="hud">
      <button class="ic sm" data-r="pause">❚❚</button>
      <div class="hmid">${mode!=='stunt'?'<div class="prog"><i id="pg"></i></div>':'<div id="sc" class="score">0</div>'}<div id="hinfo" class="hinfo"></div>${mode==='online'?'<div id="place" class="place"></div>':''}</div>
      <div class="spd"><b id="spd">0</b><small>км/ч</small></div>
    </div>
    <div class="ctl left"><button class="cb" data-k="back">⟲</button><button class="cb" data-k="fwd">⟳</button></div>
    <div class="ctl right"><button class="cb brake" data-k="brake">ТОРМОЗ</button><button class="cb gas" data-k="gas">ГАЗ</button></div>`);
  ui.querySelectorAll('.cb').forEach(el=>{
    const k=el.dataset.k;
    const on=e=>{ e.preventDefault(); btn[k]=true; el.classList.add('p'); updKeys(); try{el.setPointerCapture(e.pointerId);}catch(_){} };
    const off=e=>{ btn[k]=false; el.classList.remove('p'); updKeys(); };
    el.addEventListener('pointerdown',on); el.addEventListener('pointerup',off); el.addEventListener('pointercancel',off); el.addEventListener('lostpointercapture',off);
  });
  ui.querySelector('[data-r=pause]').onclick=()=>pause();
}

function pause(){
  if(!R||R.over) return;
  if(R.mode==='online'){ onlinePause(); return; } R.paused=true; Snd.engine(0,0,false);
  const ov=document.createElement('div'); ov.className='ov'; ov.id='pz';
  ov.innerHTML=`<div class="dlg"><h2>Пауза</h2><button class="btn green" id="go">Продолжить</button><button class="btn" id="rs">Заново</button><button class="btn red" id="ex">В гараж</button></div>`;
  document.body.appendChild(ov);
  ov.querySelector('#go').onclick=()=>{ ov.remove(); R.paused=false; };
  ov.querySelector('#rs').onclick=()=>{ ov.remove(); startRace(R.mode,R.li); };
  ov.querySelector('#ex').onclick=()=>{ ov.remove(); exitRace(); };
}
function exitRace(){ if(R && R.mode==='stunt' && !R.over){} R=null; Snd.engine(0,0,false); save(); renderGarage(); }

function pop(text, col){ if(R) R.pops.push({text, col:col||'#ffe14d', t:0}); }

function endRace(finished){
  if(R.over) return;
  if(R.mode==='online'){ onlineFinish(); return; } R.over=true; Snd.engine(0,0,false);
  let reward=0, lines='';
  if(R.mode==='enduro'){
    const Lv=LEVELS[R.li], st=S.lvl[R.li]||{done:false,best:0};
    const first=!st.done;
    reward=Math.round((first?Lv.reward:Lv.reward*0.35) + R.coinsGot*5 - R.crashes*Lv.reward*0.04); reward=Math.max(Math.round(Lv.reward*0.15),reward);
    const rec=!st.best||R.t<st.best;
    if(rec) st.best=R.t; st.done=true; S.lvl[R.li]=st;
    lines=`<div class="res"><span>Время</span><b>${R.t.toFixed(1)} с ${rec?'<em>РЕКОРД!</em>':''}</b></div>
      <div class="res"><span>Монеты на трассе</span><b>${R.coinsGot}</b></div><div class="res"><span>Аварии</span><b>${R.crashes}</b></div>`;
  } else {
    reward=Math.round(R.score/20);
    const rec=R.score>S.stuntBest; if(rec) S.stuntBest=Math.round(R.score);
    lines=`<div class="res"><span>Очки</span><b>${fmt(R.score)} ${rec?'<em>РЕКОРД!</em>':''}</b></div><div class="res"><span>Аварии</span><b>${R.crashes}</b></div>`;
  }
  prog('runs',1); S.coins+=reward; save();
  const next = R.mode==='enduro' && R.li<LEVELS.length-1;
  const ov=document.createElement('div'); ov.className='ov';
  ov.innerHTML=`<div class="dlg"><h2>${R.mode==='enduro'?'Финиш! 🏁':'Время вышло!'}</h2>${lines}
    <div class="res big"><span>Награда</span><b>💰 +${fmt(reward)}</b></div>
    <div class="brow"><button class="btn" id="ag">Ещё раз</button>${next?'<button class="btn" id="nx">Дальше ➜</button>':''}<button class="btn green" id="gr">Гараж</button></div></div>`;
  document.body.appendChild(ov); Snd.blip(523,0.15); setTimeout(()=>Snd.blip(784,0.3),150);
  const mode=R.mode, li=R.li;
  ov.querySelector('#ag').onclick=()=>{ ov.remove(); startRace(mode,li); };
  if(next) ov.querySelector('#nx').onclick=()=>{ ov.remove(); startRace('enduro',li+1); };
  ov.querySelector('#gr').onclick=()=>{ ov.remove(); R=null; renderGarage(); };
}

function respawn(){
  const b=R.bike;
  let x = R.mode!=='stunt' ? (R.cp>0 ? R.cps[R.cp-1].x : 0) : b.x+2;
  if(R.mode==='stunt'){ // find a flat spot ahead
    for(let i=0;i<200;i++){ const s=Math.abs(R.T.hAt(x+1)-R.T.hAt(x-1)); if(s<0.05) break; x+=0.5; } }
  b.place(x,R.T); R.rider=null; R.crashT=0; R.air=0; R.rot=0; R.wheelie=0; R.stoppie=0; R.combo=1;
}

function landTricks(){
  const b=R.bike; let a=b.a; a=Math.atan2(Math.sin(a),Math.cos(a));
  const flips=Math.floor((Math.abs(R.rot)+0.6)/(Math.PI*2));
  if(R.air>0.35){ prog('air',R.air); }
  if(Math.abs(a)<1.1){
    let pts=0, names=[];
    if(flips>0){ pts+=flips*1000; names.push((R.rot>0?'Бэкфлип':'Фронтфлип')+(flips>1?' x'+flips:'')); prog('flips',flips); }
    if(R.air>0.8){ pts+=Math.round(R.air*150); if(!flips) names.push('Полёт '+R.air.toFixed(1)+'с'); }
    if(pts>0){
      if(R.mode==='stunt'){ pts=Math.round(pts*R.combo); R.score+=pts; pop(names.join(' + ')+'  +'+pts+(R.combo>1?'  x'+R.combo:''), flips?'#7CFF6B':'#ffe14d'); R.combo=Math.min(5,R.combo+1); R.comboT=3; }
      else { if(flips) { R.coinsGot+=flips*2; pop(names.join(' + ')+'  +'+flips*2+' монет','#7CFF6B'); } }
      Snd.blip(flips?880:660,0.15);
    }
  }
  R.air=0; R.rot=0;
}

function updateRace(dt){
  const b=R.bike;
  if(R.startDelay>0){ R.startDelay-=dt; if(R.startDelay<=0 && R.mode==='online'){ pop('ПОЕХАЛИ!','#7CFF6B'); Snd.blip(880,0.3); } else if(R.mode==='online' && Math.ceil(R.startDelay)!==Math.ceil(R.startDelay+dt)) Snd.blip(440,0.15); }
  const alive=!R.rider;
  const inp = alive && R.startDelay<=0 && !R.over ? input : {gas:false,brake:false,lean:0};
  const prevX=b.x;
  if(R.mode==='stunt') R.gen.ensure(b.x);
  b.step(dt, inp, R.T);
  if(!R.over && R.startDelay<=0) R.t+=dt;
  if(alive && !R.over){
    const d=b.x-prevX; if(d>0 && b.x>R.maxX){ prog('dist', b.x-Math.max(prevX,R.maxX)); R.maxX=b.x; }
    const c0=b.wheels[0].contact, c1=b.wheels[1].contact, inAir=!c0&&!c1;
    // rotation tracking
    let da=b.a-R.lastA; R.lastA=b.a;
    if(inAir){ R.air+=dt; R.rot+=da; }
    else if(R.air>0){ landTricks(); }
    // wheelie / stoppie
    if(c0&&!c1&&b.speed>2&&b.a>0.12){ R.wheelie+=dt; prog('wheelie',dt); if(R.mode==='stunt'&&R.wheelie>0.6) R.score+=dt*120*R.combo; }
    else { if(R.wheelie>1.2){ const pts=Math.round(R.wheelie*120); if(R.mode==='stunt') pop('Вилли '+R.wheelie.toFixed(1)+'с  +'+Math.round(pts*R.combo)); else pop('Вилли '+R.wheelie.toFixed(1)+'с'); if(R.mode==='stunt'){R.combo=Math.min(5,R.combo+1);R.comboT=3;} } R.wheelie=0; }
    if(c1&&!c0&&b.speed>2&&b.a<-0.12){ R.stoppie+=dt; if(R.mode==='stunt'&&R.stoppie>0.4) R.score+=dt*200*R.combo; }
    else { if(R.stoppie>0.8){ pop('Стоппи '+R.stoppie.toFixed(1)+'с'); } R.stoppie=0; }
    if(R.comboT>0){ R.comboT-=dt; if(R.comboT<=0) R.combo=1; }
    // crash
    if(b.crashed(R.T)){
      R.crashes++; R.crashT=0; R.combo=1; R.air=0; R.rot=0;
      const [hx,hy]=b.headPos(); R.rider={x:hx,y:hy,vx:b.vx*0.8,vy:b.vy*0.5+3,a:b.a,va:(Math.random()-0.5)*10};
      Snd.blip(110,0.4,'sawtooth'); pop('АВАРИЯ!','#ff4d4d');
      if(navigator.vibrate) try{navigator.vibrate(120);}catch(e){}
    }
    // coins
    for(const c of R.coins){ if(!c.got && Math.abs(c.x-b.x)<1.1 && Math.abs(c.y-b.y-0.3)<1.4){ c.got=true; R.coinsGot++; prog('coins',1); Snd.blip(1320,0.08,'triangle'); } }
    // checkpoints
    while(R.cp<R.cps.length && b.x>R.cps[R.cp].x){ R.cp++; pop('Чекпоинт ✓','#8fd3ff'); Snd.blip(740,0.12); }
    if(R.mode!=='stunt' && b.x>R.finishX) endRace(true);
    if(R.mode==='stunt' && R.t>=STUNT_TIME) endRace(true);
    // dust
    const rw=b.wheels[0];
    if(rw.contact && inp.gas && (rw.slip>1.5 || Math.random()<0.25)) R.parts.push({x:rw.x-0.2,y:rw.y-rw.r+0.05,vx:-1-Math.random()*2,vy:Math.random()*2,t:0,s:0.1+Math.random()*0.15});
  }
  if(R.rider){
    const r=R.rider; r.vy-=G*dt; r.x+=r.vx*dt; r.y+=r.vy*dt; r.a+=r.va*dt;
    const gy=R.T.hAt(r.x)+0.2; if(r.y<gy){ r.y=gy; r.vy=Math.abs(r.vy)*0.3; r.vx*=0.7; r.va*=0.7; }
    R.crashT+=dt;
    if(R.crashT>1.6){ if(R.mode==='stunt' && R.t>=STUNT_TIME) endRace(true); else respawn(); }
  }
  for(const p of R.parts){ p.t+=dt; p.x+=p.vx*dt; p.y+=p.vy*dt; p.vy-=3*dt; }
  R.parts=R.parts.filter(p=>p.t<0.7);
  for(const p of R.pops) p.t+=dt; R.pops=R.pops.filter(p=>p.t<1.6);
  // camera
  const sp=Math.hypot(b.vx,b.vy), gh=Math.max(0,b.y-R.T.hAt(b.x));
  const zt=H/(6.8+Math.min(sp,32)*0.13+Math.min(gh,14)*0.35);
  R.cam.z+=(zt-R.cam.z)*Math.min(1,dt*1.5);
  R.cam.x+=(b.x+b.vx*0.3-R.cam.x)*Math.min(1,dt*5);
  R.cam.y+=(b.y+0.4-R.cam.y)*Math.min(1,dt*4);
  // engine sound
  const rpm=Math.min(1.2,Math.abs(b.wheels[0].w*b.wheels[0].r)/R.p.vmax);
  Snd.engine(rpm, inp.gas?1:0, !R.over && !R.paused);
  // HUD
  const spd=document.getElementById('spd'); if(spd) spd.textContent=Math.round(Math.abs(b.speed)*3.6);
  const pg=document.getElementById('pg'); if(pg) pg.style.width=Math.max(0,Math.min(100,b.x/R.finishX*100))+'%';
  const sc=document.getElementById('sc'); if(sc) sc.textContent=fmt(R.score)+(R.combo>1?'  x'+R.combo:'');
  const hi=document.getElementById('hinfo');
  if(R.mode==='online') onlineTick(dt);
  if(hi) hi.textContent = R.mode==='stunt' ? '⏱ '+Math.max(0,Math.ceil(STUNT_TIME-R.t))+' с' : '⏱ '+R.t.toFixed(1)+' с   💰 '+R.coinsGot;
}

function drawRace(){
  const th=R.theme, b=R.bike, z=R.cam.z, cx=R.cam.x, cy=R.cam.y;
  ctx.setTransform(DPR,0,0,DPR,0,0);
  drawSky(th, cx);
  const ox=W*0.36, oy=H*0.5;
  ctx.setTransform(DPR*z,0,0,-DPR*z, DPR*(ox-cx*z), DPR*(oy+cy*z));
  const x0=cx-ox/z-2, x1=cx+(W-ox)/z+2, T=R.T, ybot=cy-(H-oy)/z-5;
  // decorations behind
  const dstep=6;
  for(let x=Math.floor(x0/dstep)*dstep; x<x1; x+=dstep){
    const hv=hash(Math.floor(x/dstep)+17); if(hv<0.45) continue; const gy=T.hAt(x)-0.1, s=0.7+hv*0.8;
    if(th.deco==='tree'){ L(x,gy,x,gy+1.6*s,0.18,'#5a3d22'); circ(x,gy+2.2*s,0.9*s,shade(th.near,-0.15)); circ(x-0.4*s,gy+1.8*s,0.6*s,shade(th.near,-0.05)); }
    else if(th.deco==='pine'){ L(x,gy,x,gy+0.8*s,0.15,'#4a3320'); poly([x-0.9*s,gy+0.6*s,x+0.9*s,gy+0.6*s,x,gy+3.2*s],shade(th.near,-0.25)); }
    else if(th.deco==='rock'){ poly([x-0.7*s,gy,x+0.8*s,gy,x+0.5*s,gy+0.6*s,x-0.3*s,gy+0.8*s],shade(th.ground,0.15)); }
    else if(th.deco==='city' && hv>0.8){ L(x,gy,x,gy+3.5,0.08,'#2c2f3a'); L(x,gy+3.5,x+0.6,gy+3.5,0.08,'#2c2f3a'); circ(x+0.6,gy+3.4,0.12,'#ffe7a0'); }
  }
  // terrain
  const i0=Math.max(0,Math.floor((x0-T.x0)/DX)), i1=Math.min(T.h.length-1,Math.ceil((x1-T.x0)/DX));
  ctx.beginPath(); ctx.moveTo(T.x0+i0*DX, ybot);
  for(let i=i0;i<=i1;i++) ctx.lineTo(T.x0+i*DX, T.h[i]);
  ctx.lineTo(T.x0+i1*DX, ybot); ctx.closePath();
  ctx.fillStyle=th.ground; ctx.fill();
  ctx.beginPath(); for(let i=i0;i<=i1;i++){ const x=T.x0+i*DX; i===i0?ctx.moveTo(x,T.h[i]-0.45):ctx.lineTo(x,T.h[i]-0.45);} ctx.strokeStyle=shade(th.ground,-0.18); ctx.lineWidth=0.5; ctx.stroke();
  ctx.beginPath(); for(let i=i0;i<=i1;i++){ const x=T.x0+i*DX; i===i0?ctx.moveTo(x,T.h[i]-0.06):ctx.lineTo(x,T.h[i]-0.06);} ctx.strokeStyle=th.top; ctx.lineWidth=0.16; ctx.stroke();
  // checkpoints & finish
  for(let i=0;i<R.cps.length;i++){ const c=R.cps[i]; if(c.x<x0||c.x>x1) continue; L(c.x,c.y,c.x,c.y+2.6,0.07,'#ddd'); poly([c.x,c.y+2.6,c.x+1,c.y+2.3,c.x,c.y+2.0], i<R.cp?'#4cd964':'#ff9f1a'); }
  if(R.finishX<x1+5){ const fx=R.finishX, fy=T.hAt(fx);
    L(fx-0.1,fy,fx-0.1,fy+3.4,0.1,'#eee'); L(fx+2.6,fy,fx+2.6,fy+3.4,0.1,'#eee');
    for(let i=0;i<8;i++) for(let j=0;j<2;j++){ ctx.fillStyle=(i+j)%2?'#111':'#fff'; ctx.fillRect(fx+i*0.34,fy+3.0+j*0.3,0.34,0.3); } }
  // coins
  for(const c of R.coins){ if(c.got||c.x<x0||c.x>x1) continue; circ(c.x,c.y,0.32,'#ffcc33','#b8860b',0.06); circ(c.x,c.y,0.17,null,'#e6a800',0.05); }
  // dust
  for(const p of R.parts){ ctx.globalAlpha=1-p.t/0.7; circ(p.x,p.y,p.s*(1+p.t*2),shade(th.ground,0.35)); } ctx.globalAlpha=1;
  const labels = R.mode==='online' ? drawGhosts(ox,oy,z,cx,cy) : [];
  // bike
  drawBikeBody(b, R.p.type, bikeColor(), b.pose, !R.rider, '#c8352b');
  if(R.rider){ const r=R.rider; ctx.save(); ctx.translate(r.x,r.y); ctx.rotate(r.a); ctx.lineCap='round';
    L(0,-0.5,0,0.2,0.2,'#eef0f4'); L(0,-0.5,0.3,-0.9,0.12,'#2f5f9e'); L(0,-0.5,-0.25,-0.95,0.12,'#2f5f9e'); L(0,0.1,0.35,-0.15,0.08,'#e2b48f'); circ(0,0.38,0.15,'#c8352b'); ctx.restore(); }
  // popups (screen space)
  ctx.setTransform(DPR,0,0,DPR,0,0); ctx.textAlign='center';
  ctx.font='800 '+Math.round(H*0.04)+'px system-ui,sans-serif';
  for(const l of labels){ ctx.lineWidth=4; ctx.strokeStyle='rgba(0,0,0,.6)'; ctx.strokeText(l.t,l.x,l.y); ctx.fillStyle=l.c; ctx.fillText(l.t,l.x,l.y); }
  R.pops.forEach((p,i)=>{ ctx.globalAlpha=Math.min(1,(1.6-p.t)*2); ctx.font='900 '+Math.round(H*0.065)+'px system-ui,sans-serif';
    const y=H*0.3-i*H*0.08-p.t*20; ctx.lineWidth=5; ctx.strokeStyle='rgba(0,0,0,.6)'; ctx.strokeText(p.text,W/2,y); ctx.fillStyle=p.col; ctx.fillText(p.text,W/2,y); });
  ctx.globalAlpha=1;
  if(R.startDelay>0){ ctx.font='900 '+Math.round(H*(R.mode==='online'?0.2:0.12))+'px system-ui'; ctx.fillStyle='#fff'; ctx.lineWidth=6; ctx.strokeStyle='rgba(0,0,0,.5)';
    const txt = R.mode==='online' ? String(Math.ceil(R.startDelay)) : 'ПОЕХАЛИ!'; ctx.strokeText(txt,W/2,H*0.45); ctx.fillText(txt,W/2,H*0.45); }
}

let gT=0;
function drawGarage(dt){
  gT+=dt;
  ctx.setTransform(DPR,0,0,DPR,0,0);
  const g=ctx.createLinearGradient(0,0,0,H); g.addColorStop(0,'#1d2a5c'); g.addColorStop(0.62,'#2c3f86'); g.addColorStop(0.62,'#22306a'); g.addColorStop(1,'#141c42'); ctx.fillStyle=g; ctx.fillRect(0,0,W,H);
  // shelves
  ctx.fillStyle='rgba(10,16,40,.45)';
  for(let i=0;i<4;i++){ const x=W*0.04+i*W*0.13; ctx.fillRect(x,H*0.12,W*0.1,H*0.46); }
  ctx.fillStyle='rgba(120,150,230,.18)'; for(let i=0;i<4;i++) for(let j=0;j<4;j++){ const x=W*0.04+i*W*0.13; ctx.fillRect(x+4,H*0.12+j*H*0.115+H*0.1,W*0.1-8,4); }
  ctx.strokeStyle='rgba(255,255,255,.05)'; ctx.lineWidth=2; for(let x=-W;x<W*2;x+=60){ ctx.beginPath(); ctx.moveTo(x,H*0.62); ctx.lineTo(x+(x-W*0.3)*0.6,H); ctx.stroke(); }
  // light cone
  const lg=ctx.createRadialGradient(W*0.3,H*0.66,10,W*0.3,H*0.66,H*0.5); lg.addColorStop(0,'rgba(140,170,255,.25)'); lg.addColorStop(1,'rgba(140,170,255,0)'); ctx.fillStyle=lg; ctx.fillRect(0,0,W,H);
  if(scene!=='garage') return;
  const p=makeParams(curBike(),curUp());
  const z=H/4.2, ox=W*0.3, oy=H*0.68;
  ctx.fillStyle='rgba(0,0,0,.35)'; ctx.beginPath(); ctx.ellipse(ox,oy+4,z*1.2,z*0.12,0,0,Math.PI*2); ctx.fill();
  ctx.setTransform(DPR*z,0,0,-DPR*z,DPR*ox,DPR*oy);
  const st=restState(p,0,p.r-p.anch[0][1]+0.05+Math.sin(gT*2)*0.004);
  st.wheels.forEach(w=>{ w.y=w.r; w.phi=0; });
  drawBikeBody(st,p.type,bikeColor(),Math.sin(gT*0.8)*0.1,true,'#c8352b');
}

// ---------- main loop ----------
let last=performance.now(), acc=0;
function frame(now){
  let dt=Math.min(0.05,(now-last)/1000); last=now;
  if(scene==='race' && R){
    if(!R.paused){ acc+=dt; let n=0; while(acc>=1/60 && n<4){ updateRace(1/60); acc-=1/60; n++; } if(n===4) acc=0; }
    if(R) drawRace();
  } else drawGarage(dt);
  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);

document.addEventListener('visibilitychange',()=>{ if(document.hidden){ if(R&&!R.paused&&!R.over&&R.mode!=='online') pause(); Snd.engine(0,0,false); save(); } });
window.onAndroidBack=function(){
  const ov=document.querySelector('.ov');
  if(ov){ if(ov.id==='pz'){ ov.remove(); if(R) R.paused=false; } else if(!R) { ov.remove(); if(scene==='garage') renderGarage(); } return true; }
  if(scene==='race'){ pause(); return true; }
  if(scene==='modes'){ renderGarage(); return true; }
  if(scene==='lobby'){ Net.send({t:'leave'}); Net.room=null; renderOnline(); return true; }
  if(scene==='online'){ Net.close(); renderModes(); return true; }
  return false;
};
renderGarage();
