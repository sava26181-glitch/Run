// physics.hpp — физика мотоцикла и генерация трасс
#pragma once
#include <vector>
#include <cmath>
#include <cstdint>
#include <algorithm>

namespace phys {

constexpr float DX = 0.5f;
constexpr float G = 13.0f;
constexpr float PIF = 3.14159265358979f;

struct Rng {
  uint32_t a;
  explicit Rng(uint32_t s) : a(s) {}
  float operator()() {
    a += 0x6D2B79F5u;
    uint32_t t = a;
    t = (t ^ (t >> 15)) * (1u | t);
    t ^= t + (t ^ (t >> 7)) * (61u | t);
    return (float)((t ^ (t >> 14)) >> 0) / 4294967296.0f;
  }
};
inline float ss(float u) { return u * u * (3 - 2 * u); }

struct Probe { float d, nx, ny; };

struct Terrain {
  float x0 = -30;
  std::vector<float> h{0.0f};
  float end() const { return x0 + (h.size() - 1) * DX; }
  float hAt(float x) const {
    float f = (x - x0) / DX; int i = (int)std::floor(f);
    if (i < 0) return h[0];
    if (i >= (int)h.size() - 1) return h.back();
    float t = f - i; return h[i] * (1 - t) + h[i + 1] * t;
  }
  template <class F> void seg(float L, F fn) {
    float base = h.back(); int n = std::max(1, (int)std::lround(L / DX));
    for (int i = 1; i <= n; i++) h.push_back(base + fn((float)i / n));
  }
  Probe probe(float x, float y, float r) const {
    int i0 = (int)std::floor((x - r - x0) / DX) - 1, i1 = (int)std::ceil((x + r - x0) / DX) + 1;
    if (i0 < 0) i0 = 0; if (i1 > (int)h.size() - 2) i1 = (int)h.size() - 2;
    float bd2 = 1e9f, bnx = 0, bny = 1, sx = 0, sy = 1;
    for (int i = i0; i <= i1; i++) {
      float ax = x0 + i * DX, ay = h[i], ex = DX, ey = h[i + 1] - ay;
      float t = ((x - ax) * ex + (y - ay) * ey) / (ex * ex + ey * ey);
      t = std::clamp(t, 0.0f, 1.0f);
      float dx = x - (ax + ex * t), dy = y - (ay + ey * t), d2 = dx * dx + dy * dy;
      if (d2 < bd2) { bd2 = d2; bnx = dx; bny = dy; float l = std::hypot(ex, ey); sx = -ey / l; sy = ex / l; }
    }
    float d = std::sqrt(bd2);
    bool below = y < hAt(x);
    if (below || d < 1e-6f) return {below ? -d : 0.0f, sx, sy};
    return {d, bnx / d, bny / d};
  }
};

struct Coin { float x, y; bool got = false; };
struct Level { Terrain T; std::vector<Coin> coins; std::vector<float> cps; float finishX = 1e9f; };

inline Level genEnduro(float len, float diff, uint32_t seed) {
  Rng r(seed); Level L; Terrain& T = L.T;
  T.seg(70, [](float) { return 0.0f; });
  std::vector<int> kinds;
  if (diff < 0.9f) kinds = {0, 0, 1, 2, 3, 6};
  else if (diff < 1.5f) kinds = {0, 1, 2, 3, 4, 5, 0};
  else kinds = {0, 1, 2, 3, 4, 5, 5, 3, 1};
  while (T.end() < len) {
    int k = kinds[(int)(r() * kinds.size())];
    if (k == 6) { float L2 = 6 + r() * 10; T.seg(L2, [](float) { return 0.0f; }); }
    else if (k == 0) { float L2 = 18 + r() * 30, A = (1.2f + r() * 2.6f) * diff, s = r() < 0.6f ? 1.f : -1.f; T.seg(L2, [=](float u) { return s * A * (1 - std::cos(2 * PIF * u)) / 2; }); }
    else if (k == 1) { float L2 = 18 + r() * 25, D = (r() * 2 - 1) * 6 * diff; T.seg(L2, [=](float u) { return D * ss(u); }); }
    else if (k == 2) { int n = 3 + (int)(r() * 4); float a = (0.25f + r() * 0.35f) * diff; T.seg(n * 2.6f, [=](float u) { float s = std::sin(PIF * u * n); return a * s * s; }); }
    else if (k == 3) { float hh = (1.0f + r() * 1.4f) * diff, Lr = hh * 3.2f; T.seg(Lr, [=](float u) { return hh * std::pow(u, 1.5f); }); T.seg(3 + r() * 4, [](float) { return 0.0f; }); T.seg(Lr * 1.8f, [=](float u) { return -hh * ss(u); }); }
    else if (k == 4) { int n = 2 + (int)(r() * 3); for (int i = 0; i < n; i++) { float s = (r() < 0.5f ? 1.f : -1.f) * (0.25f + r() * 0.25f) * diff; T.seg(1, [=](float u) { return s * ss(u); }); T.seg(1.5f + r() * 2, [](float) { return 0.0f; }); } }
    else if (k == 5) { float hh = (1.0f + r() * 1.2f) * diff, Lr = hh * 3; T.seg(Lr, [=](float u) { return hh * std::pow(u, 1.6f); }); T.seg(1, [=](float u) { return -(hh + 0.6f * diff) * u; }); T.seg(5, [](float) { return 0.0f; }); }
    T.seg(3 + r() * 5, [](float) { return 0.0f; });
  }
  L.finishX = T.end() + 8;
  T.seg(80, [](float) { return 0.0f; });
  { std::vector<float> o = T.h; for (size_t i = 1; i + 1 < T.h.size(); i++) T.h[i] = o[i - 1] * 0.25f + o[i] * 0.5f + o[i + 1] * 0.25f; }
  for (float x = 40; x < L.finishX - 10; x += 14 + r() * 14) L.coins.push_back({x, T.hAt(x) + 1.0f});
  for (float x = 150; x < L.finishX - 40; x += 150) L.cps.push_back(x);
  return L;
}

struct StuntGen {
  Rng r; Level L;
  explicit StuntGen(uint32_t seed) : r(seed) { L.T.seg(60, [](float) { return 0.0f; }); }
  void more() {
    Terrain& T = L.T; float k = r();
    T.seg(10 + r() * 14, [](float) { return 0.0f; });
    if (k < 0.45f) { float hh = 1.4f + r() * 1.8f, Lr = hh * 2.8f; T.seg(Lr, [=](float u) { return hh * u * u; }); T.seg(1.5f, [](float) { return 0.0f; }); T.seg(Lr * 3, [=](float u) { return -hh * ss(u); }); }
    else if (k < 0.8f) { float hh = 3.5f + r() * 2.5f, Lr = hh * 2.1f; T.seg(Lr, [=](float u) { return hh * std::pow(u, 2.2f); }); T.seg(1, [](float) { return 0.0f; }); T.seg(26 + hh * 2, [=](float u) { return -hh * ss(u); }); }
    else { int n = 3 + (int)(r() * 3); float a = 0.5f + r() * 0.4f; T.seg(n * 4.0f, [=](float u) { float s = std::sin(PIF * u * n); return a * s * s; }); }
  }
  void ensure(float x) { while (L.T.end() < x + 120) more(); }
};

// ---------------- bike ----------------
enum BikeType { MOPED = 0, DIRT = 1, ENDURO = 2 };
struct BikeSpec { const char* name; BikeType type; int price; float power, vmax, mass, grip, hp; uint32_t color; };
struct Upg { int engine = 0, wheels = 0, susp = 0, frame = 0; };

struct Params {
  BikeType type; float M, Ic, mw, r, I, T, vmax, mu, kA, cA, kP, cP, travel, lean, airLean, B;
  float anch[2][2]; float head[2];
};
inline Params makeParams(const BikeSpec& B, const Upg& u) {
  Params p{}; bool moped = B.type == MOPED;
  p.type = B.type; p.r = moped ? 0.29f : 0.34f; p.mw = 8;
  p.M = B.mass * (1 - 0.04f * u.frame) + 65; float k = p.M / 150;
  p.Ic = p.M * 0.33f; p.I = 0.6f * p.mw * p.r * p.r;
  p.T = 230 * B.power * (1 + 0.13f * u.engine); p.vmax = B.vmax * (1 + 0.05f * u.engine);
  p.mu = 1.05f * B.grip * (1 + 0.07f * u.wheels);
  p.kA = 9500 * k * (1 + 0.10f * u.susp); p.cA = 750 * k * (1 + 0.12f * u.susp); p.kP = 45000; p.cP = 600;
  p.travel = 0.15f + 0.02f * u.susp;
  p.lean = 420 * k * (1 + 0.06f * u.frame); p.airLean = 700 * k * (1 + 0.10f * u.frame); p.B = 1100 * k;
  if (moped) { p.anch[0][0] = -0.6f; p.anch[0][1] = -0.34f; p.anch[1][0] = 0.62f; p.anch[1][1] = -0.34f; p.head[0] = 0.02f; p.head[1] = 0.92f; }
  else { p.anch[0][0] = -0.68f; p.anch[0][1] = -0.38f; p.anch[1][0] = 0.70f; p.anch[1][1] = -0.38f; p.head[0] = 0.04f; p.head[1] = 1.02f; }
  return p;
}

struct Input { bool gas = false, brake = false; float lean = 0, leanEff = 0; };
struct Wheel { float x, y, vx = 0, vy = 0, w = 0, phi = 0, r, I; bool contact = false; float slip = 0, comp = 0; };

struct Bike {
  Params p; float x, y, vx = 0, vy = 0, a = 0, va = 0, pose = 0; bool air = false;
  Wheel wh[2];
  Bike() {}
  Bike(const Params& pp, float X, float Y) : p(pp), x(X), y(Y) {
    for (int i = 0; i < 2; i++) { wh[i].x = X + p.anch[i][0]; wh[i].y = Y + p.anch[i][1] - 0.05f; wh[i].r = p.r; wh[i].I = p.I; }
  }
  float speed() const { return vx * std::cos(a) + vy * std::sin(a); }
  void place(float X, const Terrain& T) {
    float Y = std::max(T.hAt(X + p.anch[0][0]), T.hAt(X + p.anch[1][0])) + p.r - p.anch[0][1] + 0.05f;
    x = X; y = Y; vx = vy = va = 0; a = 0;
    for (int i = 0; i < 2; i++) { wh[i].x = X + p.anch[i][0]; wh[i].y = Y + p.anch[i][1] - 0.04f; wh[i].vx = wh[i].vy = wh[i].w = 0; }
  }
  void step(float dt, Input& in, const Terrain& T) {
    air = !wh[0].contact && !wh[1].contact;
    for (auto& w : wh) { w.contact = false; w.slip = 0; }
    const int N = 10; float h = dt / N;
    for (int s = 0; s < N; s++) sub(h, in, T);
    pose += (-in.leanEff - pose) * std::min(1.0f, dt * 8);
  }
  void sub(float h, Input& in, const Terrain& T) {
    float ca = std::cos(a), sa = std::sin(a);
    float fx = 0, fy = -p.M * G, tq = 0;
    bool inAir = air && !wh[0].contact && !wh[1].contact;
    float lean = in.lean;
    if (inAir && lean == 0) { if (in.gas) lean = 0.55f; else if (in.brake) lean = -0.55f; }
    in.leanEff = lean;
    tq += lean * (inAir ? p.airLean : p.lean);
    tq -= va * p.Ic * (inAir ? 0.25f : 0.6f);
    float ux = -sa, uy = ca;
    for (int j = 0; j < 2; j++) {
      Wheel& w = wh[j]; float lx = p.anch[j][0], ly = p.anch[j][1];
      float rx = lx * ca - ly * sa, ry = lx * sa + ly * ca;
      float px = x + rx, py = y + ry, pvx = vx - va * ry, pvy = vy + va * rx;
      float dx = w.x - px, dy = w.y - py, dvx = w.vx - pvx, dvy = w.vy - pvy;
      float dA = dx * ux + dy * uy, vA = dvx * ux + dvy * uy;
      w.comp = dA;
      float qx = dx - dA * ux, qy = dy - dA * uy, qvx = dvx - vA * ux, qvy = dvy - vA * uy;
      float fA = -p.kA * dA - p.cA * vA;
      if (dA > p.travel) fA -= (dA - p.travel) * p.kA * 10 + (vA > 0 ? vA * p.cA * 2 : 0);
      if (dA < -0.12f) fA -= (dA + 0.12f) * p.kA * 10;
      float Fx = fA * ux - p.kP * qx - p.cP * qvx, Fy = fA * uy - p.kP * qy - p.cP * qvy;
      w.vx += Fx / p.mw * h; w.vy += (Fy / p.mw - G) * h;
      fx -= Fx; fy -= Fy; tq += rx * (-Fy) - ry * (-Fx);
    }
    vx += fx / p.M * h; vy += fy / p.M * h; va += tq / p.Ic * h;
    va = std::clamp(va, -9.0f, 9.0f);
    Wheel& rw = wh[0];
    if (in.gas) {
      float ratio = std::max(0.0f, rw.w * rw.r / p.vmax);
      float Tq = p.T * std::max(0.0f, 1 - ratio * ratio);
      if (!inAir) {
        float gs = std::atan2(T.hAt(x + 0.7f) - T.hAt(x - 0.7f), 1.4f);
        float ang = std::atan2(std::sin(a - gs), std::cos(a - gs));
        if (ang > 0.3f) Tq *= std::max(0.15f, 1 - (ang - 0.3f) * 2.2f);
      }
      rw.w += Tq / rw.I * h; va += 0.4f * Tq / p.Ic * h;
    }
    if (in.brake) {
      float fwd = speed();
      if (fwd < 0.6f && !in.gas) {
        if (rw.w * rw.r > -3) { rw.w -= p.T * 0.35f / rw.I * h; va -= p.T * 0.35f / p.Ic * h; }
      } else for (int j = 0; j < 2; j++) { Wheel& w = wh[j]; float b = p.B * (j ? 0.45f : 1.0f) * h / w.I; if (std::fabs(w.w) <= b) w.w = 0; else w.w -= (w.w > 0 ? 1 : -1) * b; }
    }
    x += vx * h; y += vy * h; a += va * h;
    for (auto& w : wh) {
      w.w *= (1 - 0.08f * h);
      w.x += w.vx * h; w.y += w.vy * h; w.phi -= w.w * h;
      Probe c = T.probe(w.x, w.y, w.r);
      if (c.d < w.r) {
        float pen = w.r - c.d, nx = c.nx, ny = c.ny;
        w.x += nx * pen; w.y += ny * pen;
        float vn = w.vx * nx + w.vy * ny, jn = 0;
        if (vn < 0) { jn = -vn * p.mw * 1.05f; w.vx -= vn * nx * 1.05f; w.vy -= vn * ny * 1.05f; }
        float tx = ny, ty = -nx, vt = w.vx * tx + w.vy * ty, s = vt - w.w * w.r;
        float jt = -s / (1 / p.mw + w.r * w.r / w.I), lim = p.mu * jn;
        jt = std::clamp(jt, -lim, lim);
        w.vx += jt / p.mw * tx; w.vy += jt / p.mw * ty; w.w -= jt * w.r / w.I;
        w.contact = true; w.slip = std::max(w.slip, std::fabs(s));
      }
    }
  }
  void headPos(float& hx, float& hy) const {
    float ca = std::cos(a), sa = std::sin(a), lx = p.head[0] + pose * 0.15f, ly = p.head[1];
    hx = x + lx * ca - ly * sa; hy = y + lx * sa + ly * ca;
  }
  bool crashed(const Terrain& T) const { float hx, hy; headPos(hx, hy); return T.probe(hx, hy, 0.17f).d < 0.17f; }
};

} // namespace phys
