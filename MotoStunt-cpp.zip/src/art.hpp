// art.hpp — модели мотоциклов, гонщик, фоны, трассы
#pragma once
#include "gfx.hpp"
#include "physics.hpp"

namespace art {
using namespace gfx;
using V = Vector2;

inline float hsh(int n) { n = (n << 13) ^ n; return ((n * (n * n * 15731 + 789221) + 1376312589) & 0x7fffffff) / (float)0x7fffffff; }

// ---------- состояние байка для отрисовки ----------
struct BikeView {
  float x, y, a; float wx[2], wy[2], phi[2], r; int type; Color col; float pose; bool rider = true; float alpha = 1;
};
inline BikeView viewOf(const phys::Bike& b, Color col) {
  BikeView v; v.x = b.x; v.y = b.y; v.a = b.a; v.r = b.p.r; v.type = b.p.type; v.col = col; v.pose = b.pose;
  for (int i = 0; i < 2; i++) { v.wx[i] = b.wh[i].x; v.wy[i] = b.wh[i].y; v.phi[i] = b.wh[i].phi; }
  return v;
}
inline BikeView restView(const phys::Params& p, Color col, float x = 0, float y = 0) {
  BikeView v; v.x = x; v.y = y; v.a = 0; v.r = p.r; v.type = p.type; v.col = col; v.pose = 0;
  for (int i = 0; i < 2; i++) { v.wx[i] = x + p.anch[i][0]; v.wy[i] = y + p.anch[i][1] - 0.06f; v.phi[i] = 0; }
  return v;
}

// ---------- колесо ----------
inline void wheel(const Xf& w, float r, int type, bool disc) {
  bool moped = type == phys::MOPED;
  Color tire = hex(0x1C1D22), rimC = moped ? hex(0xD9DEE6) : (type == phys::ENDURO ? hex(0x2B2D33) : hex(0xC9A43A));
  circO(w, {0, 0}, r, tire, 3);
  if (!moped) for (int i = 0; i < 20; i++) { float a = i * PI / 10; float a0 = a - 0.07f, a1 = a + 0.07f; polyF(w, {{std::cos(a0) * r, std::sin(a0) * r}, {std::cos(a1) * r, std::sin(a1) * r}, {std::cos(a1) * (r + 0.03f), std::sin(a1) * (r + 0.03f)}, {std::cos(a0) * (r + 0.03f), std::sin(a0) * (r + 0.03f)}}, tire); }
  circL(w, {0, 0}, r * 0.93f, hex(0x2A2C33));
  ringL(w, {0, 0}, r * 0.66f, r * 0.76f, rimC);
  ringL(w, {0, 0}, r * 0.62f, r * 0.66f, shade(rimC, -0.3f));
  circL(w, {0, 0}, r * 0.62f, alpha(hex(0x11131A), 0.9f));
  int ns = moped ? 18 : 24;
  for (int i = 0; i < ns; i++) { float a = i * 2 * PI / ns, off = (i % 2 ? 0.25f : -0.25f); lineL(w, {std::cos(a + off) * 0.06f, std::sin(a + off) * 0.06f}, {std::cos(a) * r * 0.64f, std::sin(a) * r * 0.64f}, 0.008f, hex(0xBFC5CE)); }
  if (disc) { ringL(w, {0, 0}, r * 0.3f, r * 0.42f, hex(0x9EA6B3)); for (int i = 0; i < 6; i++) { float a = i * PI / 3; circL(w, {std::cos(a) * r * 0.36f, std::sin(a) * r * 0.36f}, 0.012f, hex(0x5A616D)); } }
  circO(w, {0, 0}, moped ? 0.075f : 0.065f, hex(0xA8AFBA), 2); circL(w, {0, 0}, 0.025f, hex(0x5A616D));
  // блик
  DrawRing(w.p(0, 0), r * w.k * 0.8f, r * w.k * 0.9f, 200, 250, 8, alpha(WHITE_, 0.18f));
}

// ---------- IK ----------
inline V ik(V A, V B, float l1, float l2, float bend) {
  float dx = B.x - A.x, dy = B.y - A.y, d = std::sqrt(dx * dx + dy * dy); d = std::clamp(d, 0.01f, l1 + l2 - 0.001f);
  float a = (l1 * l1 - l2 * l2 + d * d) / (2 * d), hh = std::sqrt(std::max(0.f, l1 * l1 - a * a));
  float ux = dx / d, uy = dy / d; return {A.x + ux * a - uy * hh * bend, A.y + uy * a + ux * hh * bend};
}

// ---------- гонщик ----------
inline void rider(const Xf& b, int type, float pose, Color helmet) {
  bool moped = type == phys::MOPED;
  V hip = moped ? V{-0.33f, 0.42f} : V{-0.27f, 0.6f};
  V foot = moped ? V{0.02f, -0.1f} : V{-0.07f, -0.05f};
  V grip = moped ? V{0.27f, 0.6f} : V{0.24f, 0.73f};
  hip.x += pose * 0.12f; hip.y -= std::fabs(pose) * 0.03f;
  float th = (moped ? 0.32f : 0.42f) + pose * 0.42f; // наклон торса от вертикали
  V sh = {hip.x + 0.5f * std::sin(th), hip.y + 0.5f * std::cos(th)};
  float dg = std::hypot(grip.x - sh.x, grip.y - sh.y); if (dg > 0.6f) { float k = (dg - 0.59f) / dg; sh.x += (grip.x - sh.x) * k * 0.5f; sh.y += (grip.y - sh.y) * k * 0.5f; }
  V knee = ik(hip, foot, 0.42f, 0.42f, 1);
  V elbow = ik(sh, grip, 0.3f, 0.3f, -1);
  V head = {sh.x + 0.06f + pose * 0.06f, sh.y + 0.22f};
  Color jeans = hex(0x2F5F9E), shirt = hex(0xF2F4F8), skin = hex(0xE8B08A), glove = hex(0x22252C), shoe = hex(0xD8352B);
  // нога
  lineO(b, hip, knee, 0.16f, jeans); lineO(b, knee, foot, 0.13f, jeans);
  lineL(b, {hip.x, hip.y + 0.02f}, {knee.x, knee.y + 0.025f}, 0.05f, shade(jeans, 0.15f));
  // кроссовок
  polyO(b, {{foot.x - 0.07f, foot.y - 0.06f}, {foot.x + 0.17f, foot.y - 0.06f}, {foot.x + 0.17f, foot.y + 0.0f}, {foot.x + 0.09f, foot.y + 0.06f}, {foot.x - 0.06f, foot.y + 0.06f}}, shoe, 2.5f);
  polyF(b, {{foot.x - 0.07f, foot.y - 0.06f}, {foot.x + 0.17f, foot.y - 0.06f}, {foot.x + 0.17f, foot.y - 0.035f}, {foot.x - 0.07f, foot.y - 0.035f}}, WHITE_);
  // торс
  V perp = {std::cos(th), -std::sin(th)};
  polyO(b, {{hip.x - perp.x * 0.11f, hip.y - perp.y * 0.11f}, {hip.x + perp.x * 0.1f, hip.y + perp.y * 0.1f}, {sh.x + perp.x * 0.11f, sh.y + perp.y * 0.11f}, {sh.x - perp.x * 0.12f, sh.y - perp.y * 0.12f}}, shirt);
  polyF(b, {{hip.x - perp.x * 0.11f, hip.y - perp.y * 0.11f}, {hip.x - perp.x * 0.02f, hip.y - perp.y * 0.02f}, {sh.x - perp.x * 0.03f, sh.y - perp.y * 0.03f}, {sh.x - perp.x * 0.12f, sh.y - perp.y * 0.12f}}, hex(0xD5DAE4));
  lineL(b, {hip.x - perp.x * 0.11f, hip.y - perp.y * 0.11f + 0.03f}, {hip.x + perp.x * 0.1f, hip.y + perp.y * 0.1f + 0.03f}, 0.05f, hex(0x5A3B22));
  // рука
  V mid = {(sh.x + elbow.x) / 2, (sh.y + elbow.y) / 2};
  lineO(b, elbow, grip, 0.08f, skin);
  lineO(b, mid, elbow, 0.085f, skin);
  lineO(b, sh, mid, 0.13f, shirt);
  circO(b, grip, 0.055f, glove, 2.5f);
  // шея и шлем
  lineO(b, {sh.x, sh.y}, {head.x - 0.02f, head.y - 0.08f}, 0.08f, skin);
  Xf hx = b.sub(head.x, head.y, -0.1f + pose * 0.25f);
  polyO(hx, {{-0.16f, -0.05f}, {-0.15f, 0.07f}, {-0.08f, 0.15f}, {0.04f, 0.17f}, {0.13f, 0.11f}, {0.17f, 0.0f}, {0.17f, -0.1f}, {0.06f, -0.13f}, {-0.06f, -0.15f}, {-0.14f, -0.12f}}, helmet);
  polyF(hx, {{-0.15f, 0.05f}, {-0.08f, 0.13f}, {0.04f, 0.155f}, {0.06f, 0.13f}, {-0.07f, 0.1f}, {-0.13f, 0.03f}}, shade(helmet, 0.25f));
  polyO(hx, {{0.03f, 0.06f}, {0.17f, 0.04f}, {0.17f, -0.05f}, {0.05f, -0.04f}}, hex(0x1B2433), 2);
  lineL(hx, {0.07f, 0.04f}, {0.14f, 0.03f}, 0.015f, alpha(WHITE_, 0.5f));
  lineL(hx, {-0.12f, 0.06f}, {0.0f, 0.13f}, 0.03f, WHITE_);
  if (!moped) polyO(hx, {{0.1f, 0.12f}, {0.26f, 0.1f}, {0.24f, 0.07f}, {0.12f, 0.08f}}, helmet, 2); // козырёк кроссового шлема
}

// ---------- амортизатор с пружиной ----------
inline void shock(const Xf& b, V top, V bot, Color spring, float w = 0.05f) {
  lineO(b, top, bot, w * 0.7f, hex(0x9AA1AD), 2.5f);
  V d = {bot.x - top.x, bot.y - top.y}; float L = std::hypot(d.x, d.y); V u = {d.x / L, d.y / L}, n = {-u.y, u.x};
  std::vector<V> sp; int coils = 9; float s0 = 0.12f, s1 = 0.85f;
  for (int i = 0; i <= coils * 2; i++) { float t = s0 + (s1 - s0) * i / (coils * 2); float o = (i % 2 ? 1 : -1) * w; sp.push_back({top.x + d.x * t + n.x * o, top.y + d.y * t + n.y * o}); }
  pathO(b, sp, w * 0.45f, spring, 2);
  circO(b, top, w * 0.55f, hex(0x6C7380), 2); circO(b, bot, w * 0.55f, hex(0x6C7380), 2);
}

// ---------- модели ----------
inline void bikeBody(const BikeView& v, const Xf& b, V R, V F, bool rider_) {
  Color col = v.col, dk = shade(col, -0.35f), lt = shade(col, 0.3f);
  Color chrome = hex(0xD9DEE6), steel = hex(0x8A93A3), dsteel = hex(0x4A505B), black = hex(0x1D1F25);
  if (v.type == phys::MOPED) {
    V H = {0.38f, 0.36f}, P = {-0.1f, -0.2f};
    // задний амортизатор
    shock(b, {-0.42f, 0.17f}, {R.x + 0.05f, R.y + 0.06f}, chrome, 0.045f);
    // маятник + цепь в кожухе
    polyO(b, {{P.x, P.y + 0.04f}, {R.x, R.y + 0.03f}, {R.x, R.y - 0.03f}, {P.x, P.y - 0.04f}}, dsteel, 2.5f);
    polyO(b, {{P.x + 0.06f, P.y + 0.07f}, {R.x + 0.12f, R.y + 0.08f}, {R.x + 0.12f, R.y - 0.0f}, {P.x + 0.06f, P.y - 0.03f}}, dk, 2.5f);
    // крылья (хром)
    pathO(b, arc(R, v.r + 0.06f, PI * 0.18f, PI * 0.95f, 12), 0.035f, chrome, 2.5f);
    // задний багажник и фонарь
    pathO(b, {{-0.88f, 0.22f}, {-0.52f, 0.22f}}, 0.03f, chrome, 2.5f); lineO(b, {-0.82f, 0.22f}, {R.x + 0.02f, R.y + 0.12f}, 0.025f, chrome, 2.5f);
    polyO(b, rrect(-0.94f, 0.17f, -0.84f, 0.25f, 0.02f), hex(0xFF3B2F), 2.5f);
    // выхлоп
    pathO(b, {{0.2f, -0.12f}, {0.2f, -0.22f}, {0.05f, -0.27f}, {-0.35f, -0.25f}}, 0.045f, chrome, 2.5f);
    polyO(b, {{-0.32f, -0.2f}, {-0.78f, -0.18f}, {-0.8f, -0.3f}, {-0.32f, -0.31f}}, chrome, 2.5f);
    lineL(b, {-0.35f, -0.23f}, {-0.75f, -0.21f}, 0.012f, alpha(WHITE_, 0.7f));
    // двигатель
    polyO(b, rrect(-0.2f, -0.31f, 0.1f, -0.05f, 0.06f), hex(0xB4BBC6), 2.5f);
    polyO(b, {{0.04f, -0.2f}, {0.24f, -0.17f}, {0.24f, -0.04f}, {0.04f, -0.07f}}, steel, 2.5f);
    for (int i = 0; i < 4; i++) lineL(b, {0.08f + i * 0.045f, -0.19f}, {0.08f + i * 0.045f, -0.06f}, 0.014f, dsteel);
    circO(b, {-0.06f, -0.18f}, 0.075f, hex(0x9AA1AD), 2.5f); circL(b, {-0.06f, -0.18f}, 0.03f, dsteel);
    // педаль
    lineO(b, {-0.06f, -0.18f}, {0.06f, -0.08f}, 0.025f, dsteel, 2); polyO(b, rrect(0.0f, -0.11f, 0.14f, -0.06f, 0.01f), black, 2);
    // рама-хребет
    auto spine = bez(H, {0.18f, -0.18f}, {-0.12f, -0.13f}, 14);
    pathO(b, spine, 0.12f, col, 3); pathL(b, bez({H.x - 0.02f, H.y + 0.02f}, {0.15f, -0.12f}, {-0.1f, -0.08f}, 14), 0.03f, lt);
    pathO(b, {{-0.12f, -0.12f}, {-0.3f, 0.02f}, {-0.48f, 0.17f}}, 0.07f, col, 3);
    // кожух под сиденьем (бак)
    polyO(b, {{-0.52f, 0.1f}, {-0.1f, 0.06f}, {-0.02f, 0.2f}, {-0.48f, 0.23f}}, col, 3);
    polyF(b, {{-0.48f, 0.15f}, {-0.08f, 0.12f}, {-0.06f, 0.15f}, {-0.47f, 0.18f}}, lt);
    // сиденье
    polyO(b, {{-0.66f, 0.21f}, {-0.04f, 0.2f}, {-0.02f, 0.26f}, {-0.1f, 0.3f}, {-0.62f, 0.3f}, {-0.68f, 0.26f}}, hex(0x3A2418), 3);
    lineL(b, {-0.6f, 0.28f}, {-0.12f, 0.28f}, 0.012f, hex(0x6B4430));
    // вилка
    lineO(b, H, F, 0.055f, chrome, 2.5f);
    V fm = {H.x + (F.x - H.x) * 0.45f, H.y + (F.y - H.y) * 0.45f};
    lineO(b, {H.x + 0.01f, H.y - 0.04f}, fm, 0.075f, black, 2.5f);
    for (int i = 1; i < 6; i++) { float t = i / 6.0f; V p = {H.x + (fm.x - H.x) * t, H.y - 0.04f + (fm.y - H.y + 0.04f) * t}; lineL(b, {p.x - 0.04f, p.y + 0.01f}, {p.x + 0.04f, p.y - 0.01f}, 0.01f, hex(0x3C3F48)); }
    pathO(b, arc(F, v.r + 0.06f, PI * 0.12f, PI * 0.7f, 10), 0.035f, chrome, 2.5f);
    // руль и фара
    pathO(b, {{H.x, H.y + 0.03f}, {H.x - 0.02f, 0.56f}, {0.27f, 0.6f}}, 0.03f, chrome, 2.5f);
    lineO(b, {0.3f, 0.598f}, {0.22f, 0.605f}, 0.05f, black, 2);
    circO(b, {H.x + 0.08f, H.y + 0.02f}, 0.075f, chrome, 2.5f); circL(b, {H.x + 0.1f, H.y + 0.02f}, 0.05f, hex(0xFFF1B8));
    circL(b, {H.x + 0.085f, H.y + 0.04f}, 0.018f, WHITE_);
    lineO(b, {H.x - 0.05f, H.y + 0.18f}, {H.x - 0.1f, H.y + 0.32f}, 0.012f, steel, 1.5f); circO(b, {H.x - 0.1f, H.y + 0.33f}, 0.03f, steel, 1.5f);
  } else {
    bool en = v.type == phys::ENDURO;
    V H = {0.36f, 0.46f}, P = {-0.13f, -0.13f};
    Color frameC = en ? hex(0x2A2D35) : hex(0xC0392B), plastic2 = en ? hex(0x16181D) : hex(0xF4F4F4);
    // задний амортизатор
    V sb = {P.x + (R.x - P.x) * 0.35f, P.y + (R.y - P.y) * 0.35f + 0.05f};
    shock(b, {-0.2f, 0.3f}, sb, en ? hex(0xFFC21A) : hex(0xE23B2B), 0.05f);
    // цепь
    lineL(b, {-0.02f, -0.12f}, {R.x, R.y + 0.09f}, 0.022f, INK); lineL(b, {-0.02f, -0.22f}, {R.x, R.y - 0.09f}, 0.022f, INK);
    lineL(b, {-0.02f, -0.12f}, {R.x, R.y + 0.09f}, 0.012f, hex(0x6C7380)); lineL(b, {-0.02f, -0.22f}, {R.x, R.y - 0.09f}, 0.012f, hex(0x6C7380));
    circO(b, R, 0.1f, hex(0x7A808C), 2);
    // маятник
    polyO(b, {{P.x, P.y + 0.06f}, {R.x + 0.02f, R.y + 0.035f}, {R.x + 0.02f, R.y - 0.035f}, {P.x, P.y - 0.05f}}, en ? hex(0xB8BEC9) : hex(0x9AA1AD), 3);
    lineL(b, {P.x + 0.05f, P.y + 0.02f}, {R.x - 0.05f, R.y + 0.01f}, 0.012f, alpha(WHITE_, 0.5f));
    circO(b, P, 0.04f, dsteel, 2);
    // глушитель
    polyO(b, {{-0.32f, 0.2f}, {-0.86f, 0.36f}, {-0.9f, 0.27f}, {-0.36f, 0.1f}}, en ? hex(0x30333A) : hex(0xC5CBD4), 3);
    polyO(b, {{-0.86f, 0.36f}, {-0.94f, 0.36f}, {-0.96f, 0.28f}, {-0.9f, 0.27f}}, hex(0x111216), 2);
    // рама
    pathO(b, {H, {-0.24f, 0.36f}, P}, 0.06f, frameC, 3);
    pathO(b, {H, {0.16f, -0.24f}, {-0.05f, -0.3f}, P}, 0.055f, frameC, 3);
    pathO(b, {{-0.24f, 0.36f}, {-0.72f, 0.45f}}, 0.04f, frameC, 2.5f);
    // двигатель
    polyO(b, {{-0.17f, -0.3f}, {0.15f, -0.3f}, {0.2f, -0.1f}, {0.12f, 0.0f}, {-0.16f, -0.02f}}, hex(0x5D6573), 3);
    polyO(b, {{0.0f, -0.02f}, {0.17f, -0.03f}, {0.24f, 0.24f}, {0.06f, 0.26f}}, hex(0x7C8595), 3);
    for (int i = 0; i < 6; i++) { float t = 0.03f + i * 0.04f; lineL(b, {0.0f + t * 0.18f, -0.02f + t * 1.05f}, {0.2f + t * 0.17f, -0.03f + t * 1.0f}, 0.016f, INK); }
    polyO(b, {{0.04f, 0.24f}, {0.24f, 0.22f}, {0.25f, 0.29f}, {0.05f, 0.31f}}, hex(0x9AA1AD), 2.5f);
    circO(b, {-0.05f, -0.15f}, 0.1f, hex(0x8A93A3), 2.5f); circL(b, {-0.05f, -0.15f}, 0.05f, hex(0x5D6573));
    for (int i = 0; i < 6; i++) { float a = i * PI / 3; circL(b, {-0.05f + std::cos(a) * 0.075f, -0.15f + std::sin(a) * 0.075f}, 0.01f, INK); }
    // карбюратор
    polyO(b, rrect(-0.15f, 0.08f, -0.04f, 0.17f, 0.02f), hex(0xB4BBC6), 2);
    // выхлопной коллектор
    pathO(b, {{0.2f, 0.1f}, {0.32f, 0.04f}, {0.3f, -0.1f}, {0.1f, -0.08f}, {-0.12f, 0.06f}, {-0.34f, 0.15f}}, 0.05f, en ? hex(0xC08A4A) : hex(0xD9DEE6), 2.5f);
    // подножка
    polyO(b, rrect(-0.15f, -0.08f, 0.02f, -0.03f, 0.01f), hex(0xB4BBC6), 2);
    lineO(b, {0.12f, -0.12f}, {0.24f, -0.06f}, 0.03f, dsteel, 2); // рычаг тормоза
    // заднее крыло
    polyO(b, {{-0.28f, 0.5f}, {-1.04f, 0.66f}, {-1.06f, 0.6f}, {-0.75f, 0.48f}, {-0.3f, 0.41f}}, col, 3);
    polyF(b, {{-0.4f, 0.48f}, {-0.98f, 0.62f}, {-0.99f, 0.6f}, {-0.42f, 0.46f}}, lt);
    // боковой номер
    polyO(b, {{-0.56f, 0.14f}, {-0.2f, 0.12f}, {-0.16f, 0.44f}, {-0.6f, 0.44f}}, plastic2, 3);
    {
      V c = b.p(-0.38f, 0.29f); const char* num = en ? "450" : "125"; float fs = 0.2f * b.k;
      Vector2 m = MeasureTextEx(F_TITLE, num, fs, 0); float ang = -std::atan2(b.s, b.c) * RAD2DEG;
      DrawTextPro(F_TITLE, num, c, {m.x / 2, m.y / 2}, ang, fs, 0, en ? col : hex(0x1D1F25));
    }
    // сиденье
    polyO(b, {{-0.74f, 0.47f}, {-0.18f, 0.5f}, {0.14f, 0.56f}, {0.12f, 0.62f}, {-0.2f, 0.58f}, {-0.74f, 0.55f}}, black, 3);
    lineL(b, {-0.68f, 0.53f}, {-0.2f, 0.555f}, 0.01f, hex(0x3A3D45));
    // бак + спойлер радиатора
    polyO(b, {{0.0f, 0.5f}, {0.12f, 0.58f}, {0.34f, 0.56f}, {0.32f, 0.46f}, {0.04f, 0.42f}}, col, 3);
    polyO(b, {{0.0f, 0.1f}, {0.34f, 0.44f}, {0.33f, 0.56f}, {0.18f, 0.55f}, {0.02f, 0.4f}, {-0.06f, 0.24f}}, col, 3);
    polyF(b, {{0.04f, 0.16f}, {0.3f, 0.42f}, {0.27f, 0.46f}, {0.02f, 0.22f}}, plastic2);
    polyF(b, {{0.05f, 0.3f}, {0.2f, 0.45f}, {0.17f, 0.48f}, {0.03f, 0.35f}}, lt);
    // вилка (перевёрнутая)
    V fm = {H.x + (F.x - H.x) * 0.55f, H.y + (F.y - H.y) * 0.55f};
    lineO(b, {H.x, H.y + 0.04f}, fm, 0.085f, en ? hex(0x2A2D35) : hex(0xC9A43A), 3);
    lineO(b, fm, F, 0.055f, hex(0xDDE2EA), 2.5f);
    lineL(b, {H.x - 0.01f, H.y + 0.02f}, fm, 0.018f, alpha(WHITE_, 0.35f));
    polyO(b, rrect(F.x - 0.05f, F.y - 0.04f, F.x + 0.06f, F.y + 0.08f, 0.02f), hex(0x9AA1AD), 2);
    polyO(b, rrect(H.x - 0.06f, H.y - 0.03f, H.x + 0.08f, H.y + 0.06f, 0.02f), hex(0x3A3D45), 2);
    // переднее крыло
    polyO(b, {{H.x + 0.02f, H.y - 0.07f}, {H.x + 0.44f, H.y - 0.16f}, {H.x + 0.46f, H.y - 0.1f}, {H.x + 0.08f, H.y + 0.0f}}, col, 3);
    // номер / фара
    if (en) { polyO(b, {{H.x + 0.05f, H.y + 0.02f}, {H.x + 0.17f, H.y - 0.02f}, {H.x + 0.2f, H.y + 0.24f}, {H.x + 0.06f, H.y + 0.26f}}, col, 3); circO(b, {H.x + 0.14f, H.y + 0.11f}, 0.055f, hex(0xFFF1B8), 2); circL(b, {H.x + 0.13f, H.y + 0.13f}, 0.016f, WHITE_); }
    else polyO(b, {{H.x + 0.04f, H.y + 0.02f}, {H.x + 0.16f, H.y - 0.01f}, {H.x + 0.18f, H.y + 0.22f}, {H.x + 0.05f, H.y + 0.24f}}, WHITE_, 3);
    // руль
    pathO(b, {{H.x - 0.01f, H.y + 0.07f}, {H.x - 0.03f, 0.68f}, {0.24f, 0.73f}}, 0.03f, hex(0x9AA1AD), 2.5f);
    lineO(b, {0.28f, 0.725f}, {0.19f, 0.735f}, 0.05f, black, 2);
    if (en) polyO(b, {{0.2f, 0.7f}, {0.36f, 0.7f}, {0.4f, 0.8f}, {0.22f, 0.8f}}, col, 2.5f);
  }
  (void)rider_;
}

inline void drawBike(const BikeView& v, float sx, float sy, float k, Color helmet = hex(0xD63A30)) {
  Xf b(sx, sy, k, v.a);
  float ca = std::cos(v.a), sa = std::sin(v.a);
  auto loc = [&](int i) { float dx = v.wx[i] - v.x, dy = v.wy[i] - v.y; return V{dx * ca + dy * sa, -dx * sa + dy * ca}; };
  V R = loc(0), F = loc(1);
  // тень
  // колёса
  for (int i = 0; i < 2; i++) { V L = i ? F : R; Xf w = b.sub(L.x, L.y, v.phi[i] - v.a + 0.0f); wheel(w, v.r, v.type, v.type == phys::ENDURO || (i == 1 && v.type == phys::DIRT)); }
  bikeBody(v, b, R, F, v.rider);
  if (v.rider) rider(b, v.type, v.pose, helmet);
}

// ---------- фон гаража ----------
inline void garageBg(float t, float bikeX) {
  float W = VW, H = VH;
  // стена
  DrawRectangleGradientV(0, 0, (int)W + 1, (int)(H * 0.68f) + 1, hex(0x18214F), hex(0x26367C));
  for (int i = 0; i < 9; i++) DrawRectangle(0, (int)(H * 0.08f + i * H * 0.068f), (int)W + 1, 2, alpha(INK, 0.25f));
  // ворота
  float gx = W * 0.5f - 260, gw = 520, gy = H * 0.1f, gh = H * 0.58f;
  DrawRectangleRec({gx - 14, gy - 14, gw + 28, gh + 14}, hex(0x121A42));
  DrawRectangleRec({gx, gy, gw, gh}, hex(0x2B3D8A));
  for (float y = gy + 22; y < gy + gh; y += 26) { DrawRectangleRec({gx, y, gw, 3}, alpha(INK, 0.35f)); DrawRectangleRec({gx, y + 3, gw, 2}, alpha(WHITE_, 0.05f)); }
  DrawRectangleRec({gx + gw / 2 - 30, gy + gh - 30, 60, 10}, hex(0x1A2560));
  // стеллаж слева
  float sx = 40, sw = std::min(300.f, W * 0.2f);
  for (int k = 0; k < 2; k++) {
    float x = sx + k * (sw * 0.0f); (void)x;
  }
  DrawRectangleRec({sx, H * 0.12f, 10, H * 0.56f}, hex(0x101839)); DrawRectangleRec({sx + sw, H * 0.12f, 10, H * 0.56f}, hex(0x101839));
  for (int i = 0; i < 4; i++) {
    float y = H * 0.2f + i * H * 0.13f; DrawRectangleRec({sx, y, sw + 10, 8}, hex(0x101839));
    for (int j = 0; j < 5; j++) {
      float r = hsh(i * 7 + j * 13 + 3), bw = 30 + r * 40, bh = 30 + hsh(i * 3 + j * 5) * 40, bx = sx + 14 + j * (sw / 5.f);
      if (bx + bw > sx + sw) continue;
      int kind = (int)(hsh(i * 11 + j * 17) * 3);
      if (kind == 0) { DrawRectangleRec({bx - 2, y - bh - 2, bw + 4, bh + 2}, INK); DrawRectangleRec({bx, y - bh, bw, bh}, hex(0x3A4A86)); DrawRectangleRec({bx, y - bh, bw, 6}, hex(0x4A5DA6)); }
      else if (kind == 1) { DrawCircleV({bx + 20, y - 22}, 22, INK); DrawCircleV({bx + 20, y - 22}, 19, hex(0x161D44)); DrawCircleV({bx + 20, y - 22}, 9, hex(0x3A4A86)); }
      else { DrawRectangleRec({bx - 2, y - 38, 30, 38}, INK); DrawRectangleRec({bx, y - 36, 26, 36}, hex(0x5A3FA0 + (j % 2) * 0x103000)); DrawRectangleRec({bx, y - 30, 26, 8}, alpha(WHITE_, 0.25f)); }
    }
  }
  // перфопанель с инструментами справа
  float px = W - std::min(360.f, W * 0.24f) - 40, pw = std::min(360.f, W * 0.24f), py = H * 0.14f, ph = H * 0.3f;
  DrawRectangleRec({px - 4, py - 4, pw + 8, ph + 8}, INK); DrawRectangleRec({px, py, pw, ph}, hex(0x2D3F8C));
  for (float yy = py + 12; yy < py + ph; yy += 18) for (float xx = px + 12; xx < px + pw; xx += 18) DrawCircleV({xx, yy}, 2, alpha(INK, 0.5f));
  Color tool = hex(0x9AA6D6);
  { Xf x(px + pw * 0.2f, py + ph * 0.5f, ph * 0.38f, PI * 0.5f); lineO(x, {-0.9f, 0}, {0.6f, 0}, 0.16f, tool, 2.5f); circO(x, {0.75f, 0}, 0.25f, tool, 2.5f); circL(x, {0.85f, 0}, 0.12f, hex(0x2D3F8C)); }
  { Xf x(px + pw * 0.45f, py + ph * 0.5f, ph * 0.38f, PI * 0.5f); lineO(x, {-0.9f, 0}, {0.4f, 0}, 0.12f, hex(0x7A5230), 2.5f); polyO(x, {{0.35f, -0.35f}, {0.75f, -0.35f}, {0.75f, 0.45f}, {0.35f, 0.35f}}, tool, 2.5f); }
  { Xf x(px + pw * 0.68f, py + ph * 0.5f, ph * 0.38f, PI * 0.5f); lineO(x, {-0.9f, 0}, {-0.1f, 0}, 0.2f, hex(0xD04A3A), 2.5f); lineO(x, {-0.1f, 0}, {0.85f, 0}, 0.06f, tool, 2.5f); }
  { Xf x(px + pw * 0.86f, py + ph * 0.5f, ph * 0.38f, PI * 0.5f); lineO(x, {-0.8f, -0.12f}, {0.5f, -0.05f}, 0.1f, hex(0x3A9A5A), 2.5f); lineO(x, {-0.8f, 0.12f}, {0.5f, 0.05f}, 0.1f, hex(0x3A9A5A), 2.5f); polyO(x, {{0.45f, -0.1f}, {0.9f, -0.04f}, {0.9f, 0.04f}, {0.45f, 0.1f}}, tool, 2.5f); }
  // плакат
  float qx = px + 10, qy = py + ph + 30, qw = pw * 0.55f, qh = H * 0.2f;
  DrawRectangleRec({qx - 4, qy - 4, qw + 8, qh + 8}, INK); DrawRectangleGradientV((int)qx, (int)qy, (int)qw, (int)qh, hex(0xFF8A1F), hex(0xD8352B));
  { Xf x(qx + qw / 2, qy + qh * 0.62f, qh * 0.28f, 0); circO(x, {-0.7f, -0.3f}, 0.35f, INK, 0); circO(x, {0.7f, -0.3f}, 0.35f, INK, 0); circL(x, {-0.7f, -0.3f}, 0.22f, hex(0xFF8A1F)); circL(x, {0.7f, -0.3f}, 0.22f, hex(0xFF8A1F)); pathL(x, {{-0.7f, -0.3f}, {-0.1f, 0.2f}, {0.45f, 0.2f}, {0.7f, -0.3f}}, 0.14f, INK); pathL(x, {{0.3f, 0.5f}, {0.45f, 0.2f}}, 0.12f, INK); }
  text(F_TITLE, "МОТО", qx + qw / 2, qy + qh * 0.08f, qh * 0.2f, INK, CENTER);
  // пол
  float fy = H * 0.68f;
  DrawRectangleGradientV(0, (int)fy, (int)W + 1, (int)(H - fy) + 1, hex(0x22306E), hex(0x111838));
  DrawRectangle(0, (int)fy, (int)W + 1, 6, INK);
  float vx = W * 0.5f;
  for (int i = -14; i <= 14; i++) { float x0 = vx + i * 60.f, x1 = vx + i * 220.f; DrawLineEx({x0, fy}, {x1, H}, 2, alpha(WHITE_, 0.05f)); }
  for (int i = 1; i < 6; i++) { float y = fy + (H - fy) * (i * i) / 36.f; DrawRectangle(0, (int)y, (int)W + 1, 2, alpha(WHITE_, 0.04f)); }
  // лампа и свет
  float lx = bikeX, ly = H * 0.08f;
  DrawLineEx({lx, 0}, {lx, ly}, 3, INK);
  DrawTriangle({lx - 24, ly + 24}, {lx + 24, ly + 24}, {lx, ly}, INK);
  DrawTriangle({lx - 20, ly + 22}, {lx + 20, ly + 22}, {lx, ly + 3}, hex(0x3A4A86));
  float flick = 0.9f + 0.1f * std::sin(t * 7) * std::sin(t * 3.1f);
  for (int i = 0; i < 8; i++) { float f = i / 8.f; DrawTriangle({lx - 22 - f * 320, ly + 26 + f * (fy - ly + 60)}, {lx + 22 + f * 320, ly + 26 + f * (fy - ly + 60)}, {lx, ly + 24}, alpha(hex(0xBFD0FF), 0.018f * flick)); }
  DrawEllipse((int)lx, (int)(fy + 70), 340, 60, alpha(hex(0xBFD0FF), 0.08f * flick));
  DrawCircleV({lx, ly + 24}, 8, hex(0xFFF6D8));
  // бочка и шины
  float bx = W - 120, by = H * 0.68f + 10;
  DrawRectangleRounded({bx - 44, by - 120, 88, 130}, 0.15f, 6, INK); DrawRectangleRounded({bx - 40, by - 116, 80, 122}, 0.15f, 6, hex(0xB8352C));
  DrawRectangle((int)bx - 40, (int)by - 86, 80, 6, INK); DrawRectangle((int)bx - 40, (int)by - 36, 80, 6, INK); DrawRectangle((int)bx - 30, (int)by - 110, 14, 120, alpha(WHITE_, 0.12f));
  for (int i = 0; i < 3; i++) { float tx = 120, ty = H * 0.68f + 24 - i * 36; DrawEllipse((int)tx, (int)ty, 86, 22, INK); DrawEllipse((int)tx, (int)ty, 82, 18, hex(0x1A1F3A)); DrawEllipse((int)tx, (int)ty - 2, 40, 8, hex(0x0E1230)); }
}

// ---------- темы трасс ----------
struct Theme { Color sky0, sky1, far, mid, ground, ground2, top; int deco; bool stars; bool snow; const char* name; };
enum { D_TREE = 0, D_ROCK, D_PINE, D_CITY };
inline const Theme THEMES[] = {
  {hex(0x5FB4F0), hex(0xCDEBFF), hex(0x8DB7AE), hex(0x4F8A5A), hex(0x6B4A2B), hex(0x4E341E), hex(0x5DBB45), D_TREE, false, false, "Лес"},
  {hex(0xF0B06E), hex(0xFBE3C4), hex(0xC99A6B), hex(0xA87650), hex(0x8A5A35), hex(0x6A4224), hex(0xC48A55), D_ROCK, false, false, "Карьер"},
  {hex(0x78C8FA), hex(0xE6F7FF), hex(0xA4CFA0), hex(0x6AA86A), hex(0x5B4026), hex(0x402C18), hex(0x7CC657), D_TREE, false, false, "Холмы"},
  {hex(0x8EABD4), hex(0xEEF2F7), hex(0x8A96A8), hex(0x5F6B7D), hex(0x4A4038), hex(0x332B25), hex(0xEEF3F6), D_PINE, false, true, "Горы"},
  {hex(0x070D24), hex(0x2A3160), hex(0x1D2647), hex(0x141A31), hex(0x2A2018), hex(0x1B140E), hex(0x3B6B3B), D_PINE, true, false, "Ночь"},
  {hex(0x27397A), hex(0xE07F8E), hex(0x2B2F55), hex(0x1C1F3A), hex(0x3B3B46), hex(0x2A2A33), hex(0xA7ADB7), D_CITY, false, false, "Город"},
};

inline float ridge(float x, float s) { return std::sin(x * 0.011f + s) * 0.5f + std::sin(x * 0.027f + s * 2.1f) * 0.3f + std::sin(x * 0.06f + s * 3.7f) * 0.2f; }

inline void cloud(float x, float y, float s, Color c) {
  float pts[5][3] = {{0, 0, 1}, {0.9f, 0.2f, 0.8f}, {-0.9f, 0.15f, 0.75f}, {0.4f, -0.5f, 0.75f}, {-0.35f, -0.45f, 0.7f}};
  for (auto& p : pts) DrawCircleV({x + p[0] * s, y + p[1] * s}, p[2] * s * 0.75f + 3, alpha(INK, 0.5f));
  for (auto& p : pts) DrawCircleV({x + p[0] * s, y + p[1] * s}, p[2] * s * 0.75f, c);
  DrawRectangleRec({x - s * 1.2f, y + s * 0.05f, s * 2.4f, s * 0.55f}, c);
}

inline void skyLayers(const Theme& th, float camX, Rectangle area, float t) {
  float X = area.x, Y = area.y, W = area.width, H = area.height;
  DrawRectangleGradientV((int)X, (int)Y, (int)W + 1, (int)H + 1, th.sky0, th.sky1);
  if (th.stars) { for (int i = 0; i < 90; i++) { float sx = std::fmod(hsh(i) * W * 1.5f - camX * 2 + W * 10, W); DrawCircleV({X + sx, Y + hsh(i + 7) * H * 0.6f}, 1 + hsh(i + 3) * 1.5f, alpha(WHITE_, 0.3f + hsh(i + 99) * 0.7f)); } DrawCircleV({X + W * 0.8f, Y + H * 0.18f}, H * 0.09f, alpha(hex(0xF4F1DA), 0.15f)); DrawCircleV({X + W * 0.8f, Y + H * 0.18f}, H * 0.06f, hex(0xF4F1DA)); DrawCircleV({X + W * 0.8f + H * 0.02f, Y + H * 0.17f}, H * 0.012f, hex(0xDCD8BC)); }
  else if (th.deco != D_CITY) { DrawCircleV({X + W * 0.82f, Y + H * 0.17f}, H * 0.12f, alpha(hex(0xFFF6D0), 0.25f)); DrawCircleV({X + W * 0.82f, Y + H * 0.17f}, H * 0.075f, hex(0xFFF6D0)); }
  if (!th.stars && th.deco != D_CITY) for (int i = 0; i < 5; i++) { float cx = std::fmod(hsh(i * 5 + 1) * W * 2 - camX * 1.2f - t * 6 + W * 50, W + 300) - 150; cloud(X + cx, Y + H * (0.1f + hsh(i * 9) * 0.25f), H * (0.05f + hsh(i * 3) * 0.04f), alpha(WHITE_, 0.95f)); }
  if (th.deco == D_CITY) {
    for (int layer = 0; layer < 2; layer++) {
      float f = layer ? 7.f : 3.f, base = Y + H * (layer ? 0.8f : 0.66f), bw = layer ? 90.f : 60.f; Color c = layer ? th.mid : th.far;
      float off = camX * f; int i0 = (int)std::floor(off / bw) - 1;
      for (int i = i0; i < i0 + W / bw + 3; i++) {
        float bh = (0.15f + hsh(i * 3 + layer) * 0.35f) * H, x = X + i * bw - off;
        DrawRectangleRec({x - 2, base - bh - 2, bw - 6 + 4, bh + H}, alpha(INK, 0.6f)); DrawRectangleRec({x, base - bh, bw - 6, bh + H}, c);
        if (layer) for (float wy = base - bh + 12; wy < base - 10; wy += 18) for (float wx = x + 10; wx < x + bw - 18; wx += 16) if (hsh(i * 97 + (int)wy * 3 + (int)wx) > 0.5f) DrawRectangleRec({wx, wy, 7, 9}, alpha(hex(0xFFDC8C), 0.6f));
      }
    }
    return;
  }
  // дальние горы
  { float off = camX * 2.5f, base = Y + H * 0.62f, amp = H * 0.2f; std::vector<Vector2> P;
    P.push_back({X, Y + H}); for (float x = 0; x <= W + 12; x += 12) P.push_back({X + x, base - amp * (0.5f + 0.5f * ridge(x + off, 1))}); P.push_back({X + W, Y + H});
    for (size_t i = 1; i + 2 < P.size(); i++) DrawTriangle(P[i], {P[i].x, Y + H}, P[i + 1], th.far), DrawTriangle(P[i + 1], {P[i].x, Y + H}, {P[i + 1].x, Y + H}, th.far);
    for (size_t i = 1; i + 2 < P.size(); i++) DrawLineEx(P[i], P[i + 1], 3, alpha(INK, 0.35f));
    if (th.snow) for (size_t i = 1; i + 2 < P.size(); i++) if (P[i].y < base - amp * 0.75f) DrawTriangle(P[i], {P[i].x, P[i].y + 14}, P[i + 1], alpha(WHITE_, 0.9f)); }
  // средний слой с деревьями
  { float off = camX * 6, base = Y + H * 0.74f, amp = H * 0.1f; Color c = th.mid;
    for (float x = 0; x <= W + 10; x += 10) { float y = base - amp * (0.5f + 0.5f * ridge(x + off, 6)); DrawRectangleRec({X + x, y, 10.5f, Y + H - y}, c); }
    float step = 46; int i0 = (int)std::floor(off / step);
    for (int i = i0; i < i0 + W / step + 2; i++) { float hv = hsh(i * 13 + 5); if (hv < 0.35f) continue; float x = i * step - off; float y = base - amp * (0.5f + 0.5f * ridge(x + off, 6)) + 4; float s = 18 + hv * 22;
      if (th.deco == D_PINE) DrawTriangle({X + x, y - s * 2.2f}, {X + x - s * 0.7f, y}, {X + x + s * 0.7f, y}, shade(c, -0.18f));
      else if (th.deco == D_TREE) { DrawCircleV({X + x, y - s}, s * 0.8f, shade(c, -0.12f)); DrawCircleV({X + x - s * 0.5f, y - s * 0.6f}, s * 0.55f, shade(c, -0.08f)); }
      else DrawEllipse((int)(X + x), (int)y, (int)(s * 0.9f), (int)(s * 0.4f), shade(c, -0.1f)); }
  }
}

// ---------- камера мира ----------
struct Cam { float cx, cy, z, ox, oy; V w2s(float x, float y) const { return {ox + (x - cx) * z, oy - (y - cy) * z}; } };

inline void groundDeco(const Theme& th, const phys::Terrain& T, const Cam& c, float x0, float x1) {
  float step = 7; Xf w(0, 0, 1);
  for (float x = std::floor(x0 / step) * step; x < x1; x += step) {
    int id = (int)std::floor(x / step); float hv = hsh(id + 17); if (hv < 0.4f) continue;
    float gx = x + hsh(id * 3) * 3, gy = T.hAt(gx) - 0.1f, s = 0.55f + hv * 0.5f;
    V p = c.w2s(gx, gy); Xf x2(p.x, p.y, c.z);
    if (th.deco == D_TREE) { lineO(x2, {0, 0}, {0, 1.6f * s}, 0.22f, hex(0x5A3D22), 2.5f); circO(x2, {0, 2.3f * s}, 0.95f * s, shade(th.mid, -0.1f), 2.5f); circO(x2, {-0.55f * s, 1.85f * s}, 0.62f * s, shade(th.mid, 0.0f), 2.5f); circO(x2, {0.5f * s, 1.95f * s}, 0.55f * s, shade(th.mid, 0.08f), 2.5f); }
    else if (th.deco == D_PINE) { lineO(x2, {0, 0}, {0, 0.8f * s}, 0.18f, hex(0x4A3320), 2.5f); for (int k = 0; k < 3; k++) polyO(x2, {{-0.95f * s + k * 0.2f * s, (0.5f + k * 0.8f) * s}, {0.95f * s - k * 0.2f * s, (0.5f + k * 0.8f) * s}, {0, (1.7f + k * 0.8f) * s}}, shade(th.mid, -0.15f + k * 0.06f), 2.5f); if (th.snow) polyF(x2, {{-0.3f * s, 3.0f * s}, {0.3f * s, 3.0f * s}, {0, 3.3f * s}}, WHITE_); }
    else if (th.deco == D_ROCK) polyO(x2, {{-0.8f * s, 0}, {0.9f * s, 0}, {0.6f * s, 0.7f * s}, {-0.2f * s, 0.9f * s}, {-0.7f * s, 0.5f * s}}, shade(th.ground, 0.2f), 2.5f);
    else if (th.deco == D_CITY && hv > 0.75f) { lineO(x2, {0, 0}, {0, 3.6f}, 0.1f, hex(0x2C2F3A), 2); lineO(x2, {0, 3.6f}, {0.7f, 3.6f}, 0.1f, hex(0x2C2F3A), 2); circO(x2, {0.7f, 3.45f}, 0.16f, hex(0xFFE7A0), 2); DrawCircleV(x2.p(0.7f, 3.45f), 40, alpha(hex(0xFFE7A0), 0.08f)); }
  }
}

inline void terrain(const Theme& th, const phys::Terrain& T, const Cam& c, float x0, float x1) {
  int i0 = std::max(0, (int)std::floor((x0 - T.x0) / phys::DX)), i1 = std::min((int)T.h.size() - 1, (int)std::ceil((x1 - T.x0) / phys::DX));
  float bottom = VH + 20;
  for (int i = i0; i < i1; i++) {
    V a = c.w2s(T.x0 + i * phys::DX, T.h[i]), b = c.w2s(T.x0 + (i + 1) * phys::DX, T.h[i + 1]);
    DrawTriangle(a, {a.x, bottom}, b, th.ground); DrawTriangle(b, {a.x, bottom}, {b.x, bottom}, th.ground);
    V a2 = {a.x, a.y + c.z * 0.9f}, b2 = {b.x, b.y + c.z * 0.9f};
    DrawTriangle(a2, {a.x, bottom}, b2, th.ground2); DrawTriangle(b2, {a.x, bottom}, {b.x, bottom}, th.ground2);
  }
  // камешки
  for (int i = i0; i < i1; i += 3) { float hv = hsh(i * 7 + 1); if (hv < 0.55f) continue; float x = T.x0 + i * phys::DX; V p = c.w2s(x, T.h[i] - 0.5f - hv * 1.4f); DrawEllipse((int)p.x, (int)p.y, (int)(c.z * (0.12f + hv * 0.12f)), (int)(c.z * 0.08f), shade(th.ground, hv > 0.8f ? 0.15f : -0.2f)); }
  // верхний слой
  float tw = th.deco == D_CITY ? 0.35f : 0.28f;
  for (int i = i0; i < i1; i++) { V a = c.w2s(T.x0 + i * phys::DX, T.h[i]), b = c.w2s(T.x0 + (i + 1) * phys::DX, T.h[i + 1]); DrawLineEx({a.x, a.y + tw * c.z * 0.5f + 1}, {b.x, b.y + tw * c.z * 0.5f + 1}, tw * c.z + 6, INK); }
  for (int i = i0; i < i1; i++) { V a = c.w2s(T.x0 + i * phys::DX, T.h[i]), b = c.w2s(T.x0 + (i + 1) * phys::DX, T.h[i + 1]); DrawLineEx({a.x, a.y + tw * c.z * 0.5f}, {b.x, b.y + tw * c.z * 0.5f}, tw * c.z, th.top); DrawCircleV(b, 0.1f, th.top); }
  for (int i = i0; i < i1; i++) { V a = c.w2s(T.x0 + i * phys::DX, T.h[i]), b = c.w2s(T.x0 + (i + 1) * phys::DX, T.h[i + 1]); DrawLineEx({a.x, a.y + 2}, {b.x, b.y + 2}, 3, shade(th.top, 0.25f)); }
  if (th.deco == D_CITY) { for (int i = i0; i < i1; i++) if ((i / 4) % 2 == 0) { V a = c.w2s(T.x0 + i * phys::DX, T.h[i] - 0.7f), b = c.w2s(T.x0 + (i + 1) * phys::DX, T.h[i + 1] - 0.7f); DrawLineEx(a, b, c.z * 0.08f, alpha(WHITE_, 0.5f)); } }
  else if (th.deco != D_ROCK) for (int i = i0; i < i1; i += 2) { float hv = hsh(i * 13 + 9); if (hv < 0.5f) continue; V p = c.w2s(T.x0 + i * phys::DX, T.h[i]); float s = c.z * 0.14f;
    DrawTriangle({p.x - s * 0.6f, p.y + 1}, {p.x + s * 0.6f, p.y + 1}, {p.x - s * 0.2f, p.y - s * 1.3f}, shade(th.top, -0.12f)); DrawTriangle({p.x - s * 0.1f, p.y + 1}, {p.x + s, p.y + 1}, {p.x + s * 0.5f, p.y - s}, shade(th.top, -0.05f)); }
}

inline void flagPole(const Cam& c, float x, float y, bool passed, float t) {
  V p = c.w2s(x, y); Xf f(p.x, p.y, c.z); Color fc = passed ? GRN : ORG;
  lineO(f, {0, 0}, {0, 3.0f}, 0.1f, hex(0xE6E9EE), 2.5f);
  float wv = std::sin(t * 6 + x) * 0.08f;
  polyO(f, {{0.05f, 2.95f}, {1.1f, 2.75f + wv}, {1.05f, 2.25f + wv}, {0.05f, 2.25f}}, fc, 2.5f);
  if (passed) { Xf ic = f.sub(0.55f, 2.55f, 0, 0.18f); pathL(ic, {{-0.7f, 0}, {-0.2f, -0.5f}, {0.7f, 0.5f}}, 0.35f, WHITE_); }
}
inline void finishArch(const Cam& c, float x, float y) {
  V p = c.w2s(x, y); Xf f(p.x, p.y, c.z);
  lineO(f, {-0.2f, 0}, {-0.2f, 4.2f}, 0.22f, hex(0xE6E9EE), 3); lineO(f, {3.4f, 0}, {3.4f, 4.2f}, 0.22f, hex(0xE6E9EE), 3);
  polyO(f, {{-0.4f, 4.6f}, {3.6f, 4.6f}, {3.6f, 3.5f}, {-0.4f, 3.5f}}, WHITE_, 3);
  for (int i = 0; i < 10; i++) for (int j = 0; j < 3; j++) if ((i + j) % 2) polyF(f, {{-0.4f + i * 0.4f, 4.6f - j * 0.366f}, {-0.4f + (i + 1) * 0.4f, 4.6f - j * 0.366f}, {-0.4f + (i + 1) * 0.4f, 4.6f - (j + 1) * 0.366f}, {-0.4f + i * 0.4f, 4.6f - (j + 1) * 0.366f}}, hex(0x15161A));
  V tp = f.p(1.6f, 5.25f); textO(F_TITLE, "ФИНИШ", tp.x, tp.y - c.z * 0.45f, c.z * 0.75f, YEL, 3, INK, CENTER);
}

} // namespace art
