// gfx.hpp — примитивы с обводкой, текст, иконки, базовые виджеты
#pragma once
#include "raylib.h"
#include "rlgl.h"
#include <vector>
#include <cmath>
#include <string>
#include <cstring>
#include <cstdio>
#include <algorithm>

namespace gfx {

// ---------- палитра ----------
inline Color hex(uint32_t c, unsigned char a = 255) { return Color{(unsigned char)(c >> 16), (unsigned char)(c >> 8), (unsigned char)c, a}; }
inline Color mix(Color a, Color b, float t) { return Color{(unsigned char)(a.r + (b.r - a.r) * t), (unsigned char)(a.g + (b.g - a.g) * t), (unsigned char)(a.b + (b.b - a.b) * t), (unsigned char)(a.a + (b.a - a.a) * t)}; }
inline Color shade(Color c, float k) { return k < 0 ? mix(c, Color{0, 0, 0, c.a}, -k) : mix(c, Color{255, 255, 255, c.a}, k); }
inline Color alpha(Color c, float a) { c.a = (unsigned char)(c.a * std::clamp(a, 0.f, 1.f)); return c; }

const Color INK = hex(0x0B1029);        // обводка
const Color NAVY0 = hex(0x10173A);
const Color NAVY1 = hex(0x1B2558);
const Color NAVY2 = hex(0x26357A);
const Color NAVY3 = hex(0x34479A);
const Color NAVY4 = hex(0x4A63C9);
const Color MUTED = hex(0xA9B6E6);
const Color GRN = hex(0x5BD63A);
const Color GRN_D = hex(0x2F9A1E);
const Color YEL = hex(0xFFD23F);
const Color ORG = hex(0xFF8A1F);
const Color REDC = hex(0xE5484D);
const Color CYAN = hex(0x35D0E0);
const Color WHITE_ = hex(0xFFFFFF);

// ---------- виртуальный экран ----------
inline float VH = 720, VW = 1280, S = 1;
inline void updateScreen() { S = GetScreenHeight() / VH; VW = GetScreenWidth() / S; }
// единый указатель: мышь или первое касание (на вебе касания не превращаются в клики мыши)
inline bool pDown = false, pPrev = false; inline Vector2 pPos{0, 0};
inline void updatePointer() {
  pPrev = pDown; int n = GetTouchPointCount();
  if (n > 0) { Vector2 t = GetTouchPosition(0); pPos = {t.x / S, t.y / S}; pDown = true; }
  else { bool md = IsMouseButtonDown(MOUSE_BUTTON_LEFT); if (md || !pPrev) { Vector2 m = GetMousePosition(); pPos = {m.x / S, m.y / S}; } pDown = md; }
}
inline bool pPressed() { return pDown && !pPrev; }
inline bool pReleased() { return !pDown && pPrev; }
inline Vector2 mouse() { return pPos; }

// ---------- трансформация: локальные (y вверх) -> виртуальный экран ----------
struct Xf {
  float tx = 0, ty = 0, c = 1, s = 0, k = 1;
  Xf() {}
  Xf(float x, float y, float scale, float ang = 0) : tx(x), ty(y), c(std::cos(ang)), s(std::sin(ang)), k(scale) {}
  Vector2 p(float x, float y) const { return {tx + k * (x * c - y * s), ty - k * (x * s + y * c)}; }
  Vector2 p(Vector2 v) const { return p(v.x, v.y); }
  Xf sub(float x, float y, float ang = 0, float sc = 1) const { // вложенная система
    Vector2 o = p(x, y); Xf r; r.tx = o.x; r.ty = o.y; float ca = std::cos(ang), sa = std::sin(ang);
    r.c = c * ca - s * sa; r.s = s * ca + c * sa; r.k = k * sc; return r;
  }
};

// ---------- триангуляция (ear clipping) ----------
inline float cross(Vector2 o, Vector2 a, Vector2 b) { return (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x); }
inline bool inTri(Vector2 p, Vector2 a, Vector2 b, Vector2 c) {
  float d1 = cross(p, a, b), d2 = cross(p, b, c), d3 = cross(p, c, a);
  bool neg = (d1 < 0) || (d2 < 0) || (d3 < 0), pos = (d1 > 0) || (d2 > 0) || (d3 > 0);
  return !(neg && pos);
}
inline void fillPoly(const std::vector<Vector2>& P, Color col) {
  int n = (int)P.size(); if (n < 3) return;
  if (n == 3) { DrawTriangle(P[0], P[1], P[2], col); return; }
  float area = 0; for (int i = 0; i < n; i++) { const Vector2 &a = P[i], &b = P[(i + 1) % n]; area += a.x * b.y - b.x * a.y; }
  std::vector<int> idx(n); for (int i = 0; i < n; i++) idx[i] = area > 0 ? i : n - 1 - i;
  int guard = 0;
  while (idx.size() > 3 && guard++ < 2000) {
    bool cut = false; int m = (int)idx.size();
    for (int i = 0; i < m; i++) {
      Vector2 a = P[idx[(i + m - 1) % m]], b = P[idx[i]], c = P[idx[(i + 1) % m]];
      if (cross(a, b, c) <= 0) continue;
      bool ok = true;
      for (int j = 0; j < m && ok; j++) { int q = idx[j]; if (q == idx[(i + m - 1) % m] || q == idx[i] || q == idx[(i + 1) % m]) continue; if (inTri(P[q], a, b, c)) ok = false; }
      if (!ok) continue;
      DrawTriangle(a, b, c, col); idx.erase(idx.begin() + i); cut = true; break;
    }
    if (!cut) break;
  }
  if (idx.size() == 3) DrawTriangle(P[idx[0]], P[idx[1]], P[idx[2]], col);
  else if (idx.size() > 3) for (size_t i = 1; i + 1 < idx.size(); i++) DrawTriangle(P[idx[0]], P[idx[i]], P[idx[i + 1]], col);
}
inline void strokePoly(const std::vector<Vector2>& P, float w, Color col, bool closed = true) {
  int n = (int)P.size(); if (n < 2) return;
  for (int i = 0; i < n - (closed ? 0 : 1); i++) DrawLineEx(P[i], P[(i + 1) % n], w, col);
  for (auto& v : P) DrawCircleV(v, w * 0.5f, col);
}

// ---------- примитивы в локальных координатах ----------
inline float OUT = 3.0f; // толщина обводки (вирт. пиксели)
inline std::vector<Vector2> tf(const Xf& x, std::initializer_list<Vector2> pts) { std::vector<Vector2> r; r.reserve(pts.size()); for (auto& p : pts) r.push_back(x.p(p)); return r; }
inline std::vector<Vector2> tf(const Xf& x, const std::vector<Vector2>& pts) { std::vector<Vector2> r; r.reserve(pts.size()); for (auto& p : pts) r.push_back(x.p(p)); return r; }

inline void polyO(const Xf& x, const std::vector<Vector2>& loc, Color fill, float o = -1, Color oc = INK) {
  auto P = tf(x, loc); if (o < 0) o = OUT; if (o > 0) strokePoly(P, o * 2, oc); fillPoly(P, fill);
}
inline void polyF(const Xf& x, const std::vector<Vector2>& loc, Color fill) { fillPoly(tf(x, loc), fill); }
inline void lineL(const Xf& x, Vector2 a, Vector2 b, float wLoc, Color c) { Vector2 A = x.p(a), B = x.p(b); float w = wLoc * x.k; DrawLineEx(A, B, w, c); DrawCircleV(A, w / 2, c); DrawCircleV(B, w / 2, c); }
inline void lineO(const Xf& x, Vector2 a, Vector2 b, float wLoc, Color c, float o = -1) { if (o < 0) o = OUT; lineL(x, a, b, wLoc + 2 * o / x.k, INK); lineL(x, a, b, wLoc, c); }
inline void pathL(const Xf& x, const std::vector<Vector2>& pts, float wLoc, Color c) { for (size_t i = 0; i + 1 < pts.size(); i++) lineL(x, pts[i], pts[i + 1], wLoc, c); }
inline void pathO(const Xf& x, const std::vector<Vector2>& pts, float wLoc, Color c, float o = -1) { if (o < 0) o = OUT; pathL(x, pts, wLoc + 2 * o / x.k, INK); pathL(x, pts, wLoc, c); }
inline void circL(const Xf& x, Vector2 c, float r, Color col) { DrawCircleV(x.p(c), r * x.k, col); }
inline void circO(const Xf& x, Vector2 c, float r, Color col, float o = -1) { if (o < 0) o = OUT; Vector2 C = x.p(c); DrawCircleV(C, r * x.k + o, INK); DrawCircleV(C, r * x.k, col); }
inline void ringL(const Xf& x, Vector2 c, float r0, float r1, Color col) { DrawRing(x.p(c), r0 * x.k, r1 * x.k, 0, 360, 36, col); }

inline std::vector<Vector2> bez(Vector2 a, Vector2 b, Vector2 c, int n = 10) { std::vector<Vector2> r; for (int i = 0; i <= n; i++) { float t = (float)i / n, u = 1 - t; r.push_back({u * u * a.x + 2 * u * t * b.x + t * t * c.x, u * u * a.y + 2 * u * t * b.y + t * t * c.y}); } return r; }
inline std::vector<Vector2> arc(Vector2 c, float r, float a0, float a1, int n = 14) { std::vector<Vector2> v; for (int i = 0; i <= n; i++) { float a = a0 + (a1 - a0) * i / n; v.push_back({c.x + r * std::cos(a), c.y + r * std::sin(a)}); } return v; }
inline std::vector<Vector2> rrect(float x0, float y0, float x1, float y1, float r, int n = 4) { // прямоугольник со скруглением (y вверх)
  std::vector<Vector2> v; auto add = [&](std::vector<Vector2> a) { v.insert(v.end(), a.begin(), a.end()); };
  add(arc({x1 - r, y0 + r}, r, -PI / 2, 0, n)); add(arc({x1 - r, y1 - r}, r, 0, PI / 2, n)); add(arc({x0 + r, y1 - r}, r, PI / 2, PI, n)); add(arc({x0 + r, y0 + r}, r, PI, PI * 1.5f, n)); return v;
}

// ---------- шрифты и текст ----------
inline Font F_TITLE, F_BOLD, F_BLACK;
inline void loadFonts() {
  std::vector<int> cps; for (int c = 32; c < 127; c++) cps.push_back(c);
  for (int c = 0x410; c <= 0x44F; c++) cps.push_back(c);
  int extra[] = {0x401, 0x451, 0x2014, 0x2013, 0xAB, 0xBB, 0xB7, 0x2026, 0xD7, 0x2116, 0xB0};
  for (int e : extra) cps.push_back(e);
  auto ld = [&](const char* f, int sz) { Font fn = LoadFontEx(f, sz, cps.data(), (int)cps.size()); GenTextureMipmaps(&fn.texture); SetTextureFilter(fn.texture, TEXTURE_FILTER_TRILINEAR); return fn; };
  F_TITLE = ld("fonts/RussoOne-Regular.ttf", 96);
  F_BOLD = ld("fonts/Rubik-Bold.ttf", 72);
  F_BLACK = ld("fonts/Rubik-Black.ttf", 96);
}
enum Align { LEFT = 0, CENTER = 1, RIGHT = 2 };
inline Vector2 measure(const Font& f, const char* s, float size) { return MeasureTextEx(f, s, size, size * 0.02f); }
inline void text(const Font& f, const char* s, float x, float y, float size, Color c, int al = LEFT) {
  Vector2 m = measure(f, s, size); if (al == CENTER) x -= m.x / 2; else if (al == RIGHT) x -= m.x;
  DrawTextEx(f, s, {std::round(x * S) / S, std::round(y * S) / S}, size, size * 0.02f, c);
}
inline void textO(const Font& f, const char* s, float x, float y, float size, Color c, float o = 3, Color oc = INK, int al = LEFT, float shadow = 0) {
  Vector2 m = measure(f, s, size); if (al == CENTER) x -= m.x / 2; else if (al == RIGHT) x -= m.x;
  if (shadow > 0) for (int i = 0; i < 12; i++) { float a = i * PI / 6; DrawTextEx(f, s, {x + std::cos(a) * o, y + shadow + std::sin(a) * o}, size, size * 0.02f, oc); }
  for (int i = 0; i < 12; i++) { float a = i * PI / 6; DrawTextEx(f, s, {x + std::cos(a) * o, y + std::sin(a) * o}, size, size * 0.02f, oc); }
  DrawTextEx(f, s, {x, y}, size, size * 0.02f, c);
}
inline const char* fmtNum(long n) {
  static char buf[8][32]; static int k = 0; k = (k + 1) % 8;
  if (n >= 100000) snprintf(buf[k], 32, "%ldK", n / 1000);
  else if (n >= 10000) snprintf(buf[k], 32, "%.1fK", n / 1000.0);
  else snprintf(buf[k], 32, "%ld", n);
  return buf[k];
}

// ---------- панели и кнопки ----------
inline void rbox(Rectangle r, float rad, Color c) { float m = std::min(r.width, r.height); if (m <= 0) return; DrawRectangleRounded(r, std::min(1.f, 2 * rad / m), 10, c); }
inline void panel(Rectangle r, Color fill = NAVY2, float rad = 22, float o = 4, bool shadow = true) {
  if (shadow) rbox({r.x, r.y + 7, r.width, r.height}, rad, alpha(INK, 0.8f));
  rbox({r.x - o, r.y - o, r.width + 2 * o, r.height + 2 * o}, rad + o, INK);
  rbox(r, rad, fill);
  rbox({r.x + 6, r.y + 5, r.width - 12, std::min(r.height * 0.4f, 26.f)}, rad * 0.7f, alpha(WHITE_, 0.06f));
}
inline void inset(Rectangle r, Color fill = NAVY1, float rad = 14) { rbox(r, rad, fill); rbox({r.x, r.y, r.width, 4}, 2, alpha(INK, 0.35f)); }

// ввод для кнопок
inline int activeId = 0; inline bool clickedThisFrame = false; inline bool dragging = false;
inline bool hit(Rectangle r, Vector2 p) { return CheckCollisionPointRec(p, r); }
inline bool button(int id, Rectangle r, bool enabled = true) {
  Vector2 m = mouse();
  if (pPressed() && hit(r, m)) activeId = id;
  bool res = false;
  if (pReleased()) { if (activeId == id && hit(r, m) && enabled && !dragging) res = true; if (activeId == id) activeId = 0; }
  return res;
}
inline bool pressed(int id) { return activeId == id && pDown; }

inline void btnFace(Rectangle r, Color base, bool down, float rad = 18, bool enabled = true) {
  if (!enabled) base = mix(base, NAVY2, 0.65f);
  float d = down ? 5 : 0, depth = 7;
  rbox({r.x - 4, r.y - 4 + d, r.width + 8, r.height + 8 - d + (down ? 0 : 0)}, rad + 4, INK);
  rbox({r.x, r.y + d, r.width, r.height - d}, rad, shade(base, -0.38f));
  rbox({r.x, r.y + d, r.width, r.height - depth}, rad, base);
  rbox({r.x + 7, r.y + d + 5, r.width - 14, (r.height - depth) * 0.36f}, rad * 0.6f, alpha(WHITE_, 0.18f));
}

// ---------- иконки (рисуются в квадрате size, центр cx,cy) ----------
enum Icon { IC_WRENCH, IC_CART, IC_PAINT, IC_TASKS, IC_GEAR, IC_FLAG, IC_TROPHY, IC_COIN, IC_LOCK, IC_BACK, IC_PLAY, IC_PAUSE, IC_ENGINE, IC_WHEEL, IC_SPRING, IC_FRAME, IC_TIMER, IC_STAR, IC_CHECK, IC_RESTART, IC_HOME, IC_SOUND, IC_MUTE, IC_LEAN_B, IC_LEAN_F, IC_BOLT, IC_ARROW_L, IC_ARROW_R, IC_HELMET, IC_PEDAL, IC_THROTTLE, IC_SKULL, IC_GAS, IC_BRAKE };

inline void coin(float cx, float cy, float r) {
  DrawCircleV({cx, cy}, r + 3, INK); DrawCircleV({cx, cy}, r, hex(0xF5A623)); DrawCircleV({cx, cy - r * 0.08f}, r * 0.86f, YEL);
  DrawRing({cx, cy - r * 0.08f}, r * 0.52f, r * 0.66f, 0, 360, 24, hex(0xF5A623));
  DrawRectangleRec({cx - r * 0.12f, cy - r * 0.42f, r * 0.24f, r * 0.7f}, hex(0xF5A623));
  DrawCircleV({cx - r * 0.35f, cy - r * 0.45f}, r * 0.14f, alpha(WHITE_, 0.7f));
}

inline void icon(Icon ic, float cx, float cy, float size, Color c = WHITE_, float o = 3) {
  Xf x(cx, cy, size / 2); float L = 2.0f / size; (void)L;
  auto ln = [&](Vector2 a, Vector2 b, float w, Color col) { lineO(x, a, b, w, col, o); };
  switch (ic) {
    case IC_WRENCH: {
      ln({-0.55f, -0.55f}, {0.25f, 0.25f}, 0.28f, c);
      circO(x, {0.38f, 0.38f}, 0.38f, c, o);
      polyF(x, {{0.38f, 0.38f}, {0.95f, 0.55f}, {0.55f, 0.95f}}, alpha(NAVY2, 1)); circL(x, {0.38f, 0.38f}, 0.13f, NAVY2);
      Xf y = x; (void)y; break; }
    case IC_CART: {
      pathO(x, {{-0.9f, 0.6f}, {-0.6f, 0.6f}, {-0.35f, -0.3f}, {0.6f, -0.3f}}, 0.12f, c, o);
      polyO(x, {{-0.52f, 0.35f}, {0.85f, 0.35f}, {0.65f, -0.15f}, {-0.38f, -0.15f}}, c, o);
      for (float gx = -0.25f; gx < 0.7f; gx += 0.28f) lineL(x, {gx, 0.3f}, {gx + 0.04f, -0.1f}, 0.05f, NAVY2);
      circO(x, {-0.25f, -0.62f}, 0.13f, c, o); circO(x, {0.5f, -0.62f}, 0.13f, c, o); break; }
    case IC_PAINT: {
      polyO(x, rrect(-0.75f, 0.2f, 0.55f, 0.75f, 0.12f), c, o);
      pathO(x, {{0.55f, 0.48f}, {0.82f, 0.48f}, {0.82f, 0.0f}, {-0.1f, -0.1f}, {-0.1f, -0.3f}}, 0.1f, c, o);
      polyO(x, rrect(-0.22f, -0.95f, 0.02f, -0.3f, 0.08f), shade(c, -0.25f), o);
      polyF(x, rrect(-0.65f, 0.3f, 0.45f, 0.48f, 0.06f), alpha(ORG, 0.9f)); break; }
    case IC_TASKS: {
      polyO(x, rrect(-0.7f, -0.9f, 0.7f, 0.75f, 0.14f), c, o);
      polyO(x, rrect(-0.32f, 0.6f, 0.32f, 0.92f, 0.1f), shade(c, -0.3f), o);
      for (int i = 0; i < 3; i++) { float yy = 0.3f - i * 0.42f; lineL(x, {-0.45f, yy}, {-0.3f, yy - 0.12f}, 0.09f, GRN_D); lineL(x, {-0.3f, yy - 0.12f}, {-0.1f, yy + 0.12f}, 0.09f, GRN_D); lineL(x, {0.05f, yy}, {0.48f, yy}, 0.09f, NAVY3); }
      break; }
    case IC_GEAR: {
      std::vector<Vector2> g; for (int i = 0; i < 16; i++) { float a = i * PI / 8 + PI / 16, r = (i % 2 == 0) ? 0.95f : 0.68f; g.push_back({std::cos(a - 0.1f) * r, std::sin(a - 0.1f) * r}); g.push_back({std::cos(a + 0.1f) * r, std::sin(a + 0.1f) * r}); }
      polyO(x, g, c, o); circO(x, {0, 0}, 0.3f, NAVY2, 0); circL(x, {0, 0}, 0.27f, NAVY2); break; }
    case IC_FLAG: {
      ln({-0.7f, -0.95f}, {-0.7f, 0.9f}, 0.12f, hex(0xDDDDDD));
      polyO(x, {{-0.66f, 0.85f}, {0.85f, 0.85f}, {0.85f, -0.05f}, {-0.66f, -0.05f}}, WHITE_, o);
      for (int i = 0; i < 6; i++) for (int j = 0; j < 3; j++) if ((i + j) % 2) polyF(x, {{-0.66f + i * 0.252f, 0.85f - j * 0.3f}, {-0.66f + (i + 1) * 0.252f, 0.85f - j * 0.3f}, {-0.66f + (i + 1) * 0.252f, 0.55f - j * 0.3f}, {-0.66f + i * 0.252f, 0.55f - j * 0.3f}}, hex(0x15161A));
      break; }
    case IC_TROPHY: {
      pathO(x, arc({-0.55f, 0.35f}, 0.28f, PI * 0.5f, PI * 1.5f), 0.1f, c, o); pathO(x, arc({0.55f, 0.35f}, 0.28f, -PI * 0.5f, PI * 0.5f), 0.1f, c, o);
      polyO(x, {{-0.6f, 0.75f}, {0.6f, 0.75f}, {0.45f, 0.05f}, {0.15f, -0.2f}, {-0.15f, -0.2f}, {-0.45f, 0.05f}}, c, o);
      polyO(x, {{-0.12f, -0.2f}, {0.12f, -0.2f}, {0.18f, -0.55f}, {-0.18f, -0.55f}}, c, o);
      polyO(x, rrect(-0.5f, -0.9f, 0.5f, -0.55f, 0.08f), shade(c, -0.25f), o); break; }
    case IC_COIN: coin(cx, cy, size * 0.42f); break;
    case IC_LOCK: {
      pathO(x, arc({0, 0.15f}, 0.42f, 0, PI), 0.16f, hex(0xC9CED6), o); lineO(x, {-0.42f, 0.15f}, {-0.42f, -0.1f}, 0.16f, hex(0xC9CED6), o); lineO(x, {0.42f, 0.15f}, {0.42f, -0.1f}, 0.16f, hex(0xC9CED6), o);
      polyO(x, rrect(-0.68f, -0.9f, 0.68f, 0.02f, 0.14f), YEL, o); circL(x, {0, -0.35f}, 0.14f, INK); lineL(x, {0, -0.4f}, {0, -0.65f}, 0.1f, INK); break; }
    case IC_BACK: { polyO(x, {{-0.85f, 0}, {-0.1f, 0.7f}, {-0.1f, 0.3f}, {0.8f, 0.3f}, {0.8f, -0.3f}, {-0.1f, -0.3f}, {-0.1f, -0.7f}}, c, o); break; }
    case IC_PLAY: polyO(x, {{-0.5f, 0.75f}, {0.8f, 0}, {-0.5f, -0.75f}}, c, o); break;
    case IC_PAUSE: polyO(x, rrect(-0.6f, -0.7f, -0.15f, 0.7f, 0.1f), c, o); polyO(x, rrect(0.15f, -0.7f, 0.6f, 0.7f, 0.1f), c, o); break;
    case IC_ENGINE: {
      polyO(x, rrect(-0.75f, -0.6f, 0.6f, 0.35f, 0.12f), hex(0x8A93A3), o);
      for (int i = 0; i < 5; i++) lineL(x, {-0.6f + i * 0.28f, 0.3f}, {-0.6f + i * 0.28f, 0.75f}, 0.13f, INK), lineL(x, {-0.6f + i * 0.28f, 0.33f}, {-0.6f + i * 0.28f, 0.7f}, 0.07f, hex(0xB9C0CC));
      circO(x, {-0.12f, -0.15f}, 0.25f, hex(0x5D6573), o); polyO(x, rrect(0.55f, -0.25f, 0.92f, 0.05f, 0.06f), hex(0x5D6573), o); break; }
    case IC_WHEEL: {
      circO(x, {0, 0}, 0.92f, hex(0x22242A), o); for (int i = 0; i < 12; i++) { float a = i * PI / 6; polyF(x, {{std::cos(a - 0.12f) * 0.98f, std::sin(a - 0.12f) * 0.98f}, {std::cos(a + 0.12f) * 0.98f, std::sin(a + 0.12f) * 0.98f}, {std::cos(a + 0.12f) * 0.8f, std::sin(a + 0.12f) * 0.8f}, {std::cos(a - 0.12f) * 0.8f, std::sin(a - 0.12f) * 0.8f}}, INK); }
      ringL(x, {0, 0}, 0.5f, 0.66f, hex(0xC9CED6)); for (int i = 0; i < 6; i++) { float a = i * PI / 3; lineL(x, {0, 0}, {std::cos(a) * 0.55f, std::sin(a) * 0.55f}, 0.07f, hex(0xC9CED6)); }
      circL(x, {0, 0}, 0.16f, hex(0xE6E9EE)); break; }
    case IC_SPRING: {
      lineO(x, {0, -0.95f}, {0, 0.95f}, 0.18f, hex(0x6C7380), o);
      std::vector<Vector2> sp; for (int i = 0; i <= 14; i++) sp.push_back({(i % 2 ? 0.42f : -0.42f), -0.62f + i * 0.088f});
      pathO(x, sp, 0.13f, c.r == 255 && c.g == 255 ? YEL : c, o);
      polyO(x, rrect(-0.35f, 0.62f, 0.35f, 0.82f, 0.05f), hex(0x9AA1AD), o); polyO(x, rrect(-0.35f, -0.82f, 0.35f, -0.62f, 0.05f), hex(0x9AA1AD), o); break; }
    case IC_FRAME: { pathO(x, {{-0.85f, -0.5f}, {-0.2f, 0.55f}, {0.7f, 0.55f}, {0.2f, -0.45f}, {-0.85f, -0.5f}}, 0.16f, c, o); lineO(x, {0.7f, 0.55f}, {0.85f, -0.7f}, 0.16f, c, o); break; }
    case IC_TIMER: { circO(x, {0, -0.08f}, 0.78f, c, o); circL(x, {0, -0.08f}, 0.62f, NAVY1); lineL(x, {0, -0.08f}, {0, 0.38f}, 0.12f, c); lineL(x, {0, -0.08f}, {0.3f, -0.2f}, 0.12f, c); polyO(x, rrect(-0.18f, 0.72f, 0.18f, 0.95f, 0.05f), c, o); break; }
    case IC_STAR: { std::vector<Vector2> st; for (int i = 0; i < 10; i++) { float a = PI / 2 + i * PI / 5, r = i % 2 ? 0.42f : 0.95f; st.push_back({std::cos(a) * r, std::sin(a) * r}); } polyO(x, st, c, o); break; }
    case IC_CHECK: pathO(x, {{-0.7f, 0.0f}, {-0.2f, -0.5f}, {0.75f, 0.55f}}, 0.24f, c, o); break;
    case IC_RESTART: { auto a = arc({0, 0}, 0.62f, 0.5f, PI * 1.85f, 18); pathO(x, a, 0.2f, c, o); Vector2 e = a.front(); polyO(x, {{e.x + 0.35f, e.y + 0.05f}, {e.x - 0.3f, e.y + 0.25f}, {e.x - 0.05f, e.y - 0.4f}}, c, o); break; }
    case IC_HOME: { polyO(x, {{-0.9f, 0.05f}, {0, 0.9f}, {0.9f, 0.05f}, {0.65f, 0.05f}, {0.65f, -0.85f}, {-0.65f, -0.85f}, {-0.65f, 0.05f}}, c, o); polyF(x, rrect(-0.2f, -0.85f, 0.2f, -0.25f, 0.06f), NAVY2); break; }
    case IC_SOUND: case IC_MUTE: {
      polyO(x, {{-0.85f, 0.3f}, {-0.45f, 0.3f}, {0.05f, 0.75f}, {0.05f, -0.75f}, {-0.45f, -0.3f}, {-0.85f, -0.3f}}, c, o);
      if (ic == IC_SOUND) { pathO(x, arc({0.05f, 0}, 0.4f, -0.8f, 0.8f, 8), 0.1f, c, o); pathO(x, arc({0.05f, 0}, 0.72f, -0.8f, 0.8f, 10), 0.1f, c, o); }
      else { ln({0.3f, 0.35f}, {0.9f, -0.35f}, 0.14f, REDC); ln({0.3f, -0.35f}, {0.9f, 0.35f}, 0.14f, REDC); }
      break; }
    case IC_LEAN_B: case IC_LEAN_F: {
      float s = ic == IC_LEAN_B ? 1.f : -1.f;
      auto a = arc({0, -0.15f}, 0.62f, s > 0 ? -0.2f : PI + 0.2f, s > 0 ? PI * 0.95f : PI * 0.05f, 18);
      pathO(x, a, 0.22f, c, o); Vector2 e = a.back();
      polyO(x, {{e.x - 0.33f * s, e.y + 0.3f}, {e.x + 0.33f * s, e.y + 0.18f}, {e.x - 0.05f * s, e.y - 0.4f}}, c, o);
      break; }
    case IC_BOLT: polyO(x, {{0.15f, 0.95f}, {-0.6f, -0.1f}, {-0.05f, -0.1f}, {-0.2f, -0.95f}, {0.6f, 0.15f}, {0.05f, 0.15f}}, c, o); break;
    case IC_ARROW_L: polyO(x, {{0.45f, 0.8f}, {-0.45f, 0}, {0.45f, -0.8f}}, c, o); break;
    case IC_ARROW_R: polyO(x, {{-0.45f, 0.8f}, {0.45f, 0}, {-0.45f, -0.8f}}, c, o); break;
    case IC_HELMET: {
      polyO(x, {{-0.85f, -0.2f}, {-0.8f, 0.35f}, {-0.4f, 0.8f}, {0.2f, 0.85f}, {0.7f, 0.5f}, {0.88f, 0.0f}, {0.85f, -0.55f}, {0.2f, -0.6f}, {-0.3f, -0.75f}, {-0.8f, -0.6f}}, c, o);
      polyO(x, {{0.05f, 0.25f}, {0.82f, 0.22f}, {0.8f, -0.25f}, {0.15f, -0.2f}}, hex(0x1B2433), o);
      lineL(x, {-0.6f, 0.45f}, {0.1f, 0.72f}, 0.12f, WHITE_); break; }
    case IC_PEDAL: { polyO(x, rrect(-0.55f, -0.85f, 0.55f, 0.6f, 0.2f), c, o); for (int i = 0; i < 4; i++) lineL(x, {-0.32f, 0.35f - i * 0.33f}, {0.32f, 0.35f - i * 0.33f}, 0.1f, shade(c, -0.35f)); break; }
    case IC_THROTTLE: { polyO(x, rrect(-0.38f, -0.95f, 0.38f, 0.95f, 0.3f), c, o); for (int i = 0; i < 7; i++) lineL(x, {-0.22f, 0.65f - i * 0.22f}, {0.22f, 0.65f - i * 0.22f}, 0.07f, shade(c, -0.35f)); break; }
    case IC_GAS: { for (int k = 0; k < 2; k++) { float ox = -0.42f + k * 0.62f; polyO(x, {{ox - 0.25f, 0.75f}, {ox + 0.15f, 0.75f}, {ox + 0.6f, 0.0f}, {ox + 0.15f, -0.75f}, {ox - 0.25f, -0.75f}, {ox + 0.2f, 0.0f}}, c, o); } break; }
    case IC_BRAKE: { circO(x, {0, 0}, 0.8f, hex(0xC9CED6), o); for (int k = 0; k < 8; k++) { float a = k * PI / 4; circL(x, {std::cos(a) * 0.55f, std::sin(a) * 0.55f}, 0.09f, hex(0x6C7380)); } circO(x, {0, 0}, 0.28f, hex(0x6C7380), o); polyO(x, rrect(0.35f, -0.1f, 0.95f, 0.75f, 0.12f), c, o); break; }
    case IC_SKULL: { circO(x, {0, 0.15f}, 0.7f, c, o); polyO(x, rrect(-0.38f, -0.85f, 0.38f, -0.3f, 0.1f), c, o); circL(x, {-0.27f, 0.1f}, 0.2f, INK); circL(x, {0.27f, 0.1f}, 0.2f, INK); break; }
  }
}

// круглая кнопка с иконкой (квадратная со скруглением)
inline bool iconButton(int id, Rectangle r, Icon ic, Color base = NAVY3, bool enabled = true, Color ic_c = WHITE_) {
  bool c = button(id, r, enabled); btnFace(r, base, pressed(id), 20, enabled);
  float d = pressed(id) ? 5 : 0; icon(ic, r.x + r.width / 2, r.y + r.height / 2 - 3 + d, std::min(r.width, r.height) * 0.56f, ic_c, 2.5f);
  return c;
}
inline bool textButton(int id, Rectangle r, const char* label, Color base = NAVY3, bool enabled = true, float fs = 34, Icon ic = (Icon)-1) {
  bool c = button(id, r, enabled); bool d = pressed(id); btnFace(r, base, d, 20, enabled);
  float dy = d ? 5 : 0; float cy = r.y + (r.height - 7) / 2 + dy;
  Vector2 m = measure(F_TITLE, label, fs); float iw = (int)ic >= 0 ? fs * 1.1f : 0; float tw = m.x + iw;
  float x0 = r.x + r.width / 2 - tw / 2;
  if ((int)ic >= 0) icon(ic, x0 + fs * 0.45f, cy, fs * 0.95f, WHITE_, 2.5f);
  textO(F_TITLE, label, x0 + iw, cy - m.y / 2, fs, enabled ? WHITE_ : alpha(WHITE_, 0.6f), 2.5f, shade(base, -0.6f));
  return c;
}
inline void coinPill(float x, float y, long coins, float h = 56) {
  const char* s = fmtNum(coins); Vector2 m = measure(F_TITLE, s, h * 0.6f); float w = m.x + h + 34;
  panel({x - w, y, w, h}, NAVY1, h / 2, 4, false);
  coin(x - w + h * 0.5f, y + h / 2, h * 0.36f);
  textO(F_TITLE, s, x - w + h + 6, y + h / 2 - m.y / 2, h * 0.6f, YEL, 2.5f);
}

} // namespace gfx
