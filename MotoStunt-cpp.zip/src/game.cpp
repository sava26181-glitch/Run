// Мото Стант — C++ / raylib
#include "physics.hpp"
#include "gfx.hpp"
#include "art.hpp"
#include <string>
#include <memory>
#include <cstdlib>
#include <ctime>
#if defined(__EMSCRIPTEN__)
#include <emscripten/emscripten.h>
#include <emscripten/html5.h>
EM_JS_DEPS(moto_deps, "$UTF8ToString,$stringToNewUTF8");
EM_JS(void, js_save, (const char* s), {
  var t = UTF8ToString(s);
  try { localStorage.setItem('motostunt_sav', t); } catch (e) {}
  try { window.webkit.messageHandlers.save.postMessage(t); } catch (e) {}
});
EM_JS(char*, js_load, (), {
  var s = null;
  try { if (window.__motoSave) s = window.__motoSave; } catch (e) {}
  try { if (!s) s = localStorage.getItem('motostunt_sav'); } catch (e) {}
  if (!s) return 0;
  return stringToNewUTF8(s);
});
#endif

using namespace gfx;
using art::V;

// ================= данные =================
static const phys::BikeSpec BIKES[3] = {
  {"Дельта", phys::MOPED, 0, 1.0f, 15, 85, 1.0f, 4.3f, 0x9E2B25},
  {"Минск Кросс", phys::DIRT, 3000, 1.9f, 22, 100, 1.15f, 12.0f, 0xEDEDED},
  {"Тайфун 450", phys::ENDURO, 12000, 2.5f, 30, 105, 1.3f, 38.0f, 0xFF7A00},
};
struct LevelDef { const char* name; int theme; float len, diff; uint32_t seed; int reward; };
static const LevelDef LEVELS[5] = {
  {"Лесная тропа", 0, 450, 0.6f, 11, 250}, {"Карьер", 1, 650, 0.95f, 23, 450}, {"Зелёные холмы", 2, 850, 1.25f, 37, 700},
  {"Горный перевал", 3, 1050, 1.55f, 51, 1100}, {"Ночной хардкор", 4, 1250, 1.9f, 73, 1700},
};
static const uint32_t PAINTS[10] = {0x9E2B25, 0x1F6FD1, 0x2AA84A, 0xF2B705, 0x7B3FD1, 0x23262D, 0xEDEDED, 0xFF7A00, 0xFF4FA3, 0x19C3C9};
static const char* UPG_NAME[4] = {"Двигатель", "Колёса", "Подвеска", "Рама"};
static const char* UPG_DESC[4] = {"Больше мощности и максимальной скорости", "Лучше сцепление с землёй и разгон", "Мягче приземления, больше ход", "Легче байк, быстрее вращение в воздухе"};
static const Icon UPG_ICON[4] = {IC_ENGINE, IC_WHEEL, IC_SPRING, IC_FRAME};
static const int MAXLVL = 6;
static const float STUNT_TIME = 90;

enum TaskK { T_DIST, T_FLIPS, T_RUNS, T_WHEELIE, T_COINS, T_AIR, T_COUNT };
static const char* TASK_FMT[T_COUNT] = {"Проехать %d м", "Сделать %d сальто", "Завершить %d заезда", "Вилли на заднем колесе %d с", "Собрать %d монет на трассе", "Провести в воздухе %d с"};
static const float TASK_BASE[T_COUNT] = {1500, 3, 3, 8, 15, 12};
static const float TASK_MUL[T_COUNT] = {1.7f, 1.6f, 1.5f, 1.6f, 1.6f, 1.6f};
static const int TASK_RW[T_COUNT] = {150, 220, 150, 200, 160, 180};

// ================= сохранение =================
struct Save {
  long coins = 400; int cur = 0; bool owned[3] = {true, false, false}; phys::Upg upg[3]; int color[3] = {-1, -1, -1};
  bool lvlDone[5] = {}; float lvlBest[5] = {}; long stuntBest = 0; bool sound = true; long xp = 0; int sel = 0; // sel: 0 = стант, 1..5 = эндуро
  int tk[3] = {0, 1, 2}; float tp[3] = {0, 0, 0}; int tl[T_COUNT] = {};
} SV;
static const char* SAVE_FILE = "motostunt.sav";
static void saveGame() {
  std::string s; char b[128];
  auto put = [&](const char* k, double v) { snprintf(b, sizeof b, "%s %.3f\n", k, v); s += b; };
  put("coins", SV.coins); put("cur", SV.cur); put("stunt", SV.stuntBest); put("sound", SV.sound); put("xp", SV.xp); put("sel", SV.sel);
  for (int i = 0; i < 3; i++) { snprintf(b, sizeof b, "bike%d %d %d %d %d %d %d\n", i, SV.owned[i], SV.upg[i].engine, SV.upg[i].wheels, SV.upg[i].susp, SV.upg[i].frame, SV.color[i]); s += b; }
  for (int i = 0; i < 5; i++) { snprintf(b, sizeof b, "lvl%d %d %.3f\n", i, SV.lvlDone[i], SV.lvlBest[i]); s += b; }
  for (int i = 0; i < 3; i++) { snprintf(b, sizeof b, "task%d %d %.3f\n", i, SV.tk[i], SV.tp[i]); s += b; }
  for (int i = 0; i < T_COUNT; i++) { snprintf(b, sizeof b, "tl%d %d\n", i, SV.tl[i]); s += b; }
#if defined(__EMSCRIPTEN__)
  js_save(s.c_str());
#else
  SaveFileText(SAVE_FILE, (char*)s.c_str());
#endif
}
static void loadGame() {
  int prev = 0; (void)prev;
#if defined(__EMSCRIPTEN__)
  char* t = js_load();
#else
  SetTraceLogLevel(LOG_NONE); char* t = LoadFileText(SAVE_FILE); SetTraceLogLevel(LOG_WARNING);
#endif
  if (!t) return;
  char* line = strtok(t, "\n");
  while (line) {
    char k[32]; double v; int a[7]; float f;
    if (sscanf(line, "bike%d %d %d %d %d %d %d", &a[0], &a[1], &a[2], &a[3], &a[4], &a[5], &a[6]) == 7) {
      int i = a[0]; if (i >= 0 && i < 3) { SV.owned[i] = a[1]; SV.upg[i] = {a[2], a[3], a[4], a[5]}; SV.color[i] = std::clamp(a[6], -1, 9); }
    } else if (sscanf(line, "lvl%1d %d %f", &a[0], &a[1], &f) == 3) { if (a[0] >= 0 && a[0] < 5) { SV.lvlDone[a[0]] = a[1]; SV.lvlBest[a[0]] = f; } }
    else if (sscanf(line, "task%1d %d %f", &a[0], &a[1], &f) == 3) { if (a[0] >= 0 && a[0] < 3 && a[1] >= 0 && a[1] < T_COUNT) { SV.tk[a[0]] = a[1]; SV.tp[a[0]] = f; } }
    else if (sscanf(line, "tl%1d %d", &a[0], &a[1]) == 2) { if (a[0] >= 0 && a[0] < T_COUNT) SV.tl[a[0]] = a[1]; }
    else if (sscanf(line, "%31s %lf", k, &v) == 2) {
      std::string K = k;
      if (K == "coins") SV.coins = (long)v; else if (K == "cur") SV.cur = std::clamp((int)v, 0, 2); else if (K == "stunt") SV.stuntBest = (long)v;
      else if (K == "sound") SV.sound = v != 0; else if (K == "xp") SV.xp = (long)v; else if (K == "sel") SV.sel = std::clamp((int)v, 0, 5);
    }
    line = strtok(nullptr, "\n");
  }
#if defined(__EMSCRIPTEN__)
  free(t);
#else
  UnloadFileText(t);
#endif
  SV.owned[0] = true; if (!SV.owned[SV.cur]) SV.cur = 0;
}
static int taskTarget(int k) { return (int)std::lround(TASK_BASE[k] * std::pow(TASK_MUL[k], SV.tl[k])); }
static int taskReward(int k) { return (int)std::lround(TASK_RW[k] * (1 + 0.5f * SV.tl[k]) / 10) * 10; }
static void prog(int k, float v) { for (int i = 0; i < 3; i++) if (SV.tk[i] == k) SV.tp[i] = std::min((float)taskTarget(k), SV.tp[i] + v); }
static int tasksReady() { int n = 0; for (int i = 0; i < 3; i++) if (SV.tp[i] >= taskTarget(SV.tk[i])) n++; return n; }
static void newTask(int slot) {
  int tries = 0, k;
  do { k = GetRandomValue(0, T_COUNT - 1); tries++; } while (tries < 50 && (k == SV.tk[(slot + 1) % 3] || k == SV.tk[(slot + 2) % 3] || k == SV.tk[slot]));
  SV.tk[slot] = k; SV.tp[slot] = 0;
}
static int level() { return 1 + (int)std::sqrt(SV.xp / 150.0); }
static float levelFrac() { int l = level(); float a = 150.f * (l - 1) * (l - 1), b = 150.f * l * l; return (SV.xp - a) / (b - a); }
static Color bikeColor(int i) { return hex(SV.color[i] >= 0 ? PAINTS[SV.color[i]] : BIKES[i].color); }
static int upCost(int bi, int lvl) { return (int)std::lround((140 + bi * 260) * std::pow(lvl + 1, 1.75) / 10) * 10; }

// ================= звук =================
struct Synth { volatile float tf = 50, tv = 0; float f = 50, v = 0, ph = 0, ph2 = 0, lp = 0; } SY;
static void audioCb(void* buf, unsigned int frames) {
  float* o = (float*)buf;
  for (unsigned i = 0; i < frames; i++) {
    SY.f += (SY.tf - SY.f) * 0.0015f; SY.v += (SY.tv - SY.v) * 0.002f;
    SY.ph += SY.f / 44100.f; if (SY.ph > 1) SY.ph -= 1; SY.ph2 += SY.f * 0.5f / 44100.f; if (SY.ph2 > 1) SY.ph2 -= 1;
    float saw = SY.ph * 2 - 1, sq = SY.ph2 < 0.5f ? 0.6f : -0.6f, pulse = SY.ph < 0.12f ? 1.f : 0.f;
    float s = saw * 0.45f + sq * 0.35f + pulse * 0.4f;
    SY.lp += (s - SY.lp) * 0.18f; o[i] = SY.lp * SY.v;
  }
}
static AudioStream engineStream; static bool audioOk = false;
enum Sfx { S_CLICK, S_COIN, S_UPG, S_CRASH, S_WIN, S_BEEP, S_GO, S_TRICK, S_COUNT };
static Sound SFX[S_COUNT];
static Sound makeTone(std::initializer_list<std::pair<float, float>> notes, int type = 0, float vol = 0.35f) {
  int sr = 44100; int total = 0; for (auto& n : notes) total += (int)(n.second * sr);
  short* d = (short*)MemAlloc(total * sizeof(short)); int k = 0;
  for (auto& n : notes) { int len = (int)(n.second * sr); float ph = 0;
    for (int i = 0; i < len; i++) { float t = (float)i / len, env = (1 - t) * std::min(1.f, i / 200.f); float s;
      ph += n.first / sr; float p = ph - std::floor(ph);
      if (type == 0) s = p < 0.5f ? 1 : -1; else if (type == 1) s = std::sin(p * 2 * PI); else if (type == 2) s = (GetRandomValue(-1000, 1000) / 1000.f) * (1 - t * 0.5f); else s = 1 - 4 * std::fabs(p - 0.5f);
      d[k++] = (short)(s * env * vol * 32000); } }
  Wave w{(unsigned)total, (unsigned)sr, 16, 1, d}; Sound snd = LoadSoundFromWave(w); UnloadWave(w); return snd;
}
static void initAudio() {
  InitAudioDevice(); if (!IsAudioDeviceReady()) return;
  SetAudioStreamBufferSizeDefault(1024);
  engineStream = LoadAudioStream(44100, 32, 1); SetAudioStreamCallback(engineStream, audioCb); PlayAudioStream(engineStream);
  SFX[S_CLICK] = makeTone({{900, 0.04f}}, 3, 0.25f);
  SFX[S_COIN] = makeTone({{1320, 0.05f}, {1760, 0.09f}}, 3, 0.3f);
  SFX[S_UPG] = makeTone({{523, 0.07f}, {659, 0.07f}, {784, 0.14f}}, 0, 0.18f);
  SFX[S_CRASH] = makeTone({{100, 0.45f}}, 2, 0.4f);
  SFX[S_WIN] = makeTone({{523, 0.12f}, {659, 0.12f}, {784, 0.12f}, {1047, 0.3f}}, 0, 0.18f);
  SFX[S_BEEP] = makeTone({{440, 0.12f}}, 0, 0.2f);
  SFX[S_GO] = makeTone({{880, 0.3f}}, 0, 0.22f);
  SFX[S_TRICK] = makeTone({{784, 0.06f}, {1175, 0.12f}}, 3, 0.3f);
  audioOk = true;
}
static void sfx(Sfx s) { if (audioOk && SV.sound) PlaySound(SFX[s]); }
static void engineSnd(float rpm, float gas, bool on) { SY.tf = 38 + rpm * 150 + gas * 12; SY.tv = (on && SV.sound && audioOk) ? 0.05f + gas * 0.06f : 0; }

// ================= сцены =================
enum Scene { SC_GARAGE, SC_TUNING, SC_SHOP, SC_PAINT, SC_TASKS, SC_MODES, SC_RACE };
static Scene scene = SC_GARAGE;
static int overlay = 0; // 0 нет, 1 настройки, 2 выход, 3 сброс
static float T = 0;
static int tuneTab = 0, shopIdx = 0;
static float modeScroll = 0, modeScrollV = 0;
struct Toast { std::string s; float t = 0; } toast;
static void say(const char* s) { toast.s = s; toast.t = 2.0f; }
static float fade = 1;

// ================= гонка =================
struct Pop { std::string s; Color c; float t; };
struct Part { float x, y, vx, vy, t, s; };
struct Race {
  bool stunt = false; int li = 0; phys::Level lv; std::unique_ptr<phys::StuntGen> gen; phys::Bike bike; const art::Theme* th = nullptr;
  art::Cam cam{0, 0, 60, 0, 0}; float t = 0, startDelay = 0.9f, crashT = 0, score = 0, combo = 1, comboT = 0, air = 0, rot = 0, lastA = 0, wheelie = 0, stoppie = 0, maxX = 0;
  int coinsGot = 0, crashes = 0, cp = 0; bool over = false, paused = false, crashed = false, won = false;
  struct { float x, y, vx, vy, a, va; } rag{};
  std::vector<Pop> pops; std::vector<Part> parts; int reward = 0; bool record = false; float resT = 0;
  phys::Terrain& T() { return stunt ? gen->L.T : lv.T; }
  std::vector<phys::Coin>& coins() { return stunt ? gen->L.coins : lv.coins; }
};
static std::unique_ptr<Race> R;
static phys::Input input;

static void startRace(bool stunt, int li) {
  R = std::make_unique<Race>(); R->stunt = stunt; R->li = li;
  if (stunt) { R->gen = std::make_unique<phys::StuntGen>((uint32_t)GetRandomValue(1, 1 << 30)); R->gen->ensure(0); R->th = &art::THEMES[5]; R->lv.finishX = 1e9f; }
  else { const LevelDef& L = LEVELS[li]; R->lv = phys::genEnduro(L.len, L.diff, L.seed); R->th = &art::THEMES[L.theme]; }
  phys::Params p = phys::makeParams(BIKES[SV.cur], SV.upg[SV.cur]);
  R->bike = phys::Bike(p, 0, 0); R->bike.place(0, R->T());
  R->cam = {R->bike.x, R->bike.y, VH / 9, VW * 0.36f, VH * 0.52f};
  scene = SC_RACE; fade = 1; input = {};
}
static void pop(const std::string& s, Color c = YEL) { if (R) { R->pops.push_back({s, c, 0}); if (R->pops.size() > 4) R->pops.erase(R->pops.begin()); } }

static void endRace() {
  if (R->over) return; R->over = true; engineSnd(0, 0, false);
  if (!R->stunt) {
    const LevelDef& L = LEVELS[R->li]; bool first = !SV.lvlDone[R->li];
    int rw = (int)std::lround((first ? L.reward : L.reward * 0.35f) + R->coinsGot * 5 - R->crashes * L.reward * 0.04f);
    R->reward = std::max((int)std::lround(L.reward * 0.15f), rw);
    R->record = SV.lvlBest[R->li] <= 0 || R->t < SV.lvlBest[R->li]; if (R->record) SV.lvlBest[R->li] = R->t; SV.lvlDone[R->li] = true;
  } else { R->reward = (int)(R->score / 20); R->record = R->score > SV.stuntBest; if (R->record) SV.stuntBest = (long)R->score; }
  prog(T_RUNS, 1); SV.coins += R->reward; SV.xp += 40 + R->reward / 3; saveGame(); sfx(S_WIN);
}
static void respawn() {
  phys::Bike& b = R->bike; float x = !R->stunt ? (R->cp > 0 ? R->lv.cps[R->cp - 1] : 0) : b.x + 2;
  if (R->stunt) for (int i = 0; i < 200; i++) { if (std::fabs(R->T().hAt(x + 1) - R->T().hAt(x - 1)) < 0.05f) break; x += 0.5f; }
  b.place(x, R->T()); R->crashed = false; R->crashT = 0; R->air = 0; R->rot = 0; R->wheelie = 0; R->stoppie = 0; R->combo = 1;
}
static void landTricks() {
  phys::Bike& b = R->bike; float a = std::atan2(std::sin(b.a), std::cos(b.a));
  int flips = (int)std::floor((std::fabs(R->rot) + 0.6f) / (2 * PI));
  if (R->air > 0.35f) prog(T_AIR, R->air);
  if (std::fabs(a) < 1.1f) {
    int pts = 0; std::string name;
    if (flips > 0) { pts += flips * 1000; name = R->rot > 0 ? "БЭКФЛИП" : "ФРОНТФЛИП"; if (flips > 1) name += " x" + std::to_string(flips); prog(T_FLIPS, flips); }
    if (R->air > 0.8f) { pts += (int)(R->air * 150); if (!flips) { char b2[32]; snprintf(b2, 32, "ПОЛЁТ %.1f С", R->air); name = b2; } }
    if (pts > 0) {
      if (R->stunt) { pts = (int)(pts * R->combo); R->score += pts; pop(name + "  +" + std::to_string(pts) + (R->combo > 1 ? "  x" + std::to_string((int)R->combo) : ""), flips ? GRN : YEL); R->combo = std::min(5.f, R->combo + 1); R->comboT = 3; }
      else if (flips) { R->coinsGot += flips * 2; pop(name + "  +" + std::to_string(flips * 2) + " монет", GRN); }
      sfx(S_TRICK);
    }
  }
  R->air = 0; R->rot = 0;
}

// элементы управления
struct Ctl { Rectangle r; bool down; };
static Ctl CB, CF, CBR, CGAS;
static void layoutControls() {
  float s = 150;
  CB.r = {28, VH - s - 28, s, s}; CF.r = {28 + s + 22, VH - s - 28, s, s};
  CGAS.r = {VW - s - 28, VH - s * 1.35f - 28, s, s * 1.35f}; CBR.r = {VW - 2 * s - 50, VH - s - 28, s, s};
}
static void readControls() {
  CB.down = CF.down = CBR.down = CGAS.down = false;
  int n = GetTouchPointCount();
  auto test = [&](Vector2 p) { for (Ctl* c : {&CB, &CF, &CBR, &CGAS}) { Rectangle e = {c->r.x - 20, c->r.y - 20, c->r.width + 40, c->r.height + 40}; if (CheckCollisionPointRec(p, e)) c->down = true; } };
  for (int i = 0; i < n; i++) { Vector2 p = GetTouchPosition(i); test({p.x / S, p.y / S}); }
  if (n == 0 && pDown) test(mouse());
  input.gas = CGAS.down || IsKeyDown(KEY_UP) || IsKeyDown(KEY_W);
  input.brake = CBR.down || IsKeyDown(KEY_DOWN) || IsKeyDown(KEY_S);
  input.lean = (CB.down || IsKeyDown(KEY_LEFT) || IsKeyDown(KEY_A) ? 1.f : 0.f) - (CF.down || IsKeyDown(KEY_RIGHT) || IsKeyDown(KEY_D) ? 1.f : 0.f);
}
static bool autopilot = false;

static void updateRace(float dt) {
  Race& r = *R; phys::Bike& b = r.bike;
  if (r.startDelay > 0) r.startDelay -= dt;
  bool alive = !r.crashed;
  phys::Input in = (alive && r.startDelay <= 0 && !r.over) ? input : phys::Input{};
  if (autopilot && alive && !r.over) { in.gas = true; in.lean = b.a > 0.5f ? -1.f : b.a < -0.5f ? 1.f : 0.f; }
  float prevX = b.x;
  if (r.stunt) r.gen->ensure(b.x);
  b.step(dt, in, r.T());
  input.leanEff = in.leanEff;
  if (!r.over && r.startDelay <= 0) r.t += dt;
  if (alive && !r.over) {
    if (b.x > r.maxX) { if (b.x > prevX) prog(T_DIST, b.x - std::max(prevX, r.maxX)); r.maxX = b.x; }
    bool c0 = b.wh[0].contact, c1 = b.wh[1].contact, inAir = !c0 && !c1;
    float da = b.a - r.lastA; r.lastA = b.a;
    if (inAir) { r.air += dt; r.rot += da; } else if (r.air > 0) landTricks();
    if (c0 && !c1 && b.speed() > 2 && b.a > 0.12f) { r.wheelie += dt; prog(T_WHEELIE, dt); if (r.stunt && r.wheelie > 0.6f) r.score += dt * 120 * r.combo; }
    else { if (r.wheelie > 1.2f) { char s[48]; snprintf(s, 48, "ВИЛЛИ %.1f С", r.wheelie); pop(s); if (r.stunt) { r.combo = std::min(5.f, r.combo + 1); r.comboT = 3; } } r.wheelie = 0; }
    if (c1 && !c0 && b.speed() > 2 && b.a < -0.12f) { r.stoppie += dt; if (r.stunt && r.stoppie > 0.4f) r.score += dt * 200 * r.combo; }
    else { if (r.stoppie > 0.8f) { char s[48]; snprintf(s, 48, "СТОППИ %.1f С", r.stoppie); pop(s); } r.stoppie = 0; }
    if (r.comboT > 0) { r.comboT -= dt; if (r.comboT <= 0) r.combo = 1; }
    if (b.crashed(r.T())) {
      r.crashes++; r.crashed = true; r.crashT = 0; r.combo = 1; r.air = 0; r.rot = 0;
      float hx, hy; b.headPos(hx, hy); r.rag = {hx, hy, b.vx * 0.8f, b.vy * 0.5f + 3, b.a, (float)GetRandomValue(-10, 10)};
      sfx(S_CRASH);
    }
    for (auto& c : r.coins()) if (!c.got && std::fabs(c.x - b.x) < 1.1f && std::fabs(c.y - b.y - 0.3f) < 1.4f) { c.got = true; r.coinsGot++; prog(T_COINS, 1); sfx(S_COIN); }
    while (r.cp < (int)r.lv.cps.size() && b.x > r.lv.cps[r.cp]) { r.cp++; pop("ЧЕКПОИНТ", CYAN); sfx(S_BEEP); }
    if (!r.stunt && b.x > r.lv.finishX) endRace();
    if (r.stunt && r.t >= STUNT_TIME) endRace();
    auto& rw = b.wh[0];
    if (rw.contact && in.gas && (rw.slip > 1.5f || GetRandomValue(0, 100) < 30)) r.parts.push_back({rw.x - 0.25f, rw.y - rw.r + 0.05f, -1.f - GetRandomValue(0, 20) / 10.f, GetRandomValue(0, 20) / 10.f, 0, 0.1f + GetRandomValue(0, 15) / 100.f});
  }
  if (r.crashed) {
    auto& g = r.rag; g.vy -= phys::G * dt; g.x += g.vx * dt; g.y += g.vy * dt; g.a += g.va * dt;
    float gy = r.T().hAt(g.x) + 0.25f; if (g.y < gy) { g.y = gy; g.vy = std::fabs(g.vy) * 0.3f; g.vx *= 0.7f; g.va *= 0.7f; }
    r.crashT += dt;
    if (r.crashT > 1.6f && !r.over) { if (r.stunt && r.t >= STUNT_TIME) endRace(); else respawn(); }
  }
  for (auto& p : r.parts) { p.t += dt; p.x += p.vx * dt; p.y += p.vy * dt; p.vy -= 3 * dt; }
  r.parts.erase(std::remove_if(r.parts.begin(), r.parts.end(), [](const Part& p) { return p.t > 0.7f; }), r.parts.end());
  for (auto& p : r.pops) p.t += dt;
  r.pops.erase(std::remove_if(r.pops.begin(), r.pops.end(), [](const Pop& p) { return p.t > 1.8f; }), r.pops.end());
  float sp = std::hypot(b.vx, b.vy), gh = std::max(0.f, b.y - r.T().hAt(b.x));
  float zt = VH / (5.0f + std::min(sp, 32.f) * 0.1f + std::min(gh, 14.f) * 0.3f);
  r.cam.z += (zt - r.cam.z) * std::min(1.f, dt * 1.5f);
  r.cam.cx += (b.x + b.vx * 0.3f - r.cam.cx) * std::min(1.f, dt * 5);
  r.cam.cy += (b.y + 0.4f - r.cam.cy) * std::min(1.f, dt * 4);
  r.cam.ox = VW * 0.36f; r.cam.oy = VH * 0.46f;
  float rpm = std::min(1.2f, std::fabs(b.wh[0].w * b.wh[0].r) / b.p.vmax);
  engineSnd(rpm, in.gas ? 1 : 0, !r.over && !r.paused);
}

// ---------- HUD-приборы ----------
static void gauge(float cx, float cy, float rad, float val, float maxv, const char* label, int ticks, bool red) {
  DrawCircleV({cx, cy + 5}, rad + 8, alpha(INK, 0.6f)); DrawCircleV({cx, cy}, rad + 6, INK); DrawCircleV({cx, cy}, rad + 2, hex(0x9AA1AD)); DrawCircleV({cx, cy}, rad - 2, hex(0x11152B));
  float a0 = PI * 0.75f, a1 = PI * 2.25f;
  if (red) DrawRing({cx, cy}, rad * 0.78f, rad * 0.9f, (a0 + (a1 - a0) * 0.8f) * RAD2DEG, a1 * RAD2DEG, 16, alpha(REDC, 0.85f));
  for (int i = 0; i <= ticks * 2; i++) { float a = a0 + (a1 - a0) * i / (ticks * 2); float r0 = i % 2 ? rad * 0.82f : rad * 0.74f; DrawLineEx({cx + std::cos(a) * r0, cy + std::sin(a) * r0}, {cx + std::cos(a) * rad * 0.92f, cy + std::sin(a) * rad * 0.92f}, i % 2 ? 2 : 3, WHITE_); }
  float a = a0 + (a1 - a0) * std::clamp(val / maxv, 0.f, 1.f);
  DrawLineEx({cx, cy}, {cx + std::cos(a) * rad * 0.8f, cy + std::sin(a) * rad * 0.8f}, 5, INK); DrawLineEx({cx, cy}, {cx + std::cos(a) * rad * 0.78f, cy + std::sin(a) * rad * 0.78f}, 3, ORG);
  DrawCircleV({cx, cy}, rad * 0.12f, hex(0x9AA1AD));
  text(F_BOLD, label, cx, cy + rad * 0.35f, rad * 0.2f, MUTED, CENTER);
}

static void ctlButton(const Ctl& c, Icon ic, Color base) {
  Rectangle r = c.r; float d = c.down ? 5 : 0;
  rbox({r.x - 4, r.y - 4 + d, r.width + 8, r.height + 8 - d}, 34, alpha(INK, 0.55f));
  rbox({r.x, r.y + d, r.width, r.height - d}, 30, alpha(shade(base, -0.4f), 0.75f));
  rbox({r.x, r.y + d, r.width, r.height - 8}, 30, alpha(base, c.down ? 0.95f : 0.7f));
  icon(ic, r.x + r.width / 2, r.y + r.height / 2 - 4 + d, std::min(r.width, r.height) * 0.5f, WHITE_, 3);
}

static void drawThumb(Rectangle rc, int theme, int seed) {
  const art::Theme& th = art::THEMES[theme];
  BeginScissorMode((int)(rc.x * S), (int)(rc.y * S), (int)(rc.width * S), (int)(rc.height * S));
  art::skyLayers(th, seed * 37.f, rc, T);
  std::vector<Vector2> P; float base = rc.y + rc.height * 0.8f;
  for (float x = 0; x <= rc.width + 6; x += 6) { float y = base - rc.height * 0.08f * (std::sin((x + seed * 50) * 0.03f) + 0.6f * std::sin((x + seed * 13) * 0.071f)); P.push_back({rc.x + x, y}); }
  for (size_t i = 0; i + 1 < P.size(); i++) { DrawTriangle(P[i], {P[i].x, rc.y + rc.height}, P[i + 1], th.ground); DrawTriangle(P[i + 1], {P[i].x, rc.y + rc.height}, {P[i + 1].x, rc.y + rc.height}, th.ground); }
  for (size_t i = 0; i + 1 < P.size(); i++) DrawLineEx({P[i].x, P[i].y + 4}, {P[i + 1].x, P[i + 1].y + 4}, 9, th.top);
  EndScissorMode();
}

static void drawRace() {
  Race& r = *R; phys::Bike& b = r.bike; const art::Theme& th = *r.th; art::Cam& c = r.cam;
  art::skyLayers(th, c.cx, {0, 0, VW, VH}, T);
  float x0 = c.cx - c.ox / c.z - 3, x1 = c.cx + (VW - c.ox) / c.z + 3;
  art::groundDeco(th, r.T(), c, x0, x1);
  art::terrain(th, r.T(), c, x0, x1);
  for (size_t i = 0; i < r.lv.cps.size(); i++) { float x = r.lv.cps[i]; if (x > x0 - 2 && x < x1) art::flagPole(c, x, r.T().hAt(x), (int)i < r.cp, T); }
  if (!r.stunt && r.lv.finishX < x1 + 6) art::finishArch(c, r.lv.finishX, r.T().hAt(r.lv.finishX));
  for (auto& cn : r.coins()) if (!cn.got && cn.x > x0 && cn.x < x1) { V p = c.w2s(cn.x, cn.y + std::sin(T * 3 + cn.x) * 0.1f); float sq = std::fabs(std::cos(T * 2.5f + cn.x)); DrawEllipse((int)p.x, (int)p.y, c.z * 0.34f * sq + 3, c.z * 0.34f + 3, INK); DrawEllipse((int)p.x, (int)p.y, c.z * 0.34f * sq, c.z * 0.34f, hex(0xF5A623)); DrawEllipse((int)p.x, (int)p.y, c.z * 0.26f * sq, c.z * 0.26f, YEL); }
  for (auto& p : r.parts) { V s = c.w2s(p.x, p.y); DrawCircleV(s, p.s * (1 + p.t * 2) * c.z, alpha(shade(th.ground, 0.4f), 1 - p.t / 0.7f)); }
  // тень байка
  { float gy = r.T().hAt(b.x); V s = c.w2s(b.x, gy); float hgt = std::max(0.f, b.y - gy); DrawEllipse((int)s.x, (int)(s.y + 3), c.z * 0.9f / (1 + hgt * 0.3f), c.z * 0.12f / (1 + hgt * 0.3f), alpha(INK, 0.35f)); }
  art::BikeView v = art::viewOf(b, bikeColor(SV.cur)); v.rider = !r.crashed;
  V s = c.w2s(b.x, b.y); art::drawBike(v, s.x, s.y, c.z);
  if (r.crashed) { V p = c.w2s(r.rag.x, r.rag.y); Xf rx(p.x, p.y, c.z, r.rag.a);
    lineO(rx, {0, -0.45f}, {0.3f, -0.9f}, 0.14f, hex(0x2F5F9E)); lineO(rx, {0, -0.45f}, {-0.25f, -0.95f}, 0.14f, hex(0x2F5F9E));
    lineO(rx, {0, -0.45f}, {0, 0.2f}, 0.22f, hex(0xF2F4F8)); lineO(rx, {0, 0.1f}, {0.35f, -0.15f}, 0.08f, hex(0xE8B08A)); circO(rx, {0, 0.4f}, 0.17f, hex(0xD63A30)); }
  // ---- HUD ----
  if (iconButton(100, {24, 20, 84, 84}, IC_PAUSE) && !r.over) { r.paused = true; sfx(S_CLICK); }
  if (!r.stunt) {
    float bw = std::min(620.f, VW * 0.45f), bx = VW / 2 - bw / 2, by = 34; float f = std::clamp(b.x / r.lv.finishX, 0.f, 1.f);
    rbox({bx - 4, by - 4, bw + 8, 30}, 15, INK); rbox({bx, by, bw, 22}, 11, hex(0x0F1430)); rbox({bx, by, std::max(22.f, bw * f), 22}, 11, GRN);
    for (size_t i = 0; i < r.lv.cps.size(); i++) { float fx = bx + bw * r.lv.cps[i] / r.lv.finishX; DrawRectangle((int)fx - 2, (int)by - 4, 4, 30, (int)i < r.cp ? WHITE_ : alpha(WHITE_, 0.5f)); }
    icon(IC_FLAG, bx + bw + 26, by + 8, 40); icon(IC_HELMET, bx + bw * f, by + 10, 40, hex(0xD63A30));
    char s2[64]; snprintf(s2, 64, "%.1f с", r.t); icon(IC_TIMER, VW / 2 - 70, by + 64, 34); textO(F_TITLE, s2, VW / 2 - 46, by + 46, 34, WHITE_, 3);
    coin(VW / 2 + 70, by + 64, 15); snprintf(s2, 64, "%d", r.coinsGot); textO(F_TITLE, s2, VW / 2 + 92, by + 46, 34, YEL, 3);
  } else {
    char s2[64]; snprintf(s2, 64, "%s", fmtNum((long)r.score)); textO(F_TITLE, s2, VW / 2, 18, 64, YEL, 4, INK, CENTER, 4);
    if (r.combo > 1) { snprintf(s2, 64, "КОМБО x%d", (int)r.combo); textO(F_BLACK, s2, VW / 2, 88, 30, GRN, 3, INK, CENTER); }
    float left = std::max(0.f, STUNT_TIME - r.t); snprintf(s2, 64, "%d", (int)std::ceil(left));
    panel({VW - 170, 26, 140, 64}, left < 10 ? REDC : NAVY1, 32, 4, false); icon(IC_TIMER, VW - 136, 58, 38); textO(F_TITLE, s2, VW - 110, 38, 40, WHITE_, 3);
  }
  // приборы
  float spd = std::fabs(b.speed()) * 3.6f, rpm = std::min(1.2f, std::fabs(b.wh[0].w * b.wh[0].r) / b.p.vmax);
  float gcx = VW / 2, gcy = VH - 92;
  gauge(gcx - 88, gcy + 14, 62, rpm * 10, 12, "x1000", 6, true);
  gauge(gcx + 40, gcy, 82, spd, 140, "км/ч", 7, false);
  char sp[16]; snprintf(sp, 16, "%d", (int)spd); textO(F_TITLE, sp, gcx + 40, gcy + 8, 30, WHITE_, 2.5f, INK, CENTER);
  // управление
  ctlButton(CB, IC_LEAN_B, NAVY4); ctlButton(CF, IC_LEAN_F, NAVY4); ctlButton(CBR, IC_BRAKE, REDC); ctlButton(CGAS, IC_GAS, GRN);
  // всплывающие надписи
  for (size_t i = 0; i < r.pops.size(); i++) { auto& p = r.pops[i]; float a = std::min(1.f, (1.8f - p.t) * 2.5f); float sc = p.t < 0.15f ? 0.6f + p.t / 0.15f * 0.5f : (p.t < 0.3f ? 1.1f - (p.t - 0.15f) / 0.15f * 0.1f : 1.f);
    float fs = 52 * sc; textO(F_BLACK, p.s.c_str(), VW / 2, VH * 0.24f + (r.pops.size() - 1 - i) * 62.f - p.t * 10, fs, alpha(p.c, a), 4, alpha(INK, a), CENTER, 4); }
  if (r.crashed && r.crashT < 1.6f) { float a = std::min(1.f, r.crashT * 4); float w = 520; rbox({VW / 2 - w / 2 - 4, VH * 0.38f - 4, w + 8, 96}, 18, alpha(INK, a)); rbox({VW / 2 - w / 2, VH * 0.38f, w, 88}, 16, alpha(REDC, a)); textO(F_TITLE, "АВАРИЯ!", VW / 2, VH * 0.38f + 14, 60, alpha(WHITE_, a), 3, alpha(INK, a), CENTER); }
  if (r.startDelay > 0) { textO(F_TITLE, "ПОЕХАЛИ!", VW / 2, VH * 0.36f, 90, WHITE_, 5, INK, CENTER, 6); }
}

// ---------- диалоги гонки ----------
static void dim() { DrawRectangle(0, 0, (int)VW + 1, (int)VH + 1, alpha(hex(0x050818), 0.7f)); }
static void ribbon(float cx, float y, const char* s, Color c) {
  Vector2 m = measure(F_TITLE, s, 52); float w = m.x + 120;
  rbox({cx - w / 2 - 4, y - 4, w + 8, 84}, 20, INK); rbox({cx - w / 2, y, w, 76}, 18, c); rbox({cx - w / 2 + 8, y + 6, w - 16, 24}, 12, alpha(WHITE_, 0.18f));
  textO(F_TITLE, s, cx, y + 11, 52, WHITE_, 3, shade(c, -0.6f), CENTER);
}
static void raceDialogs() {
  Race& r = *R;
  if (r.paused) {
    dim(); float w = 560, h = 400, x = VW / 2 - w / 2, y = VH / 2 - h / 2 + 20;
    panel({x, y, w, h}); ribbon(VW / 2, y - 40, "ПАУЗА", NAVY4);
    if (textButton(201, {x + 50, y + 70, w - 100, 84}, "Продолжить", GRN, true, 36, IC_PLAY)) { r.paused = false; sfx(S_CLICK); }
    if (textButton(202, {x + 50, y + 170, w - 100, 84}, "Заново", NAVY4, true, 36, IC_RESTART)) { bool st = r.stunt; int li = r.li; sfx(S_CLICK); startRace(st, li); return; }
    if (textButton(203, {x + 50, y + 270, w - 100, 84}, "В гараж", REDC, true, 36, IC_HOME)) { R.reset(); scene = SC_GARAGE; engineSnd(0, 0, false); sfx(S_CLICK); saveGame(); fade = 1; return; }
  }
  if (r.over) {
    r.resT += GetFrameTime(); dim();
    float w = 640, h = r.stunt ? 430 : 500, x = VW / 2 - w / 2, y = VH / 2 - h / 2 + 30; float k = std::min(1.f, r.resT * 4); y += (1 - k) * 60;
    panel({x, y, w, h}); ribbon(VW / 2, y - 44, r.stunt ? "ВРЕМЯ ВЫШЛО" : "ФИНИШ!", r.stunt ? ORG : GRN_D);
    auto row = [&](float yy, Icon ic, const char* name, const char* val, Color vc) { inset({x + 36, yy, w - 72, 64}); icon(ic, x + 76, yy + 32, 38); text(F_BOLD, name, x + 110, yy + 16, 32, MUTED); textO(F_TITLE, val, x + w - 60, yy + 12, 38, vc, 2.5f, INK, RIGHT); };
    char b1[64], b2[64];
    if (!r.stunt) { snprintf(b1, 64, "%.1f с", r.t); row(y + 60, IC_TIMER, r.record ? "Время — рекорд!" : "Время", b1, r.record ? GRN : WHITE_); snprintf(b2, 64, "%d", r.coinsGot); row(y + 134, IC_COIN, "Монеты на трассе", b2, YEL); }
    else { row(y + 60, IC_STAR, r.record ? "Очки — рекорд!" : "Очки", fmtNum((long)r.score), r.record ? GRN : YEL); snprintf(b2, 64, "%d", r.crashes); row(y + 134, IC_SKULL, "Аварии", b2, WHITE_); }
    if (!r.stunt) { snprintf(b2, 64, "%d", r.crashes); row(y + 208, IC_SKULL, "Аварии", b2, WHITE_); }
    float ry = y + (r.stunt ? 214 : 288);
    rbox({x + 36, ry, w - 72, 76}, 16, hex(0x173F2A)); text(F_TITLE, "Награда", x + 70, ry + 20, 38, WHITE_);
    snprintf(b1, 64, "+%s", fmtNum(r.reward)); Vector2 m = measure(F_TITLE, b1, 46); coin(x + w - 76 - m.x - 30, ry + 38, 22); textO(F_TITLE, b1, x + w - 66, ry + 13, 46, YEL, 3, INK, RIGHT);
    float by = y + h - 104; bool next = !r.stunt && r.li < 4; float bw = next ? (w - 72 - 32) / 3 : (w - 72 - 16) / 2;
    if (textButton(211, {x + 36, by, bw, 80}, "Ещё", NAVY4, true, 32, IC_RESTART)) { bool st = r.stunt; int li = r.li; sfx(S_CLICK); startRace(st, li); return; }
    if (next && textButton(212, {x + 36 + bw + 16, by, bw, 80}, "Дальше", NAVY4, true, 32, IC_ARROW_R)) { int li = r.li + 1; SV.sel = li + 1; sfx(S_CLICK); startRace(false, li); return; }
    if (textButton(213, {x + w - 36 - bw, by, bw, 80}, "Гараж", GRN, true, 32, IC_HOME)) { R.reset(); scene = SC_GARAGE; sfx(S_CLICK); fade = 1; return; }
  }
}

// ================= гараж и меню =================
static void stageBike(float cx, float floorY, float k, int bi, float bob = 0) {
  phys::Params p = phys::makeParams(BIKES[bi], SV.upg[bi]);
  DrawEllipse((int)cx, (int)floorY + 6, k * 1.25f + 6, k * 0.2f + 6, INK);
  DrawEllipse((int)cx, (int)floorY + 6, k * 1.25f, k * 0.2f, hex(0x2B3D8A));
  DrawEllipse((int)cx, (int)floorY + 2, k * 1.18f, k * 0.16f, hex(0x34479A));
  DrawEllipseLines((int)cx, (int)floorY + 2, k * 1.0f, k * 0.12f, alpha(CYAN, 0.5f + 0.3f * std::sin(T * 3)));
  art::BikeView v = art::restView(p, bikeColor(bi)); v.pose = std::sin(T * 0.8f) * 0.08f;
  float wy = p.r - p.anch[0][1] + 0.06f; // центр масс над землёй
  for (int i = 0; i < 2; i++) { v.wy[i] = -wy + p.r; v.phi[i] = 0; }
  art::drawBike(v, cx, floorY - wy * k + bob, k);
}

static void topBar(const char* title, bool back, int backTo = SC_GARAGE) {
  if (back) { if (iconButton(1, {24, 20, 84, 84}, IC_BACK)) { scene = (Scene)backTo; sfx(S_CLICK); } }
  else {
    Rectangle pr = {24, 20, 330, 84}; panel(pr, NAVY1, 22, 4, false);
    DrawCircleV({70, 62}, 34, INK); DrawCircleV({70, 62}, 31, NAVY3); icon(IC_HELMET, 70, 62, 48, hex(0xD63A30), 2.5f);
    text(F_TITLE, "ГОНЩИК", 116, 30, 28, WHITE_);
    char lv[32]; snprintf(lv, 32, "%d", level());
    DrawCircleV({100, 90}, 16, INK); DrawCircleV({100, 90}, 13, YEL); text(F_TITLE, lv, 100, 79, 22, INK, CENTER);
    rbox({116, 70, 210, 18}, 9, hex(0x0F1430)); rbox({116, 70, std::max(18.f, 210 * levelFrac()), 18}, 9, GRN);
  }
  if (title) textO(F_TITLE, title, back ? 130 : VW * 0.47f, 34, 50, WHITE_, 3.5f, INK, back ? LEFT : CENTER, 4);
  coinPill(VW - 128, 34, SV.coins, 56);
  if (iconButton(2, {VW - 108, 20, 84, 84}, IC_GEAR)) { overlay = 1; sfx(S_CLICK); }
}

static void statsPanel(Rectangle r, int bi) {
  panel(r, NAVY1, 20); phys::Params p = phys::makeParams(BIKES[bi], SV.upg[bi]);
  struct { const char* n; float f; char v[24]; Icon ic; } st[4];
  st[0] = {"Мощность", p.T / (230 * 3.6f), "", IC_ENGINE}; snprintf(st[0].v, 24, "%.1f л.с.", BIKES[bi].hp * (1 + 0.13f * SV.upg[bi].engine));
  st[1] = {"Скорость", p.vmax / 38, "", IC_BOLT}; snprintf(st[1].v, 24, "%d км/ч", (int)(p.vmax * 3.6f));
  st[2] = {"Сцепление", p.mu / 2.0f, "", IC_WHEEL}; snprintf(st[2].v, 24, "%d%%", (int)(p.mu * 100));
  st[3] = {"Вес", 1 - (p.M - 120) / 60, "", IC_FRAME}; snprintf(st[3].v, 24, "%d кг", (int)(p.M - 65));
  float rh = (r.height - 24) / 4;
  for (int i = 0; i < 4; i++) {
    float y = r.y + 12 + i * rh; icon(st[i].ic, r.x + 34, y + rh / 2, rh * 0.6f, WHITE_, 2);
    text(F_BOLD, st[i].n, r.x + 62, y + rh / 2 - 13, 24, MUTED);
    float bx = r.x + 200, bw = r.width - 200 - 120;
    rbox({bx, y + rh / 2 - 7, bw, 14}, 7, hex(0x0F1430)); rbox({bx, y + rh / 2 - 7, std::max(14.f, bw * std::clamp(st[i].f, 0.f, 1.f)), 14}, 7, GRN);
    text(F_TITLE, st[i].v, r.x + r.width - 18, y + rh / 2 - 14, 26, WHITE_, RIGHT);
  }
}

static void drawGarage() {
  float bx = VW * 0.47f; art::garageBg(T, bx);
  stageBike(bx, VH * 0.72f, 200, SV.cur);
  topBar(BIKES[SV.cur].name, false);
  // левая панель инструментов
  struct { Icon ic; const char* l; Scene to; } tb[4] = {{IC_WRENCH, "Тюнинг", SC_TUNING}, {IC_CART, "Салон", SC_SHOP}, {IC_PAINT, "Покраска", SC_PAINT}, {IC_TASKS, "Задания", SC_TASKS}};
  for (int i = 0; i < 4; i++) {
    Rectangle r = {24, 128 + i * 98.f, 84, 84};
    if (iconButton(10 + i, r, tb[i].ic)) { scene = tb[i].to; sfx(S_CLICK); if (scene == SC_SHOP) shopIdx = SV.cur; }
    { Vector2 m = measure(F_BOLD, tb[i].l, 22); rbox({r.x + r.width + 8, r.y + 26, m.x + 24, 34}, 17, alpha(INK, 0.75f)); text(F_BOLD, tb[i].l, r.x + r.width + 20, r.y + 31, 22, WHITE_); }
    if (i == 3 && tasksReady()) { DrawCircleV({r.x + r.width - 4, r.y + 4}, 17, INK); DrawCircleV({r.x + r.width - 4, r.y + 4}, 14, REDC); char n[4]; snprintf(n, 4, "%d", tasksReady()); text(F_TITLE, n, r.x + r.width - 4, r.y - 8, 22, WHITE_, CENTER); }
  }
  // статы
  statsPanel({24 + 0, VH - 180, std::min(560.f, VW * 0.38f), 156}, SV.cur);
  // режим + старт
  float rw = std::min(440.f, VW * 0.3f), rx = VW - rw - 28;
  Rectangle mc = {rx, VH - 290, rw, 120};
  bool mclick = button(20, mc); bool md = pressed(20);
  panel({mc.x, mc.y + (md ? 4 : 0), mc.width, mc.height}, NAVY2, 20);
  Rectangle th = {mc.x + 12, mc.y + 12 + (md ? 4 : 0), 150, mc.height - 24};
  int sel = SV.sel; drawThumb(th, sel == 0 ? 5 : LEVELS[sel - 1].theme, sel * 7 + 3); DrawRectangleLinesEx(th, 3, INK);
  text(F_BOLD, "Режим", th.x + th.width + 16, th.y + 2, 24, MUTED);
  textO(F_TITLE, sel == 0 ? "Стант-парк" : LEVELS[sel - 1].name, th.x + th.width + 16, th.y + 30, 32, WHITE_, 2.5f);
  text(F_BOLD, sel == 0 ? "Трюки · 90 сек" : "Эндуро", th.x + th.width + 16, th.y + 68, 24, YEL);
  icon(IC_ARROW_R, mc.x + mc.width - 30, mc.y + mc.height / 2, 30);
  if (mclick) { scene = SC_MODES; sfx(S_CLICK); }
  if (textButton(21, {rx, VH - 150, rw, 124}, "СТАРТ", GRN, true, 64)) { sfx(S_GO); startRace(sel == 0, sel == 0 ? 0 : sel - 1); }
}

static void sidePanelBike(int bi) { float bx = VW * 0.27f; art::garageBg(T, bx); stageBike(bx, VH * 0.72f, 175, bi); }

static void drawTuning() {
  sidePanelBike(SV.cur); topBar("ТЮНИНГ", true);
  float px = VW * 0.5f, pw = VW - px - 28, py = 124, ph = VH - py - 24;
  panel({px, py, pw, ph});
  float tw = (pw - 40 - 30) / 4;
  for (int i = 0; i < 4; i++) {
    Rectangle r = {px + 20 + i * (tw + 10), py + 18, tw, 96};
    bool on = tuneTab == i; if (button(30 + i, r)) { tuneTab = i; sfx(S_CLICK); }
    btnFace(r, on ? NAVY4 : NAVY1, pressed(30 + i), 18);
    icon(UPG_ICON[i], r.x + r.width / 2, r.y + 38, 48, WHITE_, 2.5f);
    text(F_BOLD, UPG_NAME[i], r.x + r.width / 2, r.y + 66, 21, on ? WHITE_ : MUTED, CENTER);
  }
  int* lv[4] = {&SV.upg[SV.cur].engine, &SV.upg[SV.cur].wheels, &SV.upg[SV.cur].susp, &SV.upg[SV.cur].frame};
  int l = *lv[tuneTab]; int cost = upCost(SV.cur, l); bool max = l >= MAXLVL;
  float cy = py + 136;
  inset({px + 20, cy, pw - 40, 190});
  icon(UPG_ICON[tuneTab], px + 90, cy + 80, 96, WHITE_, 3);
  textO(F_TITLE, UPG_NAME[tuneTab], px + 160, cy + 22, 40, WHITE_, 3);
  text(F_BOLD, UPG_DESC[tuneTab], px + 160, cy + 74, 22, MUTED);
  for (int i = 0; i < MAXLVL; i++) { Rectangle d = {px + 160 + i * 52.f, cy + 112, 44, 20}; rbox({d.x - 3, d.y - 3, d.width + 6, d.height + 6}, 10, INK); rbox(d, 8, i < l ? GRN : hex(0x2A3570)); }
  char b[96]; const char* eff[4] = {"+13%% мощности, +5%% скорости", "+7%% сцепления", "+10%% жёсткости, больше ход", "-4%% веса, +10%% вращения"};
  snprintf(b, 96, max ? "Максимальный уровень" : eff[tuneTab]); text(F_BOLD, b, px + 160, cy + 150, 24, max ? YEL : GRN);
  // график мощности
  float gy = cy + 204, gh = ph - (gy - py) - 124;
  if (gh > 60) {
    inset({px + 20, gy, pw - 40, gh}); text(F_BOLD, "Кривая мощности", px + 36, gy + 10, 22, MUTED);
    phys::Params p = phys::makeParams(BIKES[SV.cur], SV.upg[SV.cur]); phys::Upg nu = SV.upg[SV.cur]; if (!max) { int* q[4] = {&nu.engine, &nu.wheels, &nu.susp, &nu.frame}; (*q[tuneTab])++; }
    phys::Params pn = phys::makeParams(BIKES[SV.cur], nu);
    float gx0 = px + 50, gx1 = px + pw - 50, gy0 = gy + gh - 18, gy1 = gy + 42;
    for (int i = 0; i <= 4; i++) DrawLineEx({gx0, gy0 - (gy0 - gy1) * i / 4}, {gx1, gy0 - (gy0 - gy1) * i / 4}, 1, alpha(WHITE_, 0.08f));
    auto curve = [&](const phys::Params& q, Color c, float w) { V prev{}; for (int i = 0; i <= 40; i++) { float v = 32.f * i / 40, ratio = v / q.vmax, tq = q.T * std::max(0.f, 1 - ratio * ratio); V pt = {gx0 + (gx1 - gx0) * i / 40, gy0 - (gy0 - gy1) * tq / (230 * 3.6f * 1.2f)}; if (i) DrawLineEx(prev, pt, w, c); prev = pt; } };
    if (!max && tuneTab == 0) curve(pn, alpha(GRN, 0.9f), 4);
    curve(p, CYAN, 5);
  }
  // кнопка
  Rectangle ub = {px + 20, py + ph - 108, pw - 40, 88};
  if (max) { textButton(40, ub, "МАКСИМУМ", NAVY3, false, 40); }
  else {
    bool can = SV.coins >= cost; char lab[48]; snprintf(lab, 48, "УЛУЧШИТЬ  %s", fmtNum(cost));
    if (textButton(40, ub, lab, can ? GRN : NAVY3, true, 40)) { if (can) { SV.coins -= cost; (*lv[tuneTab])++; sfx(S_UPG); saveGame(); } else { say("Не хватает монет"); sfx(S_BEEP); } }
    Vector2 m = measure(F_TITLE, lab, 40); coin(ub.x + ub.width / 2 + m.x / 2 + 30, ub.y + 38 + (pressed(40) ? 5 : 0), 18);
  }
}

static void drawShop() {
  art::garageBg(T, VW * 0.36f);
  stageBike(VW * 0.36f, VH * 0.72f, 200, shopIdx);
  topBar("МОТОСАЛОН", true);
  if (iconButton(50, {40, VH * 0.42f, 90, 110}, IC_ARROW_L, NAVY3, shopIdx > 0)) { shopIdx--; sfx(S_CLICK); }
  if (iconButton(51, {VW * 0.72f - 130, VH * 0.42f, 90, 110}, IC_ARROW_R, NAVY3, shopIdx < 2)) { shopIdx++; sfx(S_CLICK); }
  for (int i = 0; i < 3; i++) { float dx = VW * 0.36f + (i - 1) * 30; DrawCircleV({dx, VH - 46}, 10, INK); DrawCircleV({dx, VH - 46}, 7, i == shopIdx ? YEL : NAVY3); }
  float px = VW * 0.72f - 20, pw = VW - px - 28, py = 124, ph = VH - py - 24;
  panel({px, py, pw, ph});
  const phys::BikeSpec& B = BIKES[shopIdx];
  textO(F_TITLE, B.name, px + 30, py + 24, 44, WHITE_, 3);
  const char* cls[3] = {"Мопед · класс D", "Кросс · класс C", "Эндуро · класс B"};
  text(F_BOLD, cls[shopIdx], px + 30, py + 80, 24, YEL);
  statsPanel({px + 20, py + 124, pw - 40, 220}, shopIdx);
  Rectangle bb = {px + 20, py + ph - 108, pw - 40, 88};
  if (SV.cur == shopIdx) textButton(52, bb, "В ГАРАЖЕ", NAVY3, false, 38, IC_CHECK);
  else if (SV.owned[shopIdx]) { if (textButton(53, bb, "ВЫБРАТЬ", GRN, true, 38)) { SV.cur = shopIdx; saveGame(); sfx(S_UPG); } }
  else {
    bool can = SV.coins >= B.price; const char* lab = fmtNum(B.price);
    if (textButton(54, bb, lab, can ? GRN : NAVY3, true, 42)) { if (can) { SV.coins -= B.price; SV.owned[shopIdx] = true; SV.cur = shopIdx; saveGame(); sfx(S_WIN); } else { say("Не хватает монет"); sfx(S_BEEP); } }
    Vector2 m = measure(F_TITLE, lab, 42); coin(bb.x + bb.width / 2 - m.x / 2 - 34, bb.y + 38 + (pressed(54) ? 5 : 0), 20);
    icon(IC_LOCK, px + pw - 60, py + 50, 52);
  }
}

static void drawPaint() {
  sidePanelBike(SV.cur); topBar("ПОКРАСКА", true);
  float px = VW * 0.5f, pw = VW - px - 28, py = 124, ph = VH - py - 24;
  panel({px, py, pw, ph});
  text(F_BOLD, "Цвет мотоцикла · 100", px + 30, py + 24, 28, MUTED); coin(px + 30 + measure(F_BOLD, "Цвет мотоцикла · 100", 28).x + 24, py + 40, 15);
  float cs = std::min(110.f, (pw - 60) / 5 - 16);
  for (int i = 0; i < 10; i++) {
    float cx = px + 30 + (i % 5) * (cs + 16) + cs / 2, cy = py + 100 + (i / 5) * (cs + 26) + cs / 2;
    Rectangle r = {cx - cs / 2, cy - cs / 2, cs, cs}; bool sel = SV.color[SV.cur] == i;
    if (button(60 + i, r)) {
      if (!sel) { if (SV.coins >= 100) { SV.coins -= 100; SV.color[SV.cur] = i; saveGame(); sfx(S_UPG); } else { say("Не хватает монет"); sfx(S_BEEP); } }
    }
    float d = pressed(60 + i) ? 4 : 0;
    DrawCircleV({cx, cy + 6}, cs / 2 + 4, alpha(INK, 0.7f)); DrawCircleV({cx, cy + d}, cs / 2 + 4, INK); DrawCircleV({cx, cy + d}, cs / 2, hex(PAINTS[i])); DrawCircleV({cx - cs * 0.15f, cy - cs * 0.15f + d}, cs * 0.16f, alpha(WHITE_, 0.35f));
    if (sel) { DrawRing({cx, cy + d}, cs / 2 + 7, cs / 2 + 13, 0, 360, 40, YEL); icon(IC_CHECK, cx, cy + d, cs * 0.45f, WHITE_); }
  }
  Rectangle rb = {px + 20, py + ph - 108, pw - 40, 88};
  if (SV.color[SV.cur] >= 0) { if (textButton(75, rb, "Заводской цвет", NAVY4, true, 34, IC_RESTART)) { SV.color[SV.cur] = -1; saveGame(); sfx(S_CLICK); } }
  else textButton(75, rb, "Заводской цвет", NAVY3, false, 34, IC_CHECK);
}

static void drawTasks() {
  art::garageBg(T, VW * 0.5f); topBar("ЗАДАНИЯ", true);
  float pw = std::min(1000.f, VW - 80), px = VW / 2 - pw / 2, py = 140;
  for (int i = 0; i < 3; i++) {
    float y = py + i * 180; Rectangle r = {px, y, pw, 160}; panel(r);
    int k = SV.tk[i], tg = taskTarget(k); bool done = SV.tp[i] >= tg;
    Icon ics[T_COUNT] = {IC_FLAG, IC_RESTART, IC_TROPHY, IC_LEAN_B, IC_COIN, IC_STAR};
    DrawCircleV({px + 80, y + 80}, 50, INK); DrawCircleV({px + 80, y + 80}, 46, done ? GRN_D : NAVY4); icon(ics[k], px + 80, y + 80, 56);
    char b[96]; snprintf(b, 96, TASK_FMT[k], tg); textO(F_TITLE, b, px + 150, y + 28, 34, WHITE_, 3);
    float bx = px + 150, bw = pw - 150 - 300; rbox({bx - 3, y + 92, bw + 6, 40}, 20, INK); rbox({bx, y + 95, bw, 34}, 17, hex(0x0F1430));
    rbox({bx, y + 95, std::max(34.f, bw * std::min(1.f, SV.tp[i] / tg)), 34}, 17, done ? GRN : NAVY4);
    snprintf(b, 96, "%d / %d", (int)SV.tp[i], tg); text(F_TITLE, b, bx + bw / 2, y + 99, 24, WHITE_, CENTER);
    Rectangle cb = {px + pw - 270, y + 38, 240, 84}; char lab[32]; snprintf(lab, 32, "%d", taskReward(k));
    if (textButton(80 + i, cb, done ? lab : lab, done ? GRN : NAVY3, done, 36)) { SV.coins += taskReward(k); SV.tl[k]++; newTask(i); saveGame(); sfx(S_WIN); }
    Vector2 m = measure(F_TITLE, lab, 36); coin(cb.x + cb.width / 2 - m.x / 2 - 30, cb.y + 38 + (pressed(80 + i) ? 5 : 0), 18);
  }
}

static float dragStartX = 0, dragStartScroll = 0; static bool dragArmed = false;
static void drawModes() {
  art::garageBg(T, VW * 0.5f); DrawRectangle(0, 0, (int)VW + 1, (int)VH + 1, alpha(hex(0x0A0F2A), 0.55f));
  topBar("ВЫБОР ЗАЕЗДА", true);
  float cw = 320, ch = 470, gap = 30, y0 = 150; int n = 6; float total = n * (cw + gap) - gap + 60;
  float maxS = std::max(0.f, total - VW);
  Vector2 m = mouse();
  if (pPressed() && m.y > 130) { dragArmed = true; dragStartX = m.x; dragStartScroll = modeScroll; dragging = false; }
  if (dragArmed && pDown) { float dx = m.x - dragStartX; if (std::fabs(dx) > 14) dragging = true; if (dragging) { float ns = dragStartScroll - dx; modeScrollV = (ns - modeScroll) / std::max(0.001f, GetFrameTime()); modeScroll = ns; } }
  else { modeScroll += modeScrollV * GetFrameTime(); modeScrollV *= std::pow(0.02f, GetFrameTime()); }
  modeScroll = std::clamp(modeScroll, 0.f, maxS);
  for (int i = 0; i < n; i++) {
    float x = 30 + i * (cw + gap) - modeScroll; if (x > VW || x + cw < 0) continue;
    Rectangle r = {x, y0, cw, ch}; bool open = i <= 1 || SV.lvlDone[i - 2]; bool sel = SV.sel == i;
    bool c = button(90 + i, r); float d = pressed(90 + i) && !dragging ? 5 : 0;
    panel({r.x, r.y + d, r.width, r.height}, sel ? NAVY3 : NAVY2, 24, sel ? 6 : 4);
    if (sel) rbox({r.x - 8, r.y - 8 + d, r.width + 16, r.height + 16}, 30, alpha(YEL, 0.0f));
    Rectangle th = {r.x + 16, r.y + 16 + d, r.width - 32, 240};
    drawThumb(th, i == 0 ? 5 : LEVELS[i - 1].theme, i * 7 + 3); DrawRectangleLinesEx(th, 4, INK);
    if (i == 0) icon(IC_STAR, th.x + th.width / 2, th.y + th.height / 2, 90, YEL, 4);
    else icon(IC_FLAG, th.x + th.width / 2, th.y + th.height / 2, 90, WHITE_, 4);
    const char* nm = i == 0 ? "Стант-парк" : LEVELS[i - 1].name;
    textO(F_TITLE, nm, r.x + 24, r.y + 274 + d, 34, WHITE_, 3);
    char b[64];
    if (i == 0) { text(F_BOLD, "Трюки на время · 90 сек", r.x + 24, r.y + 324 + d, 22, MUTED); snprintf(b, 64, "Рекорд: %s", fmtNum(SV.stuntBest)); text(F_BOLD, b, r.x + 24, r.y + 356 + d, 26, YEL); }
    else { const LevelDef& L = LEVELS[i - 1]; snprintf(b, 64, "Эндуро · %d м", (int)L.len); text(F_BOLD, b, r.x + 24, r.y + 324 + d, 22, MUTED);
      if (SV.lvlBest[i - 1] > 0) { snprintf(b, 64, "Рекорд: %.1f с", SV.lvlBest[i - 1]); text(F_BOLD, b, r.x + 24, r.y + 356 + d, 26, GRN); }
      else { snprintf(b, 64, "Награда: %d", L.reward); text(F_BOLD, b, r.x + 24, r.y + 356 + d, 26, YEL); }
      for (int s = 0; s < 5; s++) { float dd = L.diff; DrawCircleV({r.x + 34 + s * 30.f, r.y + 420 + d}, 11, INK); DrawCircleV({r.x + 34 + s * 30.f, r.y + 420 + d}, 8, s < (int)std::ceil(dd * 2.6f) ? ORG : NAVY1); } }
    if (!open) { rbox({r.x, r.y + d, r.width, r.height}, 24, alpha(hex(0x070B20), 0.72f)); icon(IC_LOCK, r.x + r.width / 2, r.y + 150 + d, 110); text(F_BOLD, "Пройди предыдущую трассу", r.x + r.width / 2, r.y + 230 + d, 22, MUTED, CENTER); }
    if (c && open) { SV.sel = i; saveGame(); sfx(S_GO); startRace(i == 0, i == 0 ? 0 : i - 1); }
  }
  if (pReleased()) dragArmed = false;
}

static void drawOverlay() {
  if (!overlay) return;
  dim(); float w = 600, h = overlay == 1 ? 460 : 330, x = VW / 2 - w / 2, y = VH / 2 - h / 2 + 20;
  panel({x, y, w, h});
  if (overlay == 1) {
    ribbon(VW / 2, y - 40, "НАСТРОЙКИ", NAVY4);
    if (textButton(301, {x + 50, y + 70, w - 100, 84}, SV.sound ? "Звук: вкл" : "Звук: выкл", NAVY4, true, 34, SV.sound ? IC_SOUND : IC_MUTE)) { SV.sound = !SV.sound; saveGame(); sfx(S_CLICK); }
    if (textButton(302, {x + 50, y + 170, w - 100, 84}, "Сбросить прогресс", REDC, true, 34, IC_RESTART)) { overlay = 3; sfx(S_CLICK); }
    if (textButton(303, {x + 50, y + 300, w - 100, 84}, "Закрыть", GRN, true, 34, IC_CHECK)) { overlay = 0; sfx(S_CLICK); }
    text(F_BOLD, "Мото Стант 2.0 · C++ / raylib", VW / 2, y + h - 40, 20, MUTED, CENTER);
  } else if (overlay == 3) {
    ribbon(VW / 2, y - 40, "ТОЧНО?", REDC);
    text(F_BOLD, "Все монеты, байки и рекорды пропадут", VW / 2, y + 70, 26, WHITE_, CENTER);
    if (textButton(311, {x + 40, y + 200, (w - 100) / 2, 84}, "Сбросить", REDC, true, 34)) { SV = Save(); saveGame(); overlay = 0; sfx(S_CRASH); }
    if (textButton(312, {x + 60 + (w - 100) / 2, y + 200, (w - 100) / 2, 84}, "Отмена", NAVY4, true, 34)) { overlay = 1; sfx(S_CLICK); }
  } else if (overlay == 2) {
    ribbon(VW / 2, y - 40, "ВЫЙТИ?", NAVY4);
    text(F_BOLD, "Прогресс сохранён", VW / 2, y + 70, 28, WHITE_, CENTER);
    if (textButton(321, {x + 40, y + 200, (w - 100) / 2, 84}, "Выйти", REDC, true, 34)) { overlay = 99; }
    if (textButton(322, {x + 60 + (w - 100) / 2, y + 200, (w - 100) / 2, 84}, "Остаться", GRN, true, 34)) { overlay = 0; sfx(S_CLICK); }
  }
}

// ================= main =================
static const char* shot = nullptr; static const char* shotScene = nullptr; static int shotFrames = 30; static int frameNo = 0; static bool quit = false;

#if defined(__EMSCRIPTEN__)
static void webFit() {
  double dpr = emscripten_get_device_pixel_ratio(); if (dpr > 2.5) dpr = 2.5; if (dpr < 1) dpr = 1;
  int w = EM_ASM_INT({ return window.innerWidth; }), h = EM_ASM_INT({ return window.innerHeight; });
  int W2 = (int)(w * dpr), H2 = (int)(h * dpr);
  if (W2 > 0 && H2 > 0 && (W2 != GetScreenWidth() || H2 != GetScreenHeight())) SetWindowSize(W2, H2);
}
#endif

static void frame() {
#if defined(__EMSCRIPTEN__)
  webFit();
#endif
  float dt = std::min(GetFrameTime(), 0.05f); if (shotScene) dt = 1 / 60.f; T += dt; frameNo++;
  updateScreen(); layoutControls(); updatePointer();
  if (IsKeyPressed(KEY_BACK) || IsKeyPressed(KEY_ESCAPE)) {
    if (overlay) overlay = 0;
    else if (scene == SC_RACE && R) { if (R->over) { R.reset(); scene = SC_GARAGE; } else R->paused = !R->paused; }
    else if (scene != SC_GARAGE) scene = SC_GARAGE;
    else overlay = 2;
  }
#if defined(PLATFORM_ANDROID) || defined(__ANDROID__)
  if (scene == SC_RACE && R && !R->over && !IsWindowFocused()) R->paused = true;
#endif
  if (scene == SC_RACE && R) { readControls(); if (!R->paused) { static float acc = 0; acc += dt; int n = 0; while (acc >= 1 / 60.f && n < 4) { updateRace(1 / 60.f); acc -= 1 / 60.f; n++; } if (n == 4) acc = 0; } else engineSnd(0, 0, false); }
  if (shotScene && std::string(shotScene) == "result" && R && frameNo == shotFrames - 5) { R->t = 44.2f; R->coinsGot = 17; endRace(); R->resT = 1; }
  if (shotScene && std::string(shotScene) == "pause" && R && frameNo == shotFrames - 3) R->paused = true;

  BeginDrawing(); ClearBackground(NAVY0);
  rlPushMatrix(); rlScalef(S, S, 1);
  switch (scene) {
    case SC_GARAGE: drawGarage(); break;
    case SC_TUNING: drawTuning(); break;
    case SC_SHOP: drawShop(); break;
    case SC_PAINT: drawPaint(); break;
    case SC_TASKS: drawTasks(); break;
    case SC_MODES: drawModes(); break;
    case SC_RACE: if (R) { drawRace(); raceDialogs(); } else scene = SC_GARAGE; break;
  }
  drawOverlay();
  if (toast.t > 0) { toast.t -= dt; float a = std::min(1.f, toast.t * 3); Vector2 m = measure(F_TITLE, toast.s.c_str(), 32); Rectangle r = {VW / 2 - m.x / 2 - 30, 120, m.x + 60, 60}; rbox({r.x - 4, r.y - 4, r.width + 8, r.height + 8}, 30, alpha(INK, a)); rbox(r, 28, alpha(REDC, a)); text(F_TITLE, toast.s.c_str(), VW / 2, r.y + 13, 32, alpha(WHITE_, a), CENTER); }
  if (fade > 0) { DrawRectangle(0, 0, (int)VW + 1, (int)VH + 1, alpha(NAVY0, fade)); fade -= dt * 4; }
  rlPopMatrix();
  EndDrawing();
  if (pReleased()) dragging = false;
  if (overlay == 99) quit = true;
  if (shot && frameNo >= shotFrames) { TakeScreenshot(shot); quit = true; }
}

int main(int argc, char** argv) {
  for (int i = 1; i + 1 < argc; i++) if (!strcmp(argv[i], "--shot")) { shotScene = argv[i + 1]; if (i + 2 < argc) shot = argv[i + 2]; if (i + 3 < argc) shotFrames = atoi(argv[i + 3]); }
#if defined(__EMSCRIPTEN__)
  SetConfigFlags(FLAG_MSAA_4X_HINT);
  { double dpr = emscripten_get_device_pixel_ratio(); if (dpr > 2.5) dpr = 2.5; if (dpr < 1) dpr = 1;
    int w = EM_ASM_INT({ return window.innerWidth; }), h = EM_ASM_INT({ return window.innerHeight; });
    InitWindow((int)(w * dpr), (int)(h * dpr), "Мото Стант"); }
#elif defined(PLATFORM_ANDROID) || defined(__ANDROID__)
  SetConfigFlags(FLAG_MSAA_4X_HINT | FLAG_VSYNC_HINT);
  InitWindow(0, 0, "Мото Стант");
#else
  SetConfigFlags(FLAG_MSAA_4X_HINT | FLAG_VSYNC_HINT | FLAG_WINDOW_RESIZABLE);
  InitWindow(1300, 600, "Мото Стант");
#endif
  SetExitKey(KEY_NULL); rlDisableBackfaceCulling();
  SetRandomSeed((unsigned)time(nullptr));
  if (!shotScene) initAudio();
  loadFonts(); loadGame();
  updateScreen(); layoutControls();
  if (shotScene) {
    SV.coins = 52000; SV.owned[1] = SV.owned[2] = true; SV.lvlDone[0] = SV.lvlDone[1] = true; SV.lvlBest[0] = 41.3f; SV.tp[0] = 9999; SV.xp = 900;
    std::string s = shotScene;
    if (s == "tuning") scene = SC_TUNING; else if (s == "shop") { scene = SC_SHOP; shopIdx = 1; } else if (s == "paint") scene = SC_PAINT; else if (s == "tasks") scene = SC_TASKS; else if (s == "modes") scene = SC_MODES;
    else if (s.rfind("bike", 0) == 0) { SV.cur = s[4] - '0'; }
    else if (s.rfind("race", 0) == 0) { int li = s[4] - '0'; SV.cur = s.size() > 5 ? s[5] - '0' : 0; autopilot = true; if (li == 9) startRace(true, 0); else startRace(false, li); }
    else if (s == "result") { autopilot = true; startRace(false, 0); }
    else if (s == "pause") { startRace(true, 0); }
    else if (s == "settings") overlay = 1;
  }
#if defined(__EMSCRIPTEN__)
  emscripten_set_main_loop(frame, 0, 1);
#else
  SetTargetFPS(60);
  while (!WindowShouldClose() && !quit) frame();
  saveGame();
  if (audioOk) { UnloadAudioStream(engineStream); for (auto& s : SFX) UnloadSound(s); CloseAudioDevice(); }
  CloseWindow();
#endif
  return 0;
}
