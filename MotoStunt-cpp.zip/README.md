# Мото Стант 2.0 — C++ / raylib

Стант и эндуро на мотоциклах. Вся графика рисуется кодом (мультяшный стиль с обводкой), без картинок и эмодзи.

- 3 мотоцикла: Дельта (мопед), Минск Кросс, Тайфун 450
- Тюнинг (двигатель, колёса, подвеска, рама) с кривой мощности, покраска (10 цветов)
- Стант-парк (90 сек трюков: сальто, вилли, стоппи, полёты, комбо) и 5 трасс эндуро
- Задания, уровень гонщика, звук мотора (синтез), сохранение прогресса

## Сборка APK и IPA
GitHub Actions: `.github/workflows/build.yml` → Releases → MotoStunt.apk и MotoStunt.ipa.
- Android: нативная сборка C++ (NDK, NativeActivity).
- iPhone: тот же C++ код собирается Emscripten в WebAssembly и запускается в iOS-приложении (WKWebView).
Можно залить проект одним zip — workflow сам распакует.

## Структура
- `src/physics.hpp` — физика байка и генерация трасс
- `src/gfx.hpp` — примитивы с обводкой, шрифты, иконки, кнопки
- `src/art.hpp` — модели мотоциклов, гонщик, фоны
- `src/game.cpp` — экраны, гонка, звук, сохранения
- `assets/fonts` — Russo One и Rubik (лицензия OFL)
- `android/` — Gradle-проект (NativeActivity), raylib подтягивается при сборке
- `ios/` — iOS-обёртка (Swift), `web/shell.html` — страница для WebAssembly

## На ПК
`cmake -B build && cmake --build build && ./build/motostunt`
